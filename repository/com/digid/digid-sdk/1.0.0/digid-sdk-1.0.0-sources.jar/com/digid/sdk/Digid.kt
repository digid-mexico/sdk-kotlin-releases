package com.digid.sdk

import android.content.Context
import android.util.Log
import com.digid.sdk.internal.DigidTokenStore
import com.digid.sdk.internal.DigidSessionManager

/**
 * Punto de entrada principal del SDK de Digid.
 * Debe inicializarse una sola vez en Application.onCreate() antes de usar cualquier módulo.
 *
 * ```kotlin
 * Digid.initialize(
 *     context = this,
 *     clientId = BuildConfig.DIGID_CLIENT_ID,
 *     token = BuildConfig.DIGID_TOKEN,
 *     environment = DigidEnvironment.PRODUCTION
 * )
 * ```
 */
object Digid {

    private const val TAG = "DigidSDK"
    private var isInitialized = false

    internal lateinit var applicationContext: Context
        private set

    lateinit var environment: DigidEnvironment
        private set

    lateinit var theme: DigidTheme
        private set

    /** ID del cliente en el sistema de Digid. Enviado al backend en cada solicitud KYC. */
    lateinit var clientId: String
        private set

    /**
     * Inicializa el SDK. Debe llamarse en Application.onCreate().
     *
     * @param context Contexto de la aplicación.
     * @param clientId Identificador del cliente proporcionado por Digid.
     * @param token Token de acceso proporcionado por Digid. Usar BuildConfig o un gestor de secretos, nunca hardcodear.
     * @param environment SANDBOX para pruebas, PRODUCTION para producción.
     * @param theme Configuración visual del SDK.
     */
    @Synchronized
    fun initialize(
        context: Context,
        clientId: String,
        token: String,
        environment: DigidEnvironment = DigidEnvironment.PRODUCTION,
        theme: DigidTheme = DigidTheme()
    ) {
        require(token.isNotBlank()) { "El token de acceso no puede estar vacío." }
        require(clientId.isNotBlank()) { "El clientId no puede estar vacío." }

        if (isInitialized) {
            Log.w(TAG, "Digid SDK ya fue inicializado. La llamada adicional será ignorada.")
            return
        }

        this.applicationContext = context.applicationContext
        this.clientId = clientId
        this.environment = environment
        this.theme = theme

        DigidTokenStore.initialize(context.applicationContext)
        DigidTokenStore.storeToken(token)

        DigidSessionManager.initialize(
            context = context.applicationContext,
            token = token,
            environment = environment
        )

        isInitialized = true
        Log.i(TAG, "Digid SDK inicializado. Ambiente: ${environment.name}")
    }

    fun isInitialized(): Boolean = isInitialized

    internal fun requireInitialized() {
        check(isInitialized) {
            "Digid SDK no ha sido inicializado. Llama a Digid.initialize() en Application.onCreate()."
        }
    }

    internal fun getToken(): String {
        requireInitialized()
        return DigidTokenStore.getToken()
            ?: throw IllegalStateException("No se encontró un token de acceso válido.")
    }

    fun updateTheme(newTheme: DigidTheme) {
        theme = newTheme
        Log.i(TAG, "Tema actualizado.")
    }
}
