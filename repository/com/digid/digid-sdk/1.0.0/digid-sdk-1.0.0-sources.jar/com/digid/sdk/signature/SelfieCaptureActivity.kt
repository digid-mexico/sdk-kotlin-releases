package com.digid.sdk.signature

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import com.digid.sdk.DigidResultCode
import com.digid.sdk.internal.DigidAPIClient
import com.digid.sdk.internal.DigidImageUtils

/**
 * Activity para captura de selfie con camara frontal usando Camera2 API.
 */
class SelfieCaptureActivity : AppCompatActivity(), TextureView.SurfaceTextureListener {

    companion object {
        const val EXTRA_DOCUMENT_ID = "digid_document_id"
        const val EXTRA_CLIENT_ID = "digid_client_id"
        const val EXTRA_SIGNER_ID = "digid_signer_id"
        const val EXTRA_RESULT = SelfieCaptureResult.EXTRA_RESULT
        const val EXTRA_ERROR = SelfieCaptureResult.EXTRA_ERROR

        private const val TAG = "SelfieCaptureActivity"
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100
        private const val OVAL_WIDTH_RATIO = 0.65f
        private const val OVAL_HEIGHT_RATIO = 1.35f
        private const val OVAL_TOP_OFFSET_RATIO = 0.08f
    }

    private lateinit var documentId: String
    private lateinit var clientId: String
    private lateinit var signerId: String

    private lateinit var textureView: TextureView
    private lateinit var capturedImageView: ImageView
    private lateinit var overlayView: OvalOverlayView
    private lateinit var hintLabel: TextView
    private lateinit var captureButton: FrameLayout
    private lateinit var cameraIconView: View
    private lateinit var saveButton: FrameLayout
    private lateinit var retryButton: FrameLayout
    private lateinit var loadingIndicator: ProgressBar
    private lateinit var contentLayout: FrameLayout

    private var cameraManager: CameraManager? = null
    private var cameraDevice: CameraDevice? = null
    private var previewSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var capturedBitmap: Bitmap? = null
    private var isCaptureMode = true

    private var cameraThread: HandlerThread? = null
    private var cameraHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try { Digid.requireInitialized() } catch (e: IllegalStateException) {
            deliverError(DigidException(DigidErrorCode.SDK_NOT_INITIALIZED, e.message ?: "")); return
        }

        documentId = intent.getStringExtra(EXTRA_DOCUMENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "document_id es requerido."))
            return
        }
        clientId = intent.getStringExtra(EXTRA_CLIENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "client_id es requerido."))
            return
        }
        signerId = intent.getStringExtra(EXTRA_SIGNER_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "signer_id es requerido."))
            return
        }

        val theme = Digid.theme
        val primaryColor = Color.parseColor(theme.primaryColor)
        window.statusBarColor = primaryColor

        startCameraThread()
        buildUI()
        checkCameraPermission()
    }

    override fun onDestroy() {
        super.onDestroy()
        closeCameraDevice()
        imageReader?.close()
        stopCameraThread()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (isCaptureMode) deliverCancelled() else resetToCapture()
    }

    // TextureView.SurfaceTextureListener
    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        openCamera()
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}

    private fun startCameraThread() {
        cameraThread = HandlerThread("CameraThread").also { it.start() }
        cameraHandler = Handler(cameraThread!!.looper)
    }

    private fun stopCameraThread() {
        cameraThread?.quitSafely()
        try {
            cameraThread?.join()
            cameraThread = null
            cameraHandler = null
        } catch (_: InterruptedException) {}
    }

    private fun buildUI() {
        val theme = Digid.theme
        val primaryColor = Color.parseColor(theme.primaryColor)
        val secondaryColor = Color.parseColor(theme.secondaryColor)

        contentLayout = FrameLayout(this)
        contentLayout.setBackgroundColor(Color.BLACK)
        contentLayout.id = View.generateViewId()
        setContentView(contentLayout)

        ViewCompat.setOnApplyWindowInsetsListener(contentLayout) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Toolbar - simple 56dp bar below status bar
        val toolbar = RelativeLayout(this)
        toolbar.id = View.generateViewId()
        toolbar.setBackgroundColor(primaryColor)
        val toolbarHeight = 56.dpToPx()
        val toolbarParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            toolbarHeight
        )
        toolbarParams.gravity = Gravity.TOP
        contentLayout.addView(toolbar, toolbarParams)

        val title = TextView(this)
        title.text = "Captura de Selfie"
        title.setTextColor(Color.WHITE)
        title.textSize = 18f
        title.typeface = Typeface.DEFAULT_BOLD
        val titleParams = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        )
        titleParams.addRule(RelativeLayout.CENTER_VERTICAL)
        titleParams.setMargins(48.dpToPx(), 0, 0, 0)
        toolbar.addView(title, titleParams)

        val btnCancel = Button(this)
        btnCancel.text = "Cancelar"
        btnCancel.setTextColor(Color.WHITE)
        btnCancel.background = null
        val cancelParams = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        )
        cancelParams.addRule(RelativeLayout.ALIGN_PARENT_END)
        cancelParams.addRule(RelativeLayout.CENTER_VERTICAL)
        cancelParams.setMargins(0, 0, 48.dpToPx(), 0)
        toolbar.addView(btnCancel, cancelParams)
        btnCancel.setOnClickListener { deliverCancelled() }

        // Camera preview - starts below toolbar
        textureView = TextureView(this)
        textureView.surfaceTextureListener = this
        val previewParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        previewParams.topMargin = toolbarHeight
        contentLayout.addView(textureView, previewParams)

        // Captured image (initially hidden) - starts below toolbar
        capturedImageView = ImageView(this)
        capturedImageView.scaleType = ImageView.ScaleType.CENTER_CROP
        val capturedParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        capturedParams.topMargin = toolbarHeight
        contentLayout.addView(capturedImageView, capturedParams)
        capturedImageView.visibility = View.GONE

        // Oval overlay - starts below toolbar
        overlayView = OvalOverlayView(this, primaryColor)
        val overlayParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        overlayParams.topMargin = toolbarHeight
        contentLayout.addView(overlayView, overlayParams)

        // Hint label - positioned in upper area of preview
        hintLabel = TextView(this)
        hintLabel.text = "Centre su rostro en el ovalo"
        hintLabel.setTextColor(Color.WHITE)
        hintLabel.textSize = 14f
        hintLabel.textAlignment = View.TEXT_ALIGNMENT_CENTER
        val hintParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        hintParams.setMargins(32.dpToPx(), (toolbarHeight + 24.dpToPx()), 32.dpToPx(), 0)
        contentLayout.addView(hintLabel, hintParams)

        // Capture button (white circle with camera icon)
        captureButton = FrameLayout(this)
        captureButton.elevation = 8f
        val captureDrawable = GradientDrawable()
        captureDrawable.setColor(Color.WHITE)
        captureDrawable.shape = GradientDrawable.OVAL
        captureButton.background = captureDrawable
        val captureSize = 80.dpToPx()
        val captureButtonParams = FrameLayout.LayoutParams(captureSize, captureSize)
        captureButtonParams.gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
        captureButtonParams.bottomMargin = 48.dpToPx()
        contentLayout.addView(captureButton, captureButtonParams)

        cameraIconView = View(this)
        cameraIconView.setBackgroundResource(android.R.drawable.ic_menu_camera)
        val iconParams = FrameLayout.LayoutParams(32.dpToPx(), 32.dpToPx())
        iconParams.gravity = Gravity.CENTER
        captureButton.addView(cameraIconView, iconParams)
        captureButton.setOnClickListener { captureSelfie() }

        // Save button - initially hidden
        saveButton = FrameLayout(this)
        val saveDrawable = GradientDrawable()
        saveDrawable.setColor(primaryColor)
        saveDrawable.cornerRadius = 8f.dpToPxFloat()
        saveButton.background = saveDrawable
        val saveButtonParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            48.dpToPx()
        )
        saveButtonParams.gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
        saveButtonParams.bottomMargin = 48.dpToPx()
        contentLayout.addView(saveButton, saveButtonParams)
        saveButton.visibility = View.GONE

        val saveText = TextView(this)
        saveText.text = "Guardar Selfie"
        saveText.setTextColor(Color.WHITE)
        saveText.textSize = 16f
        saveText.typeface = Typeface.DEFAULT_BOLD
        saveText.setPadding(32.dpToPx(), 0, 32.dpToPx(), 0)
        saveText.gravity = Gravity.CENTER
        val saveTextParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        saveTextParams.gravity = Gravity.CENTER
        saveButton.addView(saveText, saveTextParams)
        saveButton.setOnClickListener { uploadSelfie() }

        // Retry button - initially hidden
        retryButton = FrameLayout(this)
        val retryDrawable = GradientDrawable()
        retryDrawable.setColor(Color.TRANSPARENT)
        retryDrawable.setStroke(2.dpToPx(), secondaryColor)
        retryDrawable.shape = GradientDrawable.OVAL
        retryButton.background = retryDrawable
        val retrySize = 56.dpToPx()
        val retryButtonParams = FrameLayout.LayoutParams(retrySize, retrySize)
        retryButtonParams.gravity = Gravity.START or Gravity.BOTTOM
        retryButtonParams.setMargins(32.dpToPx(), 0, 0, 48.dpToPx())
        contentLayout.addView(retryButton, retryButtonParams)
        retryButton.visibility = View.GONE

        val retryIcon = TextView(this)
        retryIcon.text = "\u21BB"
        retryIcon.setTextColor(secondaryColor)
        retryIcon.textSize = 24f
        retryIcon.typeface = Typeface.DEFAULT_BOLD
        val retryIconParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        retryIconParams.gravity = Gravity.CENTER
        retryButton.addView(retryIcon, retryIconParams)
        retryButton.setOnClickListener { resetToCapture() }

        // Loading indicator
        loadingIndicator = ProgressBar(this)
        val loadingParams = FrameLayout.LayoutParams(64.dpToPx(), 64.dpToPx())
        loadingParams.gravity = Gravity.CENTER
        contentLayout.addView(loadingIndicator, loadingParams)
        loadingIndicator.visibility = View.GONE
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (textureView.isAvailable) openCamera()
            } else {
                deliverError(
                    DigidException(DigidErrorCode.CAMERA_PERMISSION_DENIED, "Permiso de camara denegado.")
                )
            }
        }
    }

    private fun openCamera() {
        try {
            cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
            val frontCameraId = cameraManager!!.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager!!.getCameraCharacteristics(id)
                characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            } ?: return

            val characteristics = cameraManager!!.getCameraCharacteristics(frontCameraId)
            val previewSizes = characteristics
                .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray()

            if (previewSizes.isNotEmpty()) {
                val previewSize = previewSizes[0]
                val surfaceTexture = textureView.surfaceTexture ?: return
                surfaceTexture.setDefaultBufferSize(previewSize.width, previewSize.height)

                imageReader = ImageReader.newInstance(
                    previewSize.width, previewSize.height, android.graphics.ImageFormat.JPEG, 1
                )
            }

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED
            ) return

            cameraManager!!.openCamera(frontCameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    startPreview()
                }

                override fun onDisconnected(camera: CameraDevice) {
                    closeCameraDevice()
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    deliverError(
                        DigidException(DigidErrorCode.DEVICE_NOT_SUPPORTED, "Error al abrir camara: $error")
                    )
                }
            }, cameraHandler)
        } catch (e: CameraAccessException) {
            Log.e(TAG, "Camera access exception: ${e.message}")
            deliverError(
                DigidException(DigidErrorCode.DEVICE_NOT_SUPPORTED, "No se puede acceder a la camara.")
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreview() {
        try {
            val device = cameraDevice ?: return
            val surfaceTexture = textureView.surfaceTexture ?: return
            val previewSurface = Surface(surfaceTexture)

            val requestBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            requestBuilder.addTarget(previewSurface)

            val surfaces = mutableListOf(previewSurface)
            imageReader?.surface?.let { surfaces.add(it) }

            device.createCaptureSession(
                surfaces,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        previewSession = session
                        try {
                            requestBuilder.set(
                                CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                            )
                            session.setRepeatingRequest(requestBuilder.build(), null, cameraHandler)
                        } catch (e: CameraAccessException) {
                            Log.e(TAG, "Error setting repeating request: ${e.message}")
                        }
                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        deliverError(
                            DigidException(
                                DigidErrorCode.DEVICE_NOT_SUPPORTED,
                                "No se pudo configurar la sesion de camara."
                            )
                        )
                    }
                },
                cameraHandler
            )
        } catch (e: CameraAccessException) {
            Log.e(TAG, "Camera access exception: ${e.message}")
        }
    }

    private fun captureSelfie() {
        try {
            val device = cameraDevice ?: return
            val reader = imageReader ?: return

            val requestBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            requestBuilder.addTarget(reader.surface)

            reader.setOnImageAvailableListener({ imgReader ->
                val image = imgReader.acquireLatestImage() ?: return@setOnImageAvailableListener
                val buffer = image.planes[0].buffer
                buffer.rewind()
                val imageData = ByteArray(buffer.remaining())
                buffer.get(imageData)
                image.close()

                val bitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.size)
                    ?: return@setOnImageAvailableListener
                // Mirror the image horizontally (front camera mirror correction)
                val matrix = Matrix()
                matrix.preScale(-1f, 1f, bitmap.width / 2f, bitmap.height / 2f)
                val mirroredBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                mainHandler.post { onSelfieCaptured(mirroredBitmap) }
            }, cameraHandler)

            requestBuilder.set(
                CaptureRequest.CONTROL_AF_TRIGGER,
                CaptureRequest.CONTROL_AF_TRIGGER_START
            )

            previewSession?.capture(
                requestBuilder.build(),
                object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureCompleted(
                        session: CameraCaptureSession,
                        request: CaptureRequest,
                        result: TotalCaptureResult
                    ) {
                        super.onCaptureCompleted(session, request, result)
                    }
                },
                cameraHandler
            )
        } catch (e: CameraAccessException) {
            Log.e(TAG, "Capture error: ${e.message}")
        }
    }

    private fun onSelfieCaptured(bitmap: Bitmap) {
        capturedBitmap = bitmap
        capturedImageView.setImageBitmap(bitmap)

        isCaptureMode = false
        overlayView.setShowSaveMode(true)
        hintLabel.text = "Verifique que su rostro se vea completo"

        textureView.visibility = View.GONE
        capturedImageView.visibility = View.VISIBLE
        captureButton.visibility = View.GONE
        saveButton.visibility = View.VISIBLE
        retryButton.visibility = View.VISIBLE
    }

    private fun resetToCapture() {
        capturedBitmap?.recycle()
        capturedBitmap = null
        capturedImageView.setImageBitmap(null)

        isCaptureMode = true
        overlayView.setShowSaveMode(false)
        hintLabel.text = "Centre su rostro en el ovalo"

        textureView.visibility = View.VISIBLE
        capturedImageView.visibility = View.GONE
        captureButton.visibility = View.VISIBLE
        saveButton.visibility = View.GONE
        retryButton.visibility = View.GONE

        startPreview()
    }

    private fun uploadSelfie() {
        val bitmap = capturedBitmap ?: return
        loadingIndicator.visibility = View.VISIBLE
        captureButton.isEnabled = false
        saveButton.isEnabled = false
        retryButton.isEnabled = false

        Thread {
            try {
                val selfieBase64 = DigidImageUtils.resizedPngBase64(bitmap, 96)
                val response = DigidAPIClient.uploadSelfie(
                    documentId.toIntOrNull() ?: 0,
                    signerId.toIntOrNull() ?: 0,
                    selfieBase64
                )

                mainHandler.post {
                    loadingIndicator.visibility = View.GONE
                    if (response.success) {
                        deliverSuccess()
                    } else {
                        deliverError(
                            DigidException(
                                DigidErrorCode.VERIFICATION_SERVICE_ERROR,
                                response.error ?: "Error al cargar la selfie."
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Upload error: ${e.message}")
                mainHandler.post {
                    loadingIndicator.visibility = View.GONE
                    deliverError(
                        DigidException(DigidErrorCode.NETWORK_ERROR, "Error de red: ${e.message}")
                    )
                }
            }
        }.start()
    }

    private fun deliverSuccess() {
        val result = SelfieCaptureResult(success = true, message = "Selfie capturada exitosamente.")
        setResult(RESULT_OK, Intent().putExtra(EXTRA_RESULT, result))
        finish()
    }

    private fun deliverCancelled() {
        val result = SelfieCaptureResult(success = false, message = "Proceso cancelado por el usuario.")
        setResult(DigidResultCode.RESULT_CANCELLED, Intent().putExtra(EXTRA_RESULT, result))
        finish()
    }

    private fun deliverError(error: DigidException) {
        setResult(DigidResultCode.RESULT_ERROR, Intent().putExtra(EXTRA_ERROR, error))
        finish()
    }

    private fun closeCameraDevice() {
        try {
            previewSession?.close()
            cameraDevice?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing camera: ${e.message}")
        }
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()
    private fun Float.dpToPxFloat(): Float = this * resources.displayMetrics.density

    /**
     * Overlay view con mascara oscura y recorte oval transparente.
     * Dimensions match iOS: width = 65% of container, height = width * 1.35, positioned 8% from top.
     */
    inner class OvalOverlayView(
        context: android.content.Context,
        private val primaryColor: Int
    ) : View(context) {

        private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var showSaveMode = false

        fun setShowSaveMode(saveMode: Boolean) {
            showSaveMode = saveMode
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val w = width.toFloat()
            val h = height.toFloat()
            val ovalWidth = w * OVAL_WIDTH_RATIO
            val ovalHeight = ovalWidth * OVAL_HEIGHT_RATIO
            val ovalLeft = (w - ovalWidth) / 2
            val ovalTop = h * OVAL_TOP_OFFSET_RATIO
            val ovalRight = ovalLeft + ovalWidth
            val ovalBottom = ovalTop + ovalHeight

            // Dark mask with oval cutout using even-odd fill
            val path = Path().apply {
                fillType = Path.FillType.EVEN_ODD
                addRect(0f, 0f, w, h, Path.Direction.CW)
                addOval(ovalLeft, ovalTop, ovalRight, ovalBottom, Path.Direction.CCW)
            }

            maskPaint.color = Color.BLACK
            maskPaint.alpha = 153  // 0.6 opacity (153/255 ≈ 0.6)
            maskPaint.style = Paint.Style.FILL
            canvas.drawPath(path, maskPaint)

            // White oval border with 0.8 opacity, 3dp stroke
            borderPaint.color = if (showSaveMode) primaryColor else Color.WHITE
            borderPaint.alpha = (255 * 0.8).toInt()  // 0.8 opacity
            borderPaint.style = Paint.Style.STROKE
            borderPaint.strokeWidth = 3f.dpToPxFloat()
            canvas.drawOval(ovalLeft, ovalTop, ovalRight, ovalBottom, borderPaint)
        }
    }
}
