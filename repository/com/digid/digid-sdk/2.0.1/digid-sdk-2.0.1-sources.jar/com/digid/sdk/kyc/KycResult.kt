package com.digid.sdk.kyc

import android.graphics.Bitmap
import android.os.Parcelable
import com.google.gson.Gson
import kotlinx.parcelize.Parcelize

/**
 * Resultado completo del proceso de verificación KYC.
 *
 * [success] indica que el proceso completó sin errores técnicos.
 * [faceMatch] y [livenessCheck] indican si el usuario pasó la verificación biométrica.
 * Es posible que [success] sea true pero [faceMatch] sea false (el proceso funcionó
 * pero el usuario no pasó la verificación).
 *
 * Usa [isApproved] para determinar si el usuario fue verificado exitosamente.
 *
 * El SDK descarga automáticamente las imágenes ([frontImage], [backImage], [selfieImage],
 * [portraitImage]) y el video de liveness ([livenessVideoLocalPath]). Además conserva las
 * URLs remotas ([frontImageUrl], etc., [livenessVideoUrl]) por si necesitas descargarlas
 * más tarde (requieren el token de acceso).
 */
@Parcelize
data class KycResult(
    val success: Boolean,
    val message: String,
    val sessionId: String,
    /** Identificador del usuario en el sistema del cliente. */
    val vendorData: String,
    val timestamp: String,
    /** Estado reportado por el servidor: "Approved", "Declined", "In Review". */
    val status: String,
    /** true cuando los datos de la verificación están completos y listos para consumirse. */
    val ready: Boolean,
    val faceMatch: Boolean,
    /** Similitud facial (0-100). Se recomienda aprobar a partir de 80. */
    val faceMatchScore: Float,
    val livenessCheck: Boolean,
    /** Confianza de prueba de vida (0-100). Se recomienda aprobar a partir de 80. */
    val livenessScore: Float,
    val documentValid: Boolean,
    /** Método de prueba de vida usado (ej. "PASSIVE"). Puede ser null. */
    val livenessMethod: String?,
    /** Edad estimada por análisis facial (0-100). Puede ser null. */
    val ageEstimation: Float?,
    /** Calidad de la imagen facial (0-100). Puede ser null. */
    val faceQuality: Float?,
    val document: KycDocument,

    // ─── Recursos multimedia ya descargados (listos para usar) ───
    /** Foto frontal del documento. Puede ser null si no está disponible. */
    val frontImage: Bitmap?,
    /** Foto del reverso del documento. Puede ser null si no está disponible. */
    val backImage: Bitmap?,
    /** Selfie del usuario. Puede ser null si no está disponible. */
    val selfieImage: Bitmap?,
    /** Retrato extraído del documento. Puede ser null si no está disponible. */
    val portraitImage: Bitmap?,

    // ─── URLs remotas (del JSON; requieren token para descargarse) ───
    val frontImageUrl: String?,
    val backImageUrl: String?,
    val selfieImageUrl: String?,
    val portraitImageUrl: String?,

    // ─── Video de liveness ───
    /** URL remota del video (campo `liveness_video` del JSON). Requiere token. Puede ser null. */
    val livenessVideoUrl: String?,
    /** Ruta de archivo local del video ya descargado por el SDK. Listo para reproducir. Puede ser null. */
    val livenessVideoLocalPath: String?,

    /** Análisis de la IP desde la que se realizó la verificación. Puede ser null. */
    val ipAnalysis: KycIpAnalysis?,
    /** URL del PDF de la verificación (requiere token). Puede ser null. */
    val pdfUrl: String?,
    /** Razones de rechazo cuando el proceso no fue aprobado. Vacío si fue aprobado. */
    val rejectionReasons: List<String> = emptyList()
) : Parcelable {

    companion object {
        const val EXTRA_RESULT = "digid_kyc_result"
        const val EXTRA_ERROR = "digid_kyc_error"
    }

    /** true si el proceso fue exitoso y el usuario pasó todos los checks biométricos. */
    val isApproved: Boolean
        get() = success && faceMatch && livenessCheck && documentValid

    /**
     * Serializa el resultado a JSON (snake_case) para enviar al backend del cliente.
     *
     * Emite la misma estructura que el servidor y el SDK de iOS. Los recursos binarios
     * (bitmaps y el archivo local del video) NO se incluyen: son específicos del dispositivo.
     */
    fun toJson(): String {
        val verification = linkedMapOf<String, Any?>(
            "face_match" to faceMatch,
            "face_match_score" to faceMatchScore,
            "liveness_check" to livenessCheck,
            "liveness_score" to livenessScore,
            "document_valid" to documentValid
        )
        livenessMethod?.let { verification["liveness_method"] = it }
        ageEstimation?.let { verification["age_estimation"] = it }
        faceQuality?.let { verification["face_quality"] = it }

        val documentMap = linkedMapOf<String, Any?>(
            "document_type" to document.documentType,
            "document_number" to document.documentNumber,
            "personal_number" to document.personalNumber,
            "full_name" to document.fullName,
            "first_name" to document.firstName,
            "last_name" to document.lastName,
            "birth_date" to document.birthDate,
            "expiry_date" to document.expiryDate,
            "date_of_issue" to document.dateOfIssue,
            "nationality" to document.nationality,
            "gender" to document.gender,
            "place_of_birth" to document.placeOfBirth
        )
        document.age?.let { documentMap["age"] = it }
        document.address?.let { documentMap["address"] = it }
        document.addressData?.let { documentMap["address_data"] = it.toMap() }
        document.extraFieldsJson?.let { documentMap["extra_fields"] = parseJson(it) }

        val map = linkedMapOf<String, Any?>(
            "success" to success,
            "message" to message,
            "session_id" to sessionId,
            "vendor_data" to vendorData,
            "timestamp" to timestamp,
            "status" to status,
            "ready" to ready,
            "verification" to verification,
            "document" to documentMap
        )

        val images = linkedMapOf<String, Any?>()
        frontImageUrl?.let { images["front_image"] = it }
        backImageUrl?.let { images["back_image"] = it }
        selfieImageUrl?.let { images["selfie_image"] = it }
        portraitImageUrl?.let { images["portrait_image"] = it }
        if (images.isNotEmpty()) map["images"] = images

        ipAnalysis?.let { map["ip_analysis"] = it.toMap() }
        pdfUrl?.let { map["pdf_url"] = it }
        if (rejectionReasons.isNotEmpty()) map["rejection_reasons"] = rejectionReasons
        livenessVideoUrl?.let { map["liveness_video"] = it }

        return Gson().toJson(map)
    }

    /** Convierte un String JSON a un objeto Gson (para anidar extra_fields sin escaparlo). */
    private fun parseJson(raw: String): Any? = try {
        Gson().fromJson(raw, Any::class.java)
    } catch (e: Exception) {
        null
    }
}
