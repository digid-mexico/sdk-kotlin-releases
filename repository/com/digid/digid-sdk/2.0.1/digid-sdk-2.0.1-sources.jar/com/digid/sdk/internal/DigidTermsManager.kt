package com.digid.sdk.internal

import android.util.Log
import com.digid.sdk.DigidTermsConfig

/**
 * Gestiona el estado de aceptación de los Términos y Condiciones en memoria.
 *
 * La aceptación es válida durante la ventana TTL configurada. Al expirar, el usuario
 * deberá aceptar nuevamente antes de iniciar cualquier vista del SDK.
 *
 * El estado se mantiene en memoria (no en disco) por seguridad: al matar la app,
 * el estado se resetea y el usuario deberá aceptar de nuevo en el siguiente arranque.
 */
internal object DigidTermsManager {

    private const val TAG = "DigidTermsManager"

    @Volatile private var acceptedAtMs: Long? = null
    private var ttlMs: Long = DigidTermsConfig.DEFAULT_TTL_MS

    /**
     * Aplica la configuración del cliente. Llamar desde [com.digid.sdk.Digid.initialize].
     */
    fun configure(config: DigidTermsConfig) {
        ttlMs = config.acceptanceTtlMs
        DigidLog.d(TAG, "Configurado — TTL: ${ttlMs}ms")
    }

    /**
     * Devuelve `true` si existe una aceptación vigente (dentro del TTL).
     */
    fun isAccepted(): Boolean {
        val timestamp = acceptedAtMs ?: return false
        val elapsed = System.currentTimeMillis() - timestamp
        val valid = elapsed < ttlMs
        if (!valid) {
            DigidLog.d(TAG, "Aceptación expirada — elapsed: ${elapsed}ms, ttl: ${ttlMs}ms")
        }
        return valid
    }

    /**
     * Registra el momento de aceptación. Llamar cuando el usuario acepta los T&C.
     */
    fun markAccepted() {
        acceptedAtMs = System.currentTimeMillis()
        DigidLog.d(TAG, "T&C aceptados en: $acceptedAtMs")
    }

    /**
     * Invalida la aceptación vigente, forzando que el usuario acepte de nuevo.
     * Útil para implementar funcionalidad de "cerrar sesión" desde la app cliente.
     */
    fun reset() {
        acceptedAtMs = null
        DigidLog.d(TAG, "Estado de aceptación reseteado")
    }
}
