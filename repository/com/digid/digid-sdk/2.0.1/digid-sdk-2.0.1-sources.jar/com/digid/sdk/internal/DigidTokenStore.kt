package com.digid.sdk.internal

import android.content.Context
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Almacena el token de acceso cifrado con EncryptedSharedPreferences (AES256-GCM),
 * respaldado por Android Keystore. El token nunca se guarda en texto claro en disco.
 */
internal object DigidTokenStore {

    private const val TAG = "DigidTokenStore"
    private const val PREFS_FILE = "digid_secure_prefs"
    private const val KEY_TOKEN = "digid_access_token"

    private var encryptedPrefs: android.content.SharedPreferences? = null

    fun initialize(context: Context) {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            encryptedPrefs = EncryptedSharedPreferences.create(
                context,
                PREFS_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            DigidLog.e(TAG, "Error al inicializar almacenamiento seguro: ${e.message}", e)
            throw RuntimeException("No se pudo inicializar el almacenamiento seguro del token.", e)
        }
    }

    fun storeToken(token: String) {
        encryptedPrefs?.edit()?.putString(KEY_TOKEN, token)?.apply()
            ?: DigidLog.e(TAG, "EncryptedSharedPreferences no inicializado")
    }

    fun getToken(): String? = encryptedPrefs?.getString(KEY_TOKEN, null)

    fun clearToken() {
        encryptedPrefs?.edit()?.remove(KEY_TOKEN)?.apply()
    }
}
