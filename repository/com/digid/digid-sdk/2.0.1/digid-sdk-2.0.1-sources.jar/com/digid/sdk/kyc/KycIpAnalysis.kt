package com.digid.sdk.kyc

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Análisis de la IP desde la que se realizó la verificación.
 */
@Parcelize
data class KycIpAnalysis(
    /** Dirección IP detectada. */
    val ipAddress: String?,
    /** Ciudad estimada por geolocalización de IP. */
    val ipCity: String?,
    /** Estado/región estimado por geolocalización de IP. */
    val ipState: String?,
    /** País estimado por geolocalización de IP. */
    val ipCountry: String?,
    /** true si la IP corresponde a una VPN o red Tor. Puede ser null. */
    val isVpnOrTor: Boolean?
) : Parcelable {

    /** Representación snake_case para el JSON del resultado. */
    internal fun toMap(): Map<String, Any?> {
        val map = linkedMapOf<String, Any?>()
        ipAddress?.let { map["ip_address"] = it }
        ipCity?.let { map["ip_city"] = it }
        ipState?.let { map["ip_state"] = it }
        ipCountry?.let { map["ip_country"] = it }
        isVpnOrTor?.let { map["is_vpn_or_tor"] = it }
        return map
    }
}
