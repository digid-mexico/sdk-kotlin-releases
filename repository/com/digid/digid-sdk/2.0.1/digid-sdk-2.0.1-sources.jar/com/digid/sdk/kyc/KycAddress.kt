package com.digid.sdk.kyc

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Domicilio estructurado extraído del documento de identidad.
 */
@Parcelize
data class KycAddress(
    /** Domicilio completo en una sola cadena. */
    val fullAddress: String?,
    /** Calle y número. */
    val street: String?,
    /** Ciudad o municipio. */
    val city: String?,
    /** Estado o región. */
    val state: String?,
    /** Código postal. */
    val postalCode: String?,
    /** País emisor del documento. */
    val country: String?,
    /** true si el domicilio pudo desglosarse por partes a partir del documento. */
    val addressParsed: Boolean,
    /** Advertencia cuando no fue posible desglosar el domicilio. Puede ser null. */
    val addressWarning: String?
) : Parcelable {

    /** Representación snake_case para el JSON del resultado. */
    internal fun toMap(): Map<String, Any?> {
        val map = linkedMapOf<String, Any?>("address_parsed" to addressParsed)
        fullAddress?.let { map["full_address"] = it }
        street?.let { map["street"] = it }
        city?.let { map["city"] = it }
        state?.let { map["state"] = it }
        postalCode?.let { map["postal_code"] = it }
        country?.let { map["country"] = it }
        addressWarning?.let { map["address_warning"] = it }
        return map
    }
}
