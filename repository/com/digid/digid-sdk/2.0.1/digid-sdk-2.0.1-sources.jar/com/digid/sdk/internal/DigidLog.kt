package com.digid.sdk.internal

import android.util.Log
import com.digid.sdk.Digid

/**
 * Logger interno del SDK.
 *
 * Solo emite salida cuando [Digid.verboseLogging] está activo. Así el SDK no ensucia
 * el logcat de las apps cliente en producción; el desarrollador decide si quiere ver
 * los logs para depurar.
 */
internal object DigidLog {
    fun d(tag: String, message: String) {
        if (Digid.verboseLogging) Log.d(tag, message)
    }

    fun i(tag: String, message: String) {
        if (Digid.verboseLogging) Log.i(tag, message)
    }

    fun w(tag: String, message: String) {
        if (Digid.verboseLogging) Log.w(tag, message)
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (!Digid.verboseLogging) return
        if (throwable != null) Log.e(tag, message, throwable) else Log.e(tag, message)
    }
}
