package com.digid.sdk.internal

import com.digid.sdk.kyc.KycAddress
import com.digid.sdk.kyc.KycDocument
import com.digid.sdk.kyc.KycIpAnalysis
import com.digid.sdk.kyc.KycResult
import java.time.Instant

internal object KycResultMapper {

    fun mapFromInternal(
        kycResult: InternalKycResult,
        vendorData: String,
        sessionId: String
    ): KycResult = KycResult(
        success = kycResult.success,
        message = if (kycResult.success) "Verificación completada." else "Verificación finalizada con observaciones.",
        sessionId = sessionId,
        vendorData = vendorData,
        timestamp = Instant.now().toString(),
        status = kycResult.status,
        ready = kycResult.ready,
        faceMatch = kycResult.faceMatch,
        faceMatchScore = kycResult.faceMatchScore,
        livenessCheck = kycResult.livenessCheck,
        livenessScore = kycResult.livenessScore,
        documentValid = kycResult.documentValid,
        livenessMethod = kycResult.livenessMethod,
        ageEstimation = kycResult.ageEstimation,
        faceQuality = kycResult.faceQuality,
        document = KycDocument(
            documentType = kycResult.documentType,
            documentNumber = kycResult.documentNumber,
            fullName = kycResult.fullName,
            firstName = kycResult.firstName,
            lastName = kycResult.lastName,
            birthDate = kycResult.birthDate,
            expiryDate = kycResult.expiryDate,
            personalNumber = kycResult.personalNumber,
            dateOfIssue = kycResult.dateOfIssue,
            nationality = kycResult.nationality,
            gender = kycResult.gender,
            age = kycResult.age,
            placeOfBirth = kycResult.placeOfBirth,
            address = kycResult.address,
            addressData = kycResult.addressData?.let {
                KycAddress(
                    fullAddress = it.fullAddress,
                    street = it.street,
                    city = it.city,
                    state = it.state,
                    postalCode = it.postalCode,
                    country = it.country,
                    addressParsed = it.addressParsed ?: false,
                    addressWarning = it.addressWarning
                )
            },
            extraFieldsJson = kycResult.extraFieldsJson
        ),
        frontImage = kycResult.frontImage,
        backImage = kycResult.backImage,
        selfieImage = kycResult.selfieImage,
        portraitImage = kycResult.portraitImage,
        frontImageUrl = kycResult.frontImageUrl,
        backImageUrl = kycResult.backImageUrl,
        selfieImageUrl = kycResult.selfieImageUrl,
        portraitImageUrl = kycResult.portraitImageUrl,
        livenessVideoUrl = kycResult.livenessVideoUrl,
        livenessVideoLocalPath = kycResult.livenessVideoLocalPath,
        ipAnalysis = kycResult.ipAnalysis?.let {
            KycIpAnalysis(
                ipAddress = it.ipAddress,
                ipCity = it.ipCity,
                ipState = it.ipState,
                ipCountry = it.ipCountry,
                isVpnOrTor = it.isVpnOrTor
            )
        },
        pdfUrl = kycResult.pdfUrl,
        rejectionReasons = kycResult.rejectionReasons
    )
}
