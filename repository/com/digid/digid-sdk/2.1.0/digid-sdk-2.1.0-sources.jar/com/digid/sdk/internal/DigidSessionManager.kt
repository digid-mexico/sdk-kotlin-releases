package com.digid.sdk.internal

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import com.digid.sdk.BuildConfig
import com.digid.sdk.Digid
import com.digid.sdk.DigidEnvironment
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import me.didit.sdk.DiditSdk
import me.didit.sdk.DiditSdkState
import me.didit.sdk.Configuration
import me.didit.sdk.VerificationResult
import me.didit.sdk.core.localization.SupportedLanguage
import java.io.ByteArrayOutputStream

/**
 * Capa de abstracción entre la API pública de Digid y el SDK de verificación externo.
 *
 * Flujo completo:
 * 1. POST /sdk/auth → backend valida token, verifica folios, genera session token.
 * 2. Inicia verificación biométrica con el SDK externo.
 * 3. Al completar, el SDK retorna sessionId y status.
 * 4. GET /sdk/verification/{sessionId} (polling) → datos completos llegan vía webhook al backend.
 * 5. Cuando ready=true, descarga imágenes y construye resultado final.
 */
internal object DigidSessionManager {

    private const val TAG = "DigidSessionManager"

    private var isInitialized = false
    private lateinit var environment: DigidEnvironment

    private var currentSessionToken: String? = null
    private var currentSessionData: KycSessionData? = null
    private var currentVendorData: String? = null
    private var currentCallback: KycFlowCallback? = null

    // Prevents callbacks from reaching a destroyed Activity when auth takes
    // longer than the Activity lifecycle. Set to true by cancelCurrentSession().
    @Volatile private var isCancelled = false

    private const val POLLING_INTERVAL_MS = 3000L
    private const val MAX_POLLING_ATTEMPTS = 20

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pollingAttempts = 0
    private var stateObserverJob: Job? = null

    internal interface KycFlowCallback {
        fun onAuthorizationComplete()
        fun onAuthorizationError(error: DigidException)
        fun onVerificationComplete(result: InternalKycResult)
        fun onVerificationCancelled()
        fun onVerificationError(error: DigidException)
    }

    fun initialize(context: Context, token: String, environment: DigidEnvironment) {
        this.environment = environment
        DiditSdk.initialize(context)
        isInitialized = true
        DigidLog.d(TAG, "Servicio de verificación inicializado. Ambiente: $environment")
    }

    /**
     * Solicita autorización al backend y, si es exitosa, lanza el flujo de verificación.
     * Se ejecuta en background; los callbacks se entregan en el hilo principal.
     */
    fun authorizeAndStartVerification(
        activity: Activity,
        vendorData: String,
        sessionId: String?,
        callback: KycFlowCallback
    ) {
        check(isInitialized) { "DigidSessionManager no inicializado" }

        isCancelled = false
        this.currentCallback = callback
        this.currentVendorData = vendorData

        DigidLog.d(TAG, "Solicitando autorización al backend...")

        Thread {
            try {
                val authResponse = DigidAPIClient.authorizeKycSession(Digid.clientId, sessionId)

                val sessionData = authResponse.session
                    ?: throw DigidException(
                        DigidErrorCode.VERIFICATION_SERVICE_ERROR,
                        "El servidor no devolvió datos de sesión válidos."
                    )

                currentSessionToken = sessionData.sessionToken
                currentSessionData = sessionData

                DigidLog.d(TAG, "Autorización exitosa. Folios: ${authResponse.clientInfo?.remainingFolios ?: 0}")

                mainHandler.post {
                    if (isCancelled) return@post
                    callback.onAuthorizationComplete()
                    launchVerification(activity, sessionData.sessionToken)
                }

            } catch (e: DigidException) {
                DigidLog.e(TAG, "Error de autorización: ${e.code} - ${e.message}")
                mainHandler.post { callback.onAuthorizationError(e) }
            } catch (e: Exception) {
                DigidLog.e(TAG, "Error inesperado en autorización: ${e.message}", e)
                mainHandler.post {
                    callback.onAuthorizationError(
                        DigidException(DigidErrorCode.NETWORK_ERROR, "Error de conexión con el servidor.", e.message)
                    )
                }
            }
        }.start()
    }

    /**
     * Inicia la verificación con el SDK externo.
     * Observa el StateFlow del SDK y lanza la UI solo cuando el estado sea Ready.
     */
    private fun launchVerification(activity: Activity, sessionToken: String) {
        // Los logs del motor de verificación están apagados por defecto (sandbox y
        // producción) e independientes de verboseLogging; solo con engineLoggingEnabled.
        val config = Configuration(
            languageLocale = SupportedLanguage.SPANISH,
            loggingEnabled = Digid.engineLoggingEnabled
        )

        DiditSdk.startVerification(token = sessionToken, configuration = config) { result ->
            handleVerificationResult(activity, result)
        }

        stateObserverJob?.cancel()
        stateObserverJob = CoroutineScope(Dispatchers.Main).launch {
            DiditSdk.state.collectLatest { state ->
                DigidLog.d(TAG, "Estado del servicio de verificación: $state")
                when (state) {
                    is DiditSdkState.Ready -> {
                        DigidLog.d(TAG, "Servicio listo — lanzando UI de verificación")
                        DiditSdk.launchVerificationUI(activity)
                        stateObserverJob?.cancel()
                    }
                    is DiditSdkState.Error -> {
                        val errorMsg = state.message ?: "Error al inicializar verificación"
                        DigidLog.e(TAG, "Error en servicio de verificación: $errorMsg")
                        stateObserverJob?.cancel()
                        currentCallback?.onVerificationError(
                            DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, "Error en el servicio de verificación: $errorMsg")
                        )
                        currentCallback = null
                    }
                    else -> DigidLog.d(TAG, "Estado transitorio: $state")
                }
            }
        }
    }

    private fun handleVerificationResult(activity: Activity, result: VerificationResult) {
        when (result) {
            is VerificationResult.Completed -> {
                val sessionId = result.session.sessionId
                val verificationStatus = result.session.status.rawValue
                DigidLog.d(TAG, "Verificación completada — Status: $verificationStatus, Session: $sessionId")
                pollingAttempts = 0
                startPolling(sessionId, verificationStatus)
            }
            is VerificationResult.Cancelled -> {
                DigidLog.d(TAG, "Verificación cancelada por el usuario")
                cleanupSession()
                mainHandler.post {
                    currentCallback?.onVerificationCancelled()
                    currentCallback = null
                }
            }
            is VerificationResult.Failed -> {
                val errorMsg = result.error.message ?: "Error durante la verificación"
                DigidLog.e(TAG, "Verificación fallida: $errorMsg")
                cleanupSession()
                mainHandler.post {
                    currentCallback?.onVerificationError(
                        DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, "Error en el servicio de verificación: $errorMsg")
                    )
                    currentCallback = null
                }
            }
        }
    }

    /**
     * Polling al backend para obtener datos completos de la verificación.
     * Los datos llegan al backend vía webhook del servicio externo.
     * Intervalo: 3s | Máximo: 20 intentos (60s total). Timeout retorna resultado parcial.
     */
    private fun startPolling(sessionId: String, verificationStatus: String) {
        Thread { executePollAttempt(sessionId, verificationStatus) }.start()
    }

    private fun executePollAttempt(sessionId: String, verificationStatus: String) {
        if (isCancelled) return

        pollingAttempts++
        DigidLog.d(TAG, "Polling intento $pollingAttempts/$MAX_POLLING_ATTEMPTS para sesión: $sessionId")

        if (pollingAttempts > MAX_POLLING_ATTEMPTS) {
            DigidLog.w(TAG, "Polling timeout — devolviendo resultado parcial")
            mainHandler.post {
                if (!isCancelled) returnFallbackResult(sessionId, verificationStatus)
            }
            return
        }

        try {
            val pollingResponse = DigidAPIClient.pollVerificationResult(sessionId)

            if (pollingResponse.ready) {
                DigidLog.d(TAG, "Datos completos recibidos (intento $pollingAttempts)")
                mainHandler.post {
                    if (!isCancelled) handlePollingSuccess(pollingResponse, sessionId)
                }
            } else {
                DigidLog.d(TAG, "Datos aún no listos: ${pollingResponse.message ?: "esperando webhook"}")
                mainHandler.postDelayed({
                    Thread { executePollAttempt(sessionId, verificationStatus) }.start()
                }, POLLING_INTERVAL_MS)
            }
        } catch (e: Exception) {
            DigidLog.w(TAG, "Error en polling: ${e.message} — continuando...")
            mainHandler.postDelayed({
                Thread { executePollAttempt(sessionId, verificationStatus) }.start()
            }, POLLING_INTERVAL_MS)
        }
    }

    private fun handlePollingSuccess(pollingResponse: KycPollingResponse, sessionId: String) {
        // Se devuelve el vendor_data que persiste el backend (mismo valor que el
        // API); el identificador local del integrador solo es respaldo.
        val vendorData = pollingResponse.vendorData ?: currentVendorData ?: ""
        val isApproved = pollingResponse.status.lowercase() == "approved"

        Thread {
            // Descarga imágenes y video de liveness (ambos requieren token).
            val downloadedImages = pollingResponse.images?.let {
                DigidAPIClient.downloadVerificationImages(it)
            } ?: emptyMap()
            val livenessVideoLocalPath =
                DigidAPIClient.downloadLivenessVideo(pollingResponse.livenessVideo, sessionId)

            val verification = pollingResponse.verification
            val document = pollingResponse.document
            val images = pollingResponse.images

            val internalResult = InternalKycResult(
                success = true,
                status = pollingResponse.status,
                ready = true,
                sessionId = sessionId,
                vendorData = vendorData,
                faceMatch = verification?.faceMatch ?: isApproved,
                faceMatchScore = verification?.faceMatchScore ?: if (isApproved) 100.0 else 0.0,
                livenessCheck = verification?.livenessCheck ?: isApproved,
                livenessScore = verification?.livenessScore ?: if (isApproved) 100.0 else 0.0,
                documentValid = verification?.documentValid ?: isApproved,
                livenessMethod = verification?.livenessMethod,
                ageEstimation = verification?.ageEstimation,
                faceQuality = verification?.faceQuality,
                documentType = document?.documentType ?: "",
                documentNumber = document?.documentNumber ?: "",
                personalNumber = document?.personalNumber ?: "",
                fullName = document?.fullName ?: "",
                firstName = document?.firstName ?: "",
                lastName = document?.lastName ?: "",
                birthDate = document?.birthDate ?: "",
                expiryDate = document?.expiryDate ?: "",
                dateOfIssue = document?.dateOfIssue ?: "",
                nationality = document?.nationality ?: "",
                gender = document?.gender ?: "",
                age = document?.age,
                placeOfBirth = document?.placeOfBirth ?: "",
                // El servidor envía el domicilio en address_data.full_address; se prioriza sobre el campo plano.
                address = document?.addressData?.fullAddress ?: document?.address,
                addressData = document?.addressData,
                extraFieldsJson = document?.extraFieldsJson,
                frontImage = downloadedImages["front"],
                backImage = downloadedImages["back"],
                selfieImage = downloadedImages["selfie"],
                portraitImage = downloadedImages["portrait"],
                frontImageUrl = images?.frontImage,
                backImageUrl = images?.backImage,
                selfieImageUrl = images?.selfieImage,
                portraitImageUrl = images?.portraitImage,
                livenessVideoUrl = pollingResponse.livenessVideo,
                livenessVideoLocalPath = livenessVideoLocalPath,
                ipAnalysis = pollingResponse.ipAnalysis,
                pdfUrl = pollingResponse.pdfUrl,
                createdAt = pollingResponse.createdAt,
                updatedAt = pollingResponse.updatedAt,
                rejectionReasons = pollingResponse.rejectionReasons ?: emptyList()
            )

            mainHandler.post {
                cleanupSession()
                currentCallback?.onVerificationComplete(internalResult)
                currentCallback = null
            }
        }.start()
    }

    private fun returnFallbackResult(sessionId: String, verificationStatus: String) {
        val isApproved = verificationStatus.lowercase() == "approved"

        val fallbackResult = InternalKycResult(
            success = true,
            status = verificationStatus,
            ready = false,
            sessionId = sessionId,
            vendorData = currentVendorData ?: "",
            faceMatch = isApproved,
            faceMatchScore = if (isApproved) 100.0 else 0.0,
            livenessCheck = isApproved,
            livenessScore = if (isApproved) 100.0 else 0.0,
            documentValid = isApproved,
            livenessMethod = null, ageEstimation = null, faceQuality = null,
            documentType = "", documentNumber = "", personalNumber = "", fullName = "",
            firstName = "", lastName = "", birthDate = "", expiryDate = "", dateOfIssue = "",
            nationality = "", gender = "", age = null, placeOfBirth = "", address = null,
            addressData = null, extraFieldsJson = null,
            frontImage = null, backImage = null, selfieImage = null, portraitImage = null,
            frontImageUrl = null, backImageUrl = null, selfieImageUrl = null, portraitImageUrl = null,
            livenessVideoUrl = null, livenessVideoLocalPath = null,
            ipAnalysis = null, pdfUrl = null,
            createdAt = null, updatedAt = null,
            rejectionReasons = emptyList()
        )

        DigidLog.w(TAG, "Retornando resultado parcial (sin datos del webhook)")
        cleanupSession()
        currentCallback?.onVerificationComplete(fallbackResult)
        currentCallback = null
    }

    /**
     * Cancela la sesión activa, silenciando cualquier callback pendiente.
     * Llamar desde onDestroy/onPause de la Activity para evitar callbacks sobre
     * un contexto ya destruido.
     */
    fun cancelCurrentSession() {
        isCancelled = true
        cleanupSession()
        DigidLog.d(TAG, "Sesión cancelada externamente.")
    }

    private fun cleanupSession() {
        stateObserverJob?.cancel()
        stateObserverJob = null
        currentSessionToken = null
        currentSessionData = null
        currentVendorData = null
        pollingAttempts = 0
        DigidLog.d(TAG, "Sesión de verificación limpiada.")
    }
}

internal data class InternalKycResult(
    val success: Boolean,
    val status: String,
    val ready: Boolean,
    val sessionId: String,
    val vendorData: String,
    val faceMatch: Boolean,
    val faceMatchScore: Double,
    val livenessCheck: Boolean,
    val livenessScore: Double,
    val documentValid: Boolean,
    val livenessMethod: String?,
    val ageEstimation: Double?,
    val faceQuality: Double?,
    val documentType: String,
    val documentNumber: String,
    val personalNumber: String,
    val fullName: String,
    val firstName: String,
    val lastName: String,
    val birthDate: String,
    val expiryDate: String,
    val dateOfIssue: String,
    val nationality: String,
    val gender: String,
    val age: Int?,
    val placeOfBirth: String,
    val address: String?,
    val addressData: KycAddressData?,
    val extraFieldsJson: String?,
    val frontImage: Bitmap?,
    val backImage: Bitmap?,
    val selfieImage: Bitmap?,
    val portraitImage: Bitmap?,
    val frontImageUrl: String?,
    val backImageUrl: String?,
    val selfieImageUrl: String?,
    val portraitImageUrl: String?,
    val livenessVideoUrl: String?,
    val livenessVideoLocalPath: String?,
    val ipAnalysis: KycIpAnalysisData?,
    val pdfUrl: String?,
    val createdAt: String?,
    val updatedAt: String?,
    val rejectionReasons: List<String>
)
