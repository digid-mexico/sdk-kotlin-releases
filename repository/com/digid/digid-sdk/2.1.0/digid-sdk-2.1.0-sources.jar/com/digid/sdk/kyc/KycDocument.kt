package com.digid.sdk.kyc

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Datos del documento de identidad extraídos durante el proceso KYC.
 * Corresponde a ID(Ine), Pasaporte o Licencia de conducir.
 */
@Parcelize
data class KycDocument(
    /** Tipo de documento: "Identity Card", "PASSPORT", "DRIVER_LICENSE". */
    val documentType: String,

    /** Número único del documento o CURP. */
    val documentNumber: String,

    /** Nombre completo tal como aparece en el documento. */
    val fullName: String,

    /** Nombre(s) del titular. */
    val firstName: String,

    /** Apellidos del titular. */
    val lastName: String,

    /** Fecha de nacimiento en formato YYYY-MM-DD. */
    val birthDate: String,

    /** Fecha de vencimiento del documento en formato YYYY-MM-DD. */
    val expiryDate: String,

    /** Número personal del documento (ej. CURP/NSS según el documento). Vacío si no está disponible. */
    val personalNumber: String,

    /** Fecha de emisión del documento en formato YYYY-MM-DD. Vacío si no está disponible. */
    val dateOfIssue: String,

    /** Código de nacionalidad ISO 3166. Ej: "MEX". */
    val nationality: String,

    /** Género: "M" o "F". */
    val gender: String,

    /** Edad del titular. Puede ser null si no está disponible. */
    val age: Int?,

    /** Lugar de nacimiento. Vacío si no está disponible. */
    val placeOfBirth: String,

    /**
     * Domicilio estructurado por partes (calle, ciudad, estado, etc.). Puede ser null.
     * El domicilio completo está en [KycAddress.fullAddress].
     */
    val addressData: KycAddress?,

    /** Campos OCR adicionales en formato JSON crudo. Puede ser null. */
    val extraFieldsJson: String?
) : Parcelable
