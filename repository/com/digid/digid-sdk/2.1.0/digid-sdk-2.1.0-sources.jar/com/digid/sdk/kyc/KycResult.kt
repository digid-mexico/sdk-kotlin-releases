package com.digid.sdk.kyc

import android.graphics.Bitmap
import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import kotlinx.parcelize.Parcelize

/**
 * Resultado completo del proceso de verificación KYC.
 *
 * [success] indica que el proceso completó sin errores técnicos.
 * [faceMatch] y [livenessCheck] indican si el usuario pasó la verificación biométrica.
 * Es posible que [success] sea true pero [faceMatch] sea false (el proceso funcionó
 * pero el usuario no pasó la verificación).
 *
 * Usa [isApproved] para determinar si el usuario fue verificado exitosamente.
 *
 * El SDK descarga automáticamente las imágenes ([frontImage], [backImage], [selfieImage],
 * [portraitImage]) y el video de liveness ([livenessVideoLocalPath]). Además conserva las
 * URLs remotas ([frontImageUrl], etc., [livenessVideoUrl]) por si necesitas descargarlas
 * más tarde (requieren el token de acceso).
 */
@Parcelize
data class KycResult(
    val success: Boolean,
    val message: String,
    val sessionId: String,
    /** Identificador del usuario en el sistema del cliente. */
    val vendorData: String,
    /** Inicio del proceso KYC (ISO 8601). Corresponde a `created_at` del servidor. Puede ser null. */
    val createdAt: String?,
    /** Fin del proceso KYC (ISO 8601). Corresponde a `updated_at` del servidor. Puede ser null. */
    val updatedAt: String?,
    /** Estado reportado por el servidor: "Approved", "Declined", "In Review". */
    val status: String,
    /** true cuando los datos de la verificación están completos y listos para consumirse. */
    val ready: Boolean,
    val faceMatch: Boolean,
    /** Similitud facial (0-100). Se recomienda aprobar a partir de 80. */
    val faceMatchScore: Double,
    val livenessCheck: Boolean,
    /** Confianza de prueba de vida (0-100). Se recomienda aprobar a partir de 80. */
    val livenessScore: Double,
    val documentValid: Boolean,
    /** Método de prueba de vida usado (ej. "PASSIVE"). Puede ser null. */
    val livenessMethod: String?,
    /** Edad estimada por análisis facial (0-100). Puede ser null. */
    val ageEstimation: Double?,
    /** Calidad de la imagen facial (0-100). Puede ser null. */
    val faceQuality: Double?,
    val document: KycDocument,

    // ─── Recursos multimedia ya descargados (listos para usar) ───
    /** Foto frontal del documento. Puede ser null si no está disponible. */
    val frontImage: Bitmap?,
    /** Foto del reverso del documento. Puede ser null si no está disponible. */
    val backImage: Bitmap?,
    /** Selfie del usuario. Puede ser null si no está disponible. */
    val selfieImage: Bitmap?,
    /** Retrato extraído del documento. Puede ser null si no está disponible. */
    val portraitImage: Bitmap?,

    // ─── URLs remotas (del JSON; requieren token para descargarse) ───
    val frontImageUrl: String?,
    val backImageUrl: String?,
    val selfieImageUrl: String?,
    val portraitImageUrl: String?,

    // ─── Video de liveness ───
    /** URL remota del video (campo `liveness_video` del JSON). Requiere token. Puede ser null. */
    val livenessVideoUrl: String?,
    /** Ruta de archivo local del video ya descargado por el SDK. Listo para reproducir. Puede ser null. */
    val livenessVideoLocalPath: String?,

    /** Análisis de la IP desde la que se realizó la verificación. Puede ser null. */
    val ipAnalysis: KycIpAnalysis?,
    /** URL del PDF de la verificación (requiere token). Puede ser null. */
    val pdfUrl: String?,
    /** Razones de rechazo cuando el proceso no fue aprobado. Vacío si fue aprobado. */
    val rejectionReasons: List<String> = emptyList()
) : Parcelable {

    companion object {
        const val EXTRA_RESULT = "digid_kyc_result"
        const val EXTRA_ERROR = "digid_kyc_error"
    }

    /** true si el proceso fue exitoso y el usuario pasó todos los checks biométricos. */
    val isApproved: Boolean
        get() = success && faceMatch && livenessCheck && documentValid

    /**
     * Serializa el resultado a JSON (snake_case) para enviar al backend del cliente.
     *
     * Emite la misma estructura que el servidor y el SDK de iOS. Los recursos binarios
     * (bitmaps y el archivo local del video) NO se incluyen: son específicos del dispositivo.
     */
    fun toJson(): String {
        // Contrato de claves fijas (igual que el API): las claves siempre están
        // presentes y los valores ausentes se emiten como null, para que un mismo
        // parser del cliente funcione idéntico contra el SDK y contra el API.
        val verification = linkedMapOf<String, Any?>(
            "face_match" to faceMatch,
            "face_match_score" to faceMatchScore,
            "liveness_check" to livenessCheck,
            "liveness_score" to livenessScore,
            "document_valid" to documentValid,
            "liveness_method" to livenessMethod,
            "age_estimation" to ageEstimation,
            "face_quality" to faceQuality
        )

        val documentMap = linkedMapOf<String, Any?>(
            "document_type" to document.documentType,
            "document_number" to document.documentNumber,
            "personal_number" to document.personalNumber,
            "full_name" to document.fullName,
            "first_name" to document.firstName,
            "last_name" to document.lastName,
            "birth_date" to document.birthDate,
            "expiry_date" to document.expiryDate,
            "date_of_issue" to document.dateOfIssue,
            "nationality" to document.nationality,
            "gender" to document.gender,
            "age" to document.age,
            "place_of_birth" to document.placeOfBirth,
            "address_data" to document.addressData?.toMap(),
            "extra_fields" to document.extraFieldsJson?.let { parseJson(it) }
        )

        val map = linkedMapOf<String, Any?>(
            "success" to success,
            "message" to message,
            "session_id" to sessionId,
            "vendor_data" to vendorData,
            "created_at" to createdAt,
            "updated_at" to updatedAt,
            "status" to status,
            "ready" to ready,
            "verification" to verification,
            "document" to documentMap
        )

        // El bloque solo se omite cuando no hubo imágenes (ej. sesión rechazada);
        // si existe, lleva las 4 claves fijas.
        val hasAnyImage = frontImageUrl != null || backImageUrl != null
            || selfieImageUrl != null || portraitImageUrl != null
        if (hasAnyImage) {
            map["images"] = linkedMapOf<String, Any?>(
                "front_image" to frontImageUrl,
                "back_image" to backImageUrl,
                "selfie_image" to selfieImageUrl,
                "portrait_image" to portraitImageUrl
            )
        }

        ipAnalysis?.let { map["ip_analysis"] = it.toMap() }
        pdfUrl?.let { map["pdf_url"] = it }
        if (rejectionReasons.isNotEmpty()) map["rejection_reasons"] = rejectionReasons
        livenessVideoUrl?.let { map["liveness_video"] = it }

        // serializeNulls: Gson descarta los null por defecto; el contrato de
        // claves fijas exige emitirlos.
        return GsonBuilder().serializeNulls().create().toJson(map)
    }

    /** Convierte un String JSON a un objeto Gson (para anidar extra_fields sin escaparlo). */
    private fun parseJson(raw: String): Any? = try {
        Gson().fromJson(raw, Any::class.java)
    } catch (e: Exception) {
        null
    }
}
