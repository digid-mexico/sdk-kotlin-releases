package com.digid.sdk.kyc

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Domicilio estructurado extraído del documento de identidad.
 */
@Parcelize
data class KycAddress(
    /** Domicilio completo en una sola cadena. */
    val fullAddress: String?,
    /** Calle y número. */
    val street: String?,
    /** Ciudad o municipio. */
    val city: String?,
    /** Estado o región. */
    val state: String?,
    /** Código postal. */
    val postalCode: String?,
    /** País emisor del documento. */
    val country: String?,
    /** true si el domicilio pudo desglosarse por partes a partir del documento. */
    val addressParsed: Boolean,
    /** Advertencia cuando no fue posible desglosar el domicilio. Puede ser null. */
    val addressWarning: String?
) : Parcelable {

    /** Representación snake_case para el JSON del resultado (claves fijas, igual que el API). */
    internal fun toMap(): Map<String, Any?> = linkedMapOf(
        "full_address" to fullAddress,
        "street" to street,
        "city" to city,
        "state" to state,
        "postal_code" to postalCode,
        "country" to country,
        "address_parsed" to addressParsed,
        "address_warning" to addressWarning
    )
}
