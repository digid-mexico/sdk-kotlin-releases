package com.digid.sdk

import androidx.annotation.DrawableRes

/**
 * Configuración visual del SDK de Digid.
 *
 * Se aplica globalmente a todas las vistas del SDK (KYC y Firma).
 * La personalización está limitada a colores y logo para garantizar
 * la consistencia legal y de experiencia de usuario.
 *
 * @property primaryColor Color principal en formato hexadecimal (#RRGGBB).
 *   Se aplica a botones de acción (Confirmar, Continuar, Aceptar),
 *   indicadores de progreso y elementos de énfasis.
 * @property secondaryColor Color secundario en formato hexadecimal (#RRGGBB).
 *   Se aplica a botones alternativos (Limpiar firma, Reintentar)
 *   y bordes de campos activos.
 * @property backgroundColor Color de fondo en formato hexadecimal (#RRGGBB).
 *   Se recomienda blanco (#FFFFFF) para garantizar legibilidad.
 * @property logoResId Resource ID del logo de la empresa (opcional).
 *   Si se omite, se muestra el logo de Digid.
 */
data class DigidTheme(
    val primaryColor: String = "#1A3C6E",
    val secondaryColor: String = "#2D8CF0",
    val backgroundColor: String = "#FFFFFF",
    @DrawableRes val logoResId: Int? = null
) {
    init {
        require(primaryColor.matches(HEX_COLOR_REGEX)) {
            "primaryColor debe ser un color hexadecimal válido (ej: #1A3C6E)"
        }
        require(secondaryColor.matches(HEX_COLOR_REGEX)) {
            "secondaryColor debe ser un color hexadecimal válido (ej: #2D8CF0)"
        }
        require(backgroundColor.matches(HEX_COLOR_REGEX)) {
            "backgroundColor debe ser un color hexadecimal válido (ej: #FFFFFF)"
        }
    }

    companion object {
        private val HEX_COLOR_REGEX = Regex("^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$")
    }
}
