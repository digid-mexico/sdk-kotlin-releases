package com.digid.sdk.signature

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Resultado de la Vista 3 — Aplicación de Firmas al Documento.
 *
 * Incluye cuántos puntos se firmaron y cuántos requería el documento.
 * Si el usuario canceló antes de completar todos los puntos,
 * success será false y signaturesApplied < signaturesRequired.
 */
@Parcelize
data class SignatureApplyResult(
    /** true si todos los puntos de firma fueron aceptados y el documento fue firmado en el servidor. */
    val success: Boolean,
    /** Mensaje descriptivo. */
    val message: String,
    /** Número de puntos de firma completados. */
    val signaturesApplied: Int,
    /** Total de puntos de firma que requería el documento. */
    val signaturesRequired: Int
) : Parcelable {
    companion object {
        const val EXTRA_RESULT = "digid_signature_apply_result"
        const val EXTRA_ERROR = "digid_signature_apply_error"
    }

    /** true si el documento fue firmado completamente. */
    val isFullySigned: Boolean get() = success && signaturesApplied == signaturesRequired

    fun toJson(): String = """{"success":$success,"message":"$message","signatures_applied":$signaturesApplied,"signatures_required":$signaturesRequired}"""
}
