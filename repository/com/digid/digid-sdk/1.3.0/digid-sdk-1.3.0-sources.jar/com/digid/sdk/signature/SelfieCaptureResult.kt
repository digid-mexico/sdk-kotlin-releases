package com.digid.sdk.signature

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import org.json.JSONObject

@Parcelize
data class SelfieCaptureResult(
    val success: Boolean,
    val message: String
) : Parcelable {

    companion object {
        const val EXTRA_RESULT = "digid_selfie_capture_result"
        const val EXTRA_ERROR = "digid_selfie_capture_error"
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("success", success)
        put("message", message)
    }
}
