package com.digid.sdk.kyc

import android.os.Parcelable
import com.google.gson.Gson
import kotlinx.parcelize.Parcelize

/**
 * Resultado completo del proceso de verificación KYC.
 *
 * [success] indica que el proceso completó sin errores técnicos.
 * [faceMatch] y [livenessCheck] indican si el usuario pasó la verificación biométrica.
 * Es posible que [success] sea true pero [faceMatch] sea false (el proceso funcionó
 * pero el usuario no pasó la verificación).
 *
 * Usa [isApproved] para determinar si el usuario fue verificado exitosamente.
 */
@Parcelize
data class KycResult(
    val success: Boolean,
    val message: String,
    val sessionId: String,
    /** Identificador del usuario en el sistema del cliente. */
    val vendorData: String,
    val timestamp: String,
    /** Estado reportado por el servidor: "Approved", "Declined", "In Review". */
    val status: String = "",
    val faceMatch: Boolean,
    /** Similitud facial (0-100). Se recomienda aprobar a partir de 80. */
    val faceMatchScore: Float,
    val livenessCheck: Boolean,
    /** Confianza de prueba de vida (0-100). Se recomienda aprobar a partir de 80. */
    val livenessScore: Float,
    val documentValid: Boolean,
    /** Método de prueba de vida usado (ej. "passive"). Puede ser null. */
    val livenessMethod: String? = null,
    /** Edad estimada por análisis facial (0-100). Puede ser null. */
    val ageEstimation: Float? = null,
    /** Puntaje de calidad de la imagen facial (0-100). Puede ser null. */
    val faceQuality: Float? = null,
    val document: KycDocument,
    val resources: KycResources,
    /** Análisis de la IP desde la que se realizó la verificación. Puede ser null. */
    val ipAnalysis: KycIpAnalysis? = null,
    /** URL del PDF de la verificación (requiere el token de acceso para descargarse). Puede ser null. */
    val pdfUrl: String? = null,
    /** Razones de rechazo cuando el proceso no fue aprobado. Vacío si fue aprobado. */
    val rejectionReasons: List<String> = emptyList()
) : Parcelable {

    companion object {
        const val EXTRA_RESULT = "digid_kyc_result"
        const val EXTRA_ERROR = "digid_kyc_error"
    }

    /** true si el proceso fue exitoso y el usuario pasó todos los checks biométricos. */
    val isApproved: Boolean
        get() = success && faceMatch && livenessCheck && documentValid

    /** Serializa el resultado a JSON para enviar al backend del cliente. */
    fun toJson(): String = Gson().toJson(this)
}

/**
 * Análisis de la IP desde la que se realizó la verificación.
 */
@Parcelize
data class KycIpAnalysis(
    /** Dirección IP detectada. */
    val ipAddress: String?,
    /** Ciudad estimada por geolocalización de IP. */
    val ipCity: String?,
    /** Estado/región estimado por geolocalización de IP. */
    val ipState: String?,
    /** País estimado por geolocalización de IP. */
    val ipCountry: String?,
    /** true si la IP corresponde a una VPN o red Tor. Puede ser null. */
    val isVpnOrTor: Boolean?
) : Parcelable
