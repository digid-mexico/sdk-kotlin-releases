package com.digid.sdk

import android.app.Activity

/**
 * Códigos de resultado devueltos por las actividades del SDK de Digid.
 * Se evalúan junto con Activity.RESULT_OK para determinar el estado final.
 */
object DigidResultCode {
    /**
     * El usuario canceló el proceso voluntariamente (botón Cancelar o botón Atrás).
     */
    const val RESULT_CANCELLED = Activity.RESULT_FIRST_USER + 1

    /**
     * Ocurrió un error técnico durante el proceso (red, permisos denegados, sesión inválida).
     */
    const val RESULT_ERROR = Activity.RESULT_FIRST_USER + 2
}
