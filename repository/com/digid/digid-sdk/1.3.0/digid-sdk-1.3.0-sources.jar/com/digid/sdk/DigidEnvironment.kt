package com.digid.sdk

/**
 * Ambientes de ejecución disponibles para el SDK de Digid.
 */
enum class DigidEnvironment {
    /**
     * Ambiente de pruebas. Los datos se almacenan en una base de datos separada.
     * Usar durante el desarrollo e integración.
     */
    SANDBOX,

    /**
     * Ambiente productivo. Requiere un token de producción válido.
     * Usar únicamente en builds de producción.
     */
    PRODUCTION;

    internal val baseUrl: String
        get() = when (this) {
            SANDBOX -> "https://pruebas.digidmexico.com.mx/api/"
            PRODUCTION -> "https://digidmexico.com.mx/api/"
        }
}
