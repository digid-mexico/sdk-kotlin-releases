package com.digid.sdk

/**
 * Configura la vista de Términos y Condiciones obligatoria del SDK de Digid.
 *
 * La pantalla de T&C se muestra automáticamente antes de la primera vista activa del SDK
 * en cada sesión. Si el usuario encadena múltiples vistas dentro del [acceptanceTtlMs],
 * los T&C se muestran una sola vez.
 *
 * Ejemplo de uso en `Digid.initialize()`:
 * ```kotlin
 * Digid.initialize(
 *     context = this,
 *     clientId = BuildConfig.DIGID_CLIENT_ID,
 *     token   = BuildConfig.DIGID_TOKEN,
 *     termsConfig = DigidTermsConfig(
 *         termsText        = getString(R.string.mis_terminos_y_condiciones),
 *         acceptanceTtlMs  = 30 * 60 * 1000L  // 30 minutos
 *     )
 * )
 * ```
 *
 * @param termsText Texto completo de los T&C que se muestra en el panel deslizante.
 *   Si se omite, se usa el texto predeterminado de Digid.
 * @param acceptanceTtlMs Ventana de tiempo (ms) durante la cual la aceptación sigue vigente.
 *   Por defecto: 15 minutos. Al expirar, el usuario deberá aceptar de nuevo.
 */
data class DigidTermsConfig(
    val termsText: String = DEFAULT_TERMS_TEXT,
    val acceptanceTtlMs: Long = DEFAULT_TTL_MS
) {
    init {
        require(acceptanceTtlMs > 0) { "acceptanceTtlMs debe ser un valor positivo." }
        require(termsText.isNotBlank()) { "termsText no puede estar vacío." }
    }

    companion object {
        /** TTL por defecto: 15 minutos. */
        const val DEFAULT_TTL_MS = 15L * 60L * 1_000L

        val DEFAULT_TERMS_TEXT: String = """
TÉRMINOS Y CONDICIONES

Bienvenido a Digid ("La Empresa"). La presente Política de Términos y Condiciones ("Términos") gobierna su uso de la Página Web y plataforma de firmas de la Empresa, ubicada en digid.com.mx y digidmexico.com ("la Página Web y plataforma de firmas"), así como de cualquier servicio proporcionado a través de la misma.
<br><br>
<b>Aceptación de los términos</b>
<br><br>
Al utilizar nuestra Página Web o plataforma de firmas, usted acepta voluntariamente y en forma expresa, obligándose a cumplir con los presentes Términos, que pueden ser modificados por nosotros en cualquier momento según necesidades o requerimientos de la empresa. Si no está de acuerdo con los Términos, no debe utilizar nuestra Página Web o la plataforma de firmas.
<br><br>
<b>Servicios ofrecidos</b>
<br><br>
Somos una empresa mexicana dedicada a servicios de tecnología de la información y servicios de desarrollo de software.
<br><br>
Los servicios ofrecidos por la empresa son los siguientes:
<br><br>
<b>E. FIRMA:</b> Con la e.Firma puedes firmar tus contratos, ya que es un archivo digital que permite identificarte al momento de llevar a cabo trámites en línea, sin necesidad de enviar contratos físicamente; esta firma te brinda toda la validez y garantiza la identidad del firmante.
<br><br>
<b>FIRMA AUTÓGRAFA DIGITAL:</b> Esta firma sirve para los firmantes que no cuenten con e.firma o en su defecto personas que firman desde el extranjero; esta firma es escrita directamente por su autor.
<br><br>
<b>CERTIFICACIÓN DE ARCHIVOS:</b> La certificación de archivos consiste en un proceso donde se certifica ante la Secretaría de Economía; esta certificación garantiza la inalterabilidad de los archivos, además de otorgarle fecha cierta ante las autoridades fiscales.
<br><br>
<b>PERICIALES:</b> Ofrecemos el servicio de periciales en informática forense; contamos con peritos certificados, los cuales pueden dictaminar procesos y evidencias digitales.
<br><br>
<b>Uso de la página web y plataforma de firmas</b>
<br><br>
Usted acuerda utilizar la Página Web y la plataforma de firmas solo para propósitos legales y de acuerdo con los presentes Términos. Se le prohíbe utilizar la Página Web o la plataforma de firmas de manera que pudiera desactivar, sobrecargar, dañar o perjudicar la Página Web o la plataforma de firmas, o interferir con el uso por parte de terceros.
<br><br>
<b>Propiedad intelectual</b>
<br><br>
Todo el contenido, marca y otros materiales en la Página Web y en la plataforma de firmas son propiedad de la Empresa o se usan con el permiso de sus propietarios. No está permitido el uso, reproducción parcial o total o distribución de dichos contenidos sin el permiso expreso y por escrito de la Empresa.
<br><br>
<b>Datos personales y privacidad</b>
<br><br>
Usted está obligado a consultar nuestra Política de Privacidad para conocer cómo manejamos sus datos personales; el simple uso de la página se considera que son de su conocimiento y está de acuerdo y conforme con ellos.
<br><br>
<b>Exclusión de garantías</b>
<br><br>
La Empresa no ofrece garantías o representaciones sobre la exactitud, fiabilidad, disponibilidad, actualidad o completitud de cualquier información en la Página Web o en la plataforma de firmas.
<br><br>
<b>Limitación de responsabilidad</b>
<br><br>
Hasta donde lo permite la ley aplicable, la Empresa no será responsable de ninguna pérdida directa, indirecta, incidental, especial, ejemplar o consecuencial, incluyendo sin limitación pérdida de beneficios, datos, uso, buena voluntad u otras pérdidas intangibles, resultantes del uso o la imposibilidad de usar la Página Web o la plataforma de firmas.
<br><br>
La empresa se exime expresamente de toda responsabilidad por la veracidad, precisión, legalidad o legitimidad de los documentos proporcionados por el usuario. Esta responsabilidad recae exclusivamente en el usuario, quien asegura y garantiza que posee todos los derechos y autorizaciones necesarias para suministrar dichos documentos.
<br><br>
Cualquier error, inexactitud, falsedad o infracción de derechos de terceros en los documentos suministrados por el usuario son de su entera responsabilidad, y la empresa no se hará cargo ni aceptará ninguna obligación legal o de otra índole que pueda surgir de ello.
<br><br>
<b>Indemnización</b>
<br><br>
Usted acuerda indemnizar y mantener indemne a la Empresa, sus afiliados, directores, empleados y agentes, de y contra cualquier reclamación, daño, obligación, pérdida, responsabilidad, costo o deuda, y gastos (incluyendo, pero no limitado a, honorarios de abogados) que surjan de: (I) su uso y acceso a la Página Web o a la plataforma de firmas; (II) su violación de cualquier término de estos Términos.
<br><br>
<b>Ley aplicable</b>
<br><br>
Estos Términos se regirán e interpretarán de acuerdo con las leyes de México, sin considerar su conflicto de disposiciones legales.
<br><br>
<b>Cambios a los términos</b>
<br><br>
Podemos modificar estos Términos en cualquier momento, según necesidades o requerimientos de la empresa. Publicaremos cualquier cambio en esta página, por lo que le recomendamos que previo a su uso la revise.
<br><br>
<b>Contacto</b>
<br><br>
Si tiene alguna pregunta sobre estos Términos, por favor contáctenos a través de:
<br>
Correo electrónico: <a href="mailto:contacto@digid.com.mx">contacto@digid.com.mx</a>
<br>
Dirección: Calle 70 #501 letra "A" entre calles 71 y 73 de la Colonia Dzitya Polígono Chuburná.
<br><br>
<b>Rescisión</b>
<br><br>
Nos reservamos el derecho de rescindir o suspender su acceso a nuestra Página Web o a la plataforma de firmas, por cualquier motivo, sin previo aviso.
<br><br>
<b>Renuncia</b>
<br><br>
Ninguna renuncia a cualesquiera de estos Términos será considerada una renuncia adicional o continua a dicho término o cualquier otro término, y el hecho de no reclamar un derecho o disposición bajo estos Términos no constituirá una renuncia a dicho derecho o disposición.
<br><br>
<b>Divisibilidad</b>
<br><br>
Si alguna disposición de estos Términos es considerada ilegal, nula o por cualquier razón inaplicable, dicha disposición será considerada divisible de estos Términos y no afectará la validez y aplicabilidad de las disposiciones restantes.
<br><br>
Estos Términos y Condiciones constituyen el acuerdo completo entre las partes en relación con su objeto, y reemplazan todos los acuerdos anteriores, escritos u orales, entre las partes en relación con dicho objeto.
<br><br>
Al utilizar nuestra Página Web o plataforma de firmas, usted reconoce voluntaria y expresamente que ha leído, comprendido y aceptado estar sujeto a estos Términos.
<br><br>
<b>Propiedad intelectual</b>
<br><br>
Al aceptar los presentes Términos y Condiciones, el usuario autoriza a La Empresa a utilizar su nombre comercial, marca y logotipo, de manera no exclusiva y únicamente con fines informativos y de referencia comercial, para su inclusión en listados de clientes, casos de uso o materiales institucionales del sitio web. Dicho uso no implicará cesión de derechos ni finalidad distinta a la aquí descrita.
        """.trimIndent()
    }
}
