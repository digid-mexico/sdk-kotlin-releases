package com.digid.sdk

import java.io.Serializable

/**
 * Excepcion base del SDK de Digid.
 * Contiene el codigo de error y un mensaje descriptivo.
 */
data class DigidException(
    val code: DigidErrorCode,
    override val message: String,
    val details: String? = null
) : Exception(message), Serializable {
    companion object {
        private const val serialVersionUID = 1L
    }
}

/**
 * Codigos de error del SDK de Digid.
 */
enum class DigidErrorCode {
    NETWORK_ERROR,
    CAMERA_PERMISSION_DENIED,
    SESSION_EXPIRED,
    INVALID_TOKEN,
    SDK_NOT_INITIALIZED,
    VERIFICATION_SERVICE_ERROR,
    DEVICE_NOT_SUPPORTED,
    DOCUMENT_NOT_FOUND,
    SIGNER_NOT_AUTHORIZED,
    KYC_FACE_NO_MATCH,
    KYC_LIVENESS_FAILED,
    KYC_DOCUMENT_UNREADABLE,
    INSUFFICIENT_FOLIOS,
    CLIENT_SUSPENDED,
    INVALID_PROCESS,
    SERVICE_MAINTENANCE,
    POLLING_TIMEOUT,
    UNKNOWN_ERROR;
}
