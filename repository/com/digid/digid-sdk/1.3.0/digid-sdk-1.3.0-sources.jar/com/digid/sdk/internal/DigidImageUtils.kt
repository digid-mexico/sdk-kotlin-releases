package com.digid.sdk.internal

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream

internal object DigidImageUtils {
    fun resizedPngBase64(bitmap: Bitmap, maxSize: Int = 96): String {
        val resized = Bitmap.createScaledBitmap(bitmap, maxSize, maxSize, true)
        val stream = ByteArrayOutputStream()
        resized.compress(Bitmap.CompressFormat.PNG, 100, stream)
        if (resized != bitmap) resized.recycle()
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
}
