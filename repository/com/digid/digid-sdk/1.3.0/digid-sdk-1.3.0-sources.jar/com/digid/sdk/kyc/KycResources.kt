package com.digid.sdk.kyc

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Recursos multimedia capturados durante el proceso KYC.
 * Las imágenes se entregan en formato Base64 para facilitar
 * la transmisión segura al backend del cliente.
 *
 * NOTA: La URL del video de prueba de vida expira en 24 horas.
 * Si necesitas conservarlo, descárgalo y almacénalo en tu
 * propia infraestructura antes de que expire.
 */
@Parcelize
data class KycResources(
    /** Foto frontal del documento en formato JPEG codificada en Base64. */
    val idFrontBase64: String,

    /** Foto del reverso del documento en formato JPEG codificada en Base64. */
    val idBackBase64: String,

    /** Selfie del usuario en formato JPEG codificada en Base64. */
    val selfieBase64: String,

    /** URL temporal del video de prueba de vida. Expira en 24 horas. Puede ser null. */
    val livenessVideoUrl: String?
) : Parcelable
