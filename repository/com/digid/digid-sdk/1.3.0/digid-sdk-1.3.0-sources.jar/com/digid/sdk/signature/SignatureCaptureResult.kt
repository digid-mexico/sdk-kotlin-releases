package com.digid.sdk.signature

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Resultado de la Vista 2 — Captura de Firma.
 * Contiene la imagen de la firma como PNG en Base64.
 *
 * Sobre la imagen:
 * - Formato: PNG con fondo transparente
 * - Dimensiones típicas: 800x300 px a 150 dpi
 * - Si no necesitas conservarla, ignora signatureBase64.
 */
@Parcelize
data class SignatureCaptureResult(
    /** true si el usuario confirmó su firma. */
    val success: Boolean,
    /** Mensaje descriptivo. */
    val message: String,
    /** Imagen PNG de la firma codificada en Base64 (data:image/png;base64,...). */
    val signatureBase64: String
) : Parcelable {
    companion object {
        const val EXTRA_RESULT = "digid_signature_capture_result"
        const val EXTRA_ERROR = "digid_signature_capture_error"
    }

    fun toJson(): String = """{"success":$success,"message":"$message","signature_image_base64":"$signatureBase64"}"""
}
