package com.digid.sdk.signature.internal

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.SizeF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min

/**
 * Vista de canvas táctil para captura de firma manuscrita.
 *
 * Cada trazo se guarda en coordenadas normalizadas (0..1) junto con el tamaño
 * del canvas en el momento del dibujo. Al redibujarse (p.ej. al rotar el
 * dispositivo) se aplica un **escalado uniforme** (aspect-fit) para que la
 * firma conserve sus proporciones sin deformarse.
 *
 * INTERNO: No expuesto en la API pública del SDK.
 */
internal class SignatureCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    // ── Listener ─────────────────────────────────────────────────────────────
    interface OnSignatureChangedListener {
        fun onSignatureChanged(hasContent: Boolean)
    }

    var onSignatureChangedListener: OnSignatureChangedListener? = null

    // ── Paint ─────────────────────────────────────────────────────────────────
    private val signaturePaint = Paint().apply {
        isAntiAlias = true
        color = Color.BLACK
        strokeWidth = 4f
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    // ── Stroke model ──────────────────────────────────────────────────────────
    /** Puntos en coordenadas normalizadas (0..1) respecto a [recordingSize]. */
    private data class Stroke(
        val points: List<PointF>,
        val recordingSize: SizeF
    )

    private val strokes = mutableListOf<Stroke>()
    private val currentPoints = mutableListOf<PointF>()
    private var currentRecordingSize = SizeF(0f, 0f)
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var isDrawing = false

    // ── State ─────────────────────────────────────────────────────────────────
    private var _hasContent = false
    val hasContent: Boolean get() = _hasContent

    // ── Drawing ───────────────────────────────────────────────────────────────
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (stroke in strokes) {
            buildPath(stroke)?.let { canvas.drawPath(it, signaturePaint) }
        }
        // Trazo en curso: usa el tamaño actual → siempre 1:1, sin distorsión
        if (currentPoints.isNotEmpty()) {
            val live = Stroke(currentPoints.toList(), SizeF(width.toFloat(), height.toFloat()))
            buildPath(live)?.let { canvas.drawPath(it, signaturePaint) }
        }
    }

    /**
     * Reconstruye un [Path] aplicando escalado uniforme (aspect-fit) desde el
     * tamaño de grabación hasta el tamaño actual del canvas.
     * Esto preserva las proporciones del trazo original al rotar el dispositivo.
     */
    private fun buildPath(stroke: Stroke): Path? {
        if (stroke.points.isEmpty()) return null
        val src = stroke.recordingSize
        if (src.width <= 0 || src.height <= 0 || width <= 0 || height <= 0) return null

        // Escalado uniforme: usa el menor factor para que la firma quepa sin distorsión
        val scaleX = width.toFloat() / src.width
        val scaleY = height.toFloat() / src.height
        val scale = min(scaleX, scaleY)

        // Centrar el área escalada dentro del canvas actual
        val offsetX = (width - src.width * scale) / 2f
        val offsetY = (height - src.height * scale) / 2f

        fun toDisplay(p: PointF) = PointF(
            p.x * src.width * scale + offsetX,
            p.y * src.height * scale + offsetY
        )

        val pts = stroke.points.map { toDisplay(it) }
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)

        if (pts.size == 1) {
            // Toque puntual: dibuja un punto visible
            path.lineTo(pts[0].x + 0.5f, pts[0].y + 0.5f)
            return path
        }

        // Reproducir la lógica de suavizado Bezier del tracking táctil
        var last = pts[0]
        for (i in 1 until pts.size - 1) {
            val curr = pts[i]
            val midX = (last.x + curr.x) / 2f
            val midY = (last.y + curr.y) / 2f
            path.quadTo(last.x, last.y, midX, midY)
            last = curr
        }
        path.lineTo(pts.last().x, pts.last().y)
        return path
    }

    // ── Coordinate helpers ────────────────────────────────────────────────────
    private fun normalize(x: Float, y: Float): PointF {
        val w = if (width > 0) width.toFloat() else return PointF(x, y)
        val h = if (height > 0) height.toFloat() else return PointF(x, y)
        return PointF(x / w, y / h)
    }

    // ── Touch events ──────────────────────────────────────────────────────────
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                // Registrar el tamaño del canvas al inicio de cada trazo
                currentRecordingSize = SizeF(width.toFloat(), height.toFloat())
                currentPoints.clear()
                currentPoints.add(normalize(x, y))
                lastRawX = x
                lastRawY = y
                isDrawing = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!isDrawing) return true
                val dx = abs(x - lastRawX)
                val dy = abs(y - lastRawY)
                if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                    currentPoints.add(normalize(x, y))
                    lastRawX = x
                    lastRawY = y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (isDrawing) {
                    currentPoints.add(normalize(x, y))
                    strokes.add(Stroke(currentPoints.toList(), currentRecordingSize))
                    currentPoints.clear()
                    isDrawing = false
                    val wasEmpty = !_hasContent
                    _hasContent = true
                    if (wasEmpty) onSignatureChangedListener?.onSignatureChanged(true)
                }
            }
        }
        invalidate()
        return true
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /** Limpia el canvas y restablece el estado a vacío. */
    fun clear() {
        strokes.clear()
        currentPoints.clear()
        _hasContent = false
        isDrawing = false
        invalidate()
        onSignatureChangedListener?.onSignatureChanged(false)
    }

    /** Exporta la firma como Bitmap PNG con fondo transparente. */
    fun exportToBitmap(): Bitmap {
        val w = if (width > 0) width else 800
        val h = if (height > 0) height else 300
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        for (stroke in strokes) {
            buildPath(stroke)?.let { canvas.drawPath(it, signaturePaint) }
        }
        return bitmap
    }

    /** Exporta la firma como string Base64 con prefijo data URI. */
    fun exportToBase64(): String {
        val bitmap = exportToBitmap()
        val stream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        val b64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)
        return "data:image/png;base64,$b64"
    }

    companion object {
        private const val TOUCH_TOLERANCE = 4f
    }
}
