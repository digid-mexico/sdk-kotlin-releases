package com.digid.sdk.internal

import com.digid.sdk.kyc.KycResult

/**
 * Almacén temporal de un solo uso para el resultado KYC.
 *
 * Problema que resuelve:
 * El límite de Binder en Android es ~1 MB. Un KycResult con 4 imágenes en base64
 * (frente INE, reverso, selfie, portrait) puede superar fácilmente 1.3 MB, lo que
 * causa FAILED BINDER TRANSACTION al intentar entregarlo vía setResult(Intent).
 *
 * Solución:
 * KycActivity guarda el resultado aquí en lugar de ponerlo en el Intent.
 * La Activity llamante lee el resultado con Digid.consumeKycResult() cuando
 * recibe RESULT_OK. El resultado se borra tras la primera lectura para no
 * retener memoria innecesariamente.
 */
internal object KycResultHolder {

    @Volatile
    private var pendingResult: KycResult? = null

    /** Guarda el resultado para su entrega asíncrona. Llamado por KycActivity. */
    internal fun store(result: KycResult) {
        pendingResult = result
    }

    /**
     * Lee y borra el resultado pendiente.
     * @return KycResult o null si no hay resultado pendiente (p. ej. segunda llamada).
     */
    internal fun consume(): KycResult? {
        val result = pendingResult
        pendingResult = null
        return result
    }
}
