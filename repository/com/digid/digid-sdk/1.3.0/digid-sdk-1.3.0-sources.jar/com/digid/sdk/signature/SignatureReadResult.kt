package com.digid.sdk.signature

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Resultado de la Vista 1 — Lectura del Documento.
 * Solo indica si el usuario leyó el documento completo o canceló.
 */
@Parcelize
data class SignatureReadResult(
    /** true si el usuario llegó al final del documento. */
    val success: Boolean,
    /** Mensaje descriptivo. */
    val message: String
) : Parcelable {
    companion object {
        const val EXTRA_RESULT = "digid_signature_read_result"
        const val EXTRA_ERROR = "digid_signature_read_error"
    }

    fun toJson(): String = """{"success":$success,"message":"$message"}"""
}
