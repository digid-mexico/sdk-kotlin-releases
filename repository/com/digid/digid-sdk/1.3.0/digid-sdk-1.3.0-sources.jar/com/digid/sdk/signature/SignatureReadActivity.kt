package com.digid.sdk.signature

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import com.digid.sdk.DigidResultCode
import com.digid.sdk.internal.DigidAPIClient
import com.digid.sdk.internal.DigidBaseActivity
import java.io.File
import java.io.FileOutputStream

/**
 * Downloads and renders a PDF document for the user to read before signing.
 * Displays the full document with scrolling; the Continue button is enabled only
 * when scrolling reaches 95% of the document height.
 */
class SignatureReadActivity : DigidBaseActivity() {

    companion object {
        private const val TAG = "SignatureReadActivity"

        /** ID único del documento a firmar. Requerido. */
        const val EXTRA_DOCUMENT_ID = "digid_document_id"

        /** ID de la empresa/cliente en la plataforma Digid. Requerido. */
        const val EXTRA_CLIENT_ID = "digid_client_id"

        /** ID del usuario firmante. Requerido. */
        const val EXTRA_SIGNER_ID = "digid_signer_id"

        const val EXTRA_RESULT = SignatureReadResult.EXTRA_RESULT
        const val EXTRA_ERROR = SignatureReadResult.EXTRA_ERROR
    }

    private lateinit var documentId: String
    private lateinit var clientId: String
    private lateinit var signerId: String

    private lateinit var scrollView: ScrollView
    private lateinit var pdfContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var loadingText: TextView
    private lateinit var btnContinue: Button
    private lateinit var btnCancel: Button
    private lateinit var readProgressText: TextView
    private lateinit var errorLayout: LinearLayout

    private var hasReachedEnd = false
    private var pdfRenderer: PdfRenderer? = null
    private var pdfFile: File? = null
    private var pageHeight: Int = 0

    override fun onSdkReady() {
        // Extraer parámetros
        documentId = intent.getStringExtra(EXTRA_DOCUMENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "document_id es requerido."))
            return
        }
        clientId = intent.getStringExtra(EXTRA_CLIENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "client_id es requerido."))
            return
        }
        signerId = intent.getStringExtra(EXTRA_SIGNER_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "signer_id es requerido."))
            return
        }

        buildUI()
        applyTheme()
        loadDocument()
    }

    override fun onBackPressed() {
        deliverCancelled()
    }

    override fun onDestroy() {
        super.onDestroy()
        pdfRenderer?.close()
        pdfFile?.delete()
    }

    // ── UI Construction ──────────────────────────────────────────────────────

    private fun buildUI() {
        val theme = Digid.theme
        val primaryColor = Color.parseColor(theme.primaryColor)

        window.statusBarColor = primaryColor

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.WHITE)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setContentView(root)

        val toolbar = RelativeLayout(this)
        toolbar.id = View.generateViewId()
        toolbar.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            56.dpToPx()
        ).apply { gravity = Gravity.TOP }
        toolbar.setBackgroundColor(primaryColor)
        toolbar.setPadding(16.dpToPx(), 0, 16.dpToPx(), 0)

        val title = TextView(this)
        title.text = "Lectura del Documento"
        title.setTextColor(Color.WHITE)
        title.textSize = 18f
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val titleParams = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.MATCH_PARENT
        )
        titleParams.addRule(RelativeLayout.CENTER_VERTICAL)

        theme.logoResId?.let { resId ->
            val logo = ImageView(this)
            logo.setImageResource(resId)
            logo.adjustViewBounds = true
            logo.id = View.generateViewId()
            val logoParams = RelativeLayout.LayoutParams(32.dpToPx(), 32.dpToPx())
            logoParams.addRule(RelativeLayout.CENTER_VERTICAL)
            toolbar.addView(logo, logoParams)
            titleParams.addRule(RelativeLayout.END_OF, logo.id)
            titleParams.marginStart = 8.dpToPx()
        }

        toolbar.addView(title, titleParams)

        btnCancel = Button(this)
        btnCancel.text = "Cancelar"
        btnCancel.setTextColor(Color.WHITE)
        btnCancel.background = null
        val cancelParams = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.MATCH_PARENT
        )
        cancelParams.addRule(RelativeLayout.ALIGN_PARENT_END)
        cancelParams.addRule(RelativeLayout.CENTER_VERTICAL)
        toolbar.addView(btnCancel, cancelParams)
        btnCancel.setOnClickListener { deliverCancelled() }

        root.addView(toolbar)

        scrollView = ScrollView(this)
        scrollView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ).apply {
            topMargin = 56.dpToPx()
            bottomMargin = 90.dpToPx()
        }

        pdfContainer = LinearLayout(this)
        pdfContainer.orientation = LinearLayout.VERTICAL
        scrollView.addView(pdfContainer)

        scrollView.viewTreeObserver.addOnScrollChangedListener {
            if (!hasReachedEnd) {
                updateScrollProgress()
            }
        }

        root.addView(scrollView)

        readProgressText = TextView(this)
        readProgressText.text = "Desplazate hasta el final para continuar"
        readProgressText.textAlignment = View.TEXT_ALIGNMENT_CENTER
        readProgressText.setPadding(32.dpToPx(), 12.dpToPx(), 32.dpToPx(), 12.dpToPx())
        readProgressText.setTextColor(Color.parseColor("#666666"))
        readProgressText.textSize = 14f

        btnContinue = Button(this)
        btnContinue.text = "Continuar"
        btnContinue.isEnabled = false
        btnContinue.alpha = 0.5f
        btnContinue.setBackgroundColor(primaryColor)
        btnContinue.setTextColor(Color.WHITE)
        btnContinue.setOnClickListener { deliverSuccess() }

        btnContinue.minimumHeight = 44.dpToPx()

        val bottomBar = LinearLayout(this)
        bottomBar.orientation = LinearLayout.VERTICAL
        bottomBar.setBackgroundColor(Color.WHITE)
        bottomBar.elevation = 8f
        bottomBar.addView(readProgressText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        bottomBar.addView(btnContinue, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            44.dpToPx()
        ).apply { setMargins(16.dpToPx(), 4.dpToPx(), 16.dpToPx(), 8.dpToPx()) })

        root.addView(bottomBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.BOTTOM })

        progressBar = ProgressBar(this)
        loadingText = TextView(this)
        loadingText.text = "Cargando documento..."
        loadingText.textAlignment = View.TEXT_ALIGNMENT_CENTER
        loadingText.setTextColor(Color.parseColor("#666666"))
        loadingText.textSize = 16f

        errorLayout = LinearLayout(this)
        errorLayout.orientation = LinearLayout.VERTICAL
        errorLayout.gravity = Gravity.CENTER

        val loadingLayout = LinearLayout(this)
        loadingLayout.orientation = LinearLayout.VERTICAL
        loadingLayout.gravity = Gravity.CENTER
        loadingLayout.addView(progressBar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        loadingLayout.addView(loadingText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, 16.dpToPx(), 0, 0) })

        pdfContainer.addView(loadingLayout, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        ))
    }

    private fun applyTheme() {
        val theme = Digid.theme
        val primaryColor = Color.parseColor(theme.primaryColor)
        btnContinue.setBackgroundColor(primaryColor)
        btnContinue.setTextColor(Color.WHITE)
    }

    private fun enableContinueButton() {
        btnContinue.isEnabled = true
        btnContinue.alpha = 1f
        readProgressText.text = "Documento leido completo"
        readProgressText.setTextColor(Color.parseColor("#2D8CF0"))
    }

    private fun updateScrollProgress() {
        val scrollY = scrollView.scrollY
        val totalHeight = pdfContainer.height - scrollView.height
        val scrollPercent = if (totalHeight > 0) (scrollY.toFloat() / totalHeight) * 100 else 100f

        val percent = minOf(scrollPercent.toInt(), 100)
        if (scrollPercent >= 95f) {
            hasReachedEnd = true
            enableContinueButton()
        } else {
            readProgressText.text = "Progreso de lectura: $percent%"
            readProgressText.setTextColor(Color.parseColor("#666666"))
        }
    }

    // ── PDF Loading ──────────────────────────────────────────────────────────

    private fun loadDocument() {
        Thread {
            try {
                val pdfBytes = DigidAPIClient.downloadDocument(documentId.toIntOrNull() ?: 0)
                val tempFile = File(cacheDir, "digid_doc_${documentId}.pdf")
                FileOutputStream(tempFile).use { it.write(pdfBytes) }
                pdfFile = tempFile

                runOnUiThread {
                    renderPdf(tempFile)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading document: ${e.message}", e)
                runOnUiThread {
                    showErrorState(e)
                }
            }
        }.start()
    }


    private fun renderPdf(file: File) {
        pdfContainer.removeAllViews()

        if (!file.exists() || file.length() == 0L) {
            showErrorState(Exception("PDF file is empty"))
            return
        }

        try {
            val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pdfRenderer = PdfRenderer(fd)
            val pageCount = pdfRenderer!!.pageCount

            if (pageCount == 0) {
                showErrorState(Exception("PDF has no pages"))
                return
            }

            for (i in 0 until pageCount) {
                val page = pdfRenderer!!.openPage(i)
                val screenWidth = resources.displayMetrics.widthPixels
                val scaleFactor = screenWidth.toFloat() / page.width
                val bitmapWidth = screenWidth
                val bitmapHeight = (page.height * scaleFactor).toInt()

                pageHeight = bitmapHeight

                val bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()

                val imageView = ImageView(this)
                imageView.setImageBitmap(bitmap)
                imageView.adjustViewBounds = true
                pdfContainer.addView(imageView, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ))
            }

            readProgressText.visibility = View.VISIBLE

            // After layout, check if content fits without scrolling (single-page doc)
            scrollView.post {
                val contentHeight = pdfContainer.height
                val visibleHeight = scrollView.height
                if (contentHeight <= visibleHeight) {
                    hasReachedEnd = true
                    enableContinueButton()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error rendering PDF: ${e.message}", e)
            showErrorState(e)
        }
    }

    private fun showErrorState(error: Exception) {
        pdfContainer.removeAllViews()
        errorLayout.removeAllViews()

        val errorText = TextView(this)
        errorText.text = "Error al cargar el documento"
        errorText.setTextColor(Color.parseColor("#E74C3C"))
        errorText.textSize = 16f
        errorText.gravity = Gravity.CENTER
        errorText.setPadding(32.dpToPx(), 16.dpToPx(), 32.dpToPx(), 16.dpToPx())

        val retryBtn = Button(this)
        retryBtn.text = "Reintentar"
        retryBtn.setBackgroundColor(Color.parseColor(Digid.theme.primaryColor))
        retryBtn.setTextColor(Color.WHITE)
        retryBtn.setOnClickListener { loadDocument() }

        errorLayout.addView(errorText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER })
        errorLayout.addView(retryBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.CENTER })

        pdfContainer.addView(errorLayout, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        ))
    }

    // ── Result delivery ──────────────────────────────────────────────────────

    private fun deliverSuccess() {
        val result = SignatureReadResult(
            success = true,
            message = "Documento leido correctamente."
        )
        val intent = Intent().putExtra(EXTRA_RESULT, result)
        setResult(RESULT_OK, intent)
        finish()
    }

    private fun deliverCancelled() {
        val result = SignatureReadResult(
            success = false,
            message = "Proceso cancelado por el usuario."
        )
        val intent = Intent().putExtra(EXTRA_RESULT, result)
        setResult(DigidResultCode.RESULT_CANCELLED, intent)
        finish()
    }

    private fun deliverError(error: DigidException) {
        val intent = Intent().putExtra(EXTRA_ERROR, error)
        setResult(DigidResultCode.RESULT_ERROR, intent)
        finish()
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()
}
