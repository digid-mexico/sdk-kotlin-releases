package com.digid.sdk.signature

import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import com.digid.sdk.DigidResultCode
import com.digid.sdk.DigidTheme
import com.digid.sdk.internal.DigidAPIClient
import com.digid.sdk.internal.DigidBaseActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Vista 3 — Aplicacion de Firmas al Documento.
 *
 * Porteada uno-a-uno desde la version iOS:
 * - Renderiza TODAS las paginas del PDF apiladas verticalmente dentro de un ScrollView.
 * - Posiciona cada firma con translationX/Y + pivot(0,0) + rotation para que la rotacion
 *   se comporte como el `anchorPoint(0,0)` de iOS.
 * - Muestra la imagen real de la firma (75dp x 47dp) dentro del overlay, con borde
 *   punteado mientras esta activa; al confirmar deja la firma fija sin borde.
 * - Auto-scrollea hasta la firma actual.
 */
class SignatureApplyActivity : DigidBaseActivity() {

    companion object {
        const val EXTRA_DOCUMENT_ID = "digid_document_id"
        const val EXTRA_CLIENT_ID = "digid_client_id"
        const val EXTRA_SIGNER_ID = "digid_signer_id"
        const val EXTRA_RESULT = SignatureApplyResult.EXTRA_RESULT
        const val EXTRA_ERROR = SignatureApplyResult.EXTRA_ERROR
    }

    private lateinit var documentId: String
    private lateinit var clientId: String
    private lateinit var signerId: String
    private lateinit var digidTheme: DigidTheme
    private val primaryColor: Int by lazy { Color.parseColor(digidTheme.primaryColor) }
    private val bgColor: Int by lazy { Color.parseColor(digidTheme.backgroundColor) }

    private var currentSignatureIndex = 0
    private var totalSignatures = 0
    private var signaturesApplied = 0
    private var signatureCoordinates: JSONArray? = null
    private var pdfBytes: ByteArray? = null
    private var signatureImageBytes: ByteArray? = null
    private var signatureBitmap: Bitmap? = null
    private var requiresGps = false
    private var alreadySigned = false

    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var scrollView: ScrollView
    private lateinit var pdfContainer: FrameLayout
    private lateinit var btnAccept: Button
    private lateinit var loadingBar: ProgressBar
    private lateinit var contentContainer: FrameLayout

    private val pageDetails = mutableMapOf<Int, PageDetail>()
    private val signatureOverlays = mutableMapOf<String, View>()
    private var pagesRendered = false

    private data class PageDetail(
        val pageNumber: Int,
        val renderedWidth: Float,
        val renderedHeight: Float,
        val originY: Float,
        val originalWidth: Float,
        val originalHeight: Float
    )

    override fun onSdkReady() {
        digidTheme = Digid.theme
        documentId = intent.getStringExtra(EXTRA_DOCUMENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "document_id is required"))
            return
        }
        clientId = intent.getStringExtra(EXTRA_CLIENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "client_id is required"))
            return
        }
        signerId = intent.getStringExtra(EXTRA_SIGNER_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "signer_id is required"))
            return
        }

        window.statusBarColor = primaryColor
        buildUI()
        loadSignatureData()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        showCancelConfirmation()
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UI construction
    // ═══════════════════════════════════════════════════════════════════════

    private fun buildUI() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
        setContentView(root)

        createToolbar(root)

        contentContainer = FrameLayout(this)
        contentContainer.setBackgroundColor(bgColor)
        val contentParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        contentParams.topMargin = 56.dpToPx()
        root.addView(contentContainer, contentParams)

        loadingBar = ProgressBar(this)
        val loadingParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        loadingParams.gravity = Gravity.CENTER
        contentContainer.addView(loadingBar, loadingParams)
    }

    private fun createToolbar(root: FrameLayout): RelativeLayout {
        val toolbar = RelativeLayout(this).apply {
            setBackgroundColor(primaryColor)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                56.dpToPx()
            )
        }

        digidTheme.logoResId?.let { resId ->
            val logo = ImageView(this).apply {
                setImageResource(resId)
                adjustViewBounds = true
                id = View.generateViewId()
            }
            val logoParams = RelativeLayout.LayoutParams(80.dpToPx(), 32.dpToPx())
            logoParams.addRule(RelativeLayout.CENTER_VERTICAL)
            logoParams.marginStart = 16.dpToPx()
            toolbar.addView(logo, logoParams)
        }

        val title = TextView(this).apply {
            text = "Aplicación de Firmas"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        }
        val titleParams = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        )
        titleParams.addRule(RelativeLayout.CENTER_VERTICAL)
        titleParams.marginStart = 16.dpToPx()
        toolbar.addView(title, titleParams)

        val btnCancel = Button(this).apply {
            text = "Cancelar"
            setTextColor(Color.WHITE)
            background = null
            setOnClickListener { showCancelConfirmation() }
        }
        val cancelParams = RelativeLayout.LayoutParams(
            RelativeLayout.LayoutParams.WRAP_CONTENT,
            RelativeLayout.LayoutParams.WRAP_CONTENT
        )
        cancelParams.addRule(RelativeLayout.ALIGN_PARENT_END)
        cancelParams.addRule(RelativeLayout.CENTER_VERTICAL)
        cancelParams.marginEnd = 16.dpToPx()
        toolbar.addView(btnCancel, cancelParams)

        root.addView(toolbar)
        return toolbar
    }

    private fun buildContentUI() {
        contentContainer.removeAllViews()

        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setPadding(16.dpToPx(), 16.dpToPx(), 16.dpToPx(), 16.dpToPx())
        }

        progressText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#333333"))
            gravity = Gravity.CENTER
        }
        mainLayout.addView(progressText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
        }
        val progressParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            4.dpToPx()
        )
        progressParams.setMargins(0, 4.dpToPx(), 0, 8.dpToPx())
        mainLayout.addView(progressBar, progressParams)

        // ── ScrollView con el contenedor del PDF ──
        scrollView = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#E5E5EA"))
            isFillViewport = false
        }
        pdfContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        }
        scrollView.addView(pdfContainer)

        val scrollParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        )
        scrollParams.setMargins(0, 0, 0, 12.dpToPx())
        mainLayout.addView(scrollView, scrollParams)

        // ── Boton aceptar ──
        btnAccept = Button(this).apply {
            setBackgroundColor(primaryColor)
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            isEnabled = false
            setOnClickListener { acceptCurrentSignature() }
        }
        mainLayout.addView(btnAccept, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            52.dpToPx()
        ))

        contentContainer.addView(mainLayout)

        // Renderizamos el PDF cuando ya conozcamos el ancho del ScrollView
        scrollView.viewTreeObserver.addOnGlobalLayoutListener(
            object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    if (scrollView.width > 0 && !pagesRendered) {
                        scrollView.viewTreeObserver.removeOnGlobalLayoutListener(this)
                        pagesRendered = true
                        renderPdfPages(scrollView.width)
                        showCurrentSignaturePoint()
                    }
                }
            }
        )
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  Data loading
    // ═══════════════════════════════════════════════════════════════════════

    private fun loadSignatureData() {
        Thread {
            try {
                val docId = documentId.toIntOrNull() ?: 0
                val sigId = signerId.toIntOrNull() ?: 0
                val response = DigidAPIClient.startSignature(docId, sigId)
                runOnUiThread {
                    if (!response.optBoolean("success", true)) {
                        val errorMsg = response.optString("error", "Error iniciando proceso de firma")
                        deliverError(DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, errorMsg))
                        return@runOnUiThread
                    }
                    if (response.optBoolean("alreadySigned", false)) {
                        AlertDialog.Builder(this)
                            .setTitle("Firma completada")
                            .setMessage("Este documento ya ha sido firmado.")
                            .setPositiveButton("OK") { _, _ -> finish() }
                            .show()
                        return@runOnUiThread
                    }

                    alreadySigned = response.optBoolean("alreadySigned", false)
                    requiresGps = response.optBoolean(
                        "requiresGps",
                        response.optJSONObject("preferences")?.optBoolean("required_gps", false) ?: false
                    )
                    signatureCoordinates = response.optJSONArray("signature_coordinates")
                        ?: response.optJSONArray("signatureCoordinates")
                    totalSignatures = signatureCoordinates?.length() ?: 0

                    if (totalSignatures == 0) {
                        deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "No signature coordinates found"))
                        return@runOnUiThread
                    }

                    loadPdfAndSignature()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    deliverError(DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, e.message ?: "Failed to load signature data"))
                }
            }
        }.start()
    }

    private fun loadPdfAndSignature() {
        Thread {
            try {
                val docId = documentId.toIntOrNull() ?: 0
                val sigId = signerId.toIntOrNull() ?: 0
                pdfBytes = DigidAPIClient.downloadDocument(docId)
                signatureImageBytes = DigidAPIClient.downloadSignatureImage(docId, sigId)
                signatureImageBytes?.let { bytes ->
                    signatureBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }
                runOnUiThread { buildContentUI() }
            } catch (e: Exception) {
                runOnUiThread {
                    deliverError(DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, e.message ?: "Failed to download document"))
                }
            }
        }.start()
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PDF rendering — todas las paginas apiladas
    // ═══════════════════════════════════════════════════════════════════════

    private fun renderPdfPages(containerWidth: Int) {
        val bytes = pdfBytes ?: return
        val tempFile = File(cacheDir, "digid_apply_${documentId}.pdf")
        FileOutputStream(tempFile).use { it.write(bytes) }
        val fd = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(fd)

        try {
            // 1. Calcular el ancho maximo de todas las paginas para escalar uniformemente
            var maxPageWidth = 0
            for (i in 0 until renderer.pageCount) {
                val page = renderer.openPage(i)
                if (page.width > maxPageWidth) maxPageWidth = page.width
                page.close()
            }
            if (maxPageWidth == 0) return

            val scale = containerWidth.toFloat() / maxPageWidth.toFloat()
            var currentY = 0f

            pageDetails.clear()
            pdfContainer.removeAllViews()

            for (i in 0 until renderer.pageCount) {
                val page = renderer.openPage(i)
                val renderedWidth = (page.width * scale)
                val renderedHeight = (page.height * scale)

                val bitmap = Bitmap.createBitmap(
                    renderedWidth.toInt().coerceAtLeast(1),
                    renderedHeight.toInt().coerceAtLeast(1),
                    Bitmap.Config.ARGB_8888
                )
                // Fondo blanco para paginas con transparencia
                Canvas(bitmap).drawColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                val imageView = ImageView(this).apply {
                    setImageBitmap(bitmap)
                    scaleType = ImageView.ScaleType.FIT_XY
                }
                val params = FrameLayout.LayoutParams(
                    renderedWidth.toInt(),
                    renderedHeight.toInt()
                )
                params.leftMargin = 0
                params.topMargin = currentY.toInt()
                pdfContainer.addView(imageView, params)

                val pageNumber = i + 1
                pageDetails[pageNumber] = PageDetail(
                    pageNumber = pageNumber,
                    renderedWidth = renderedWidth,
                    renderedHeight = renderedHeight,
                    originY = currentY,
                    originalWidth = page.width.toFloat(),
                    originalHeight = page.height.toFloat()
                )

                currentY += renderedHeight + 1f
                page.close()
            }

            // Forzar al FrameLayout a ocupar la altura total del stack de paginas
            val containerParams = pdfContainer.layoutParams
            containerParams.height = currentY.toInt()
            pdfContainer.layoutParams = containerParams
        } finally {
            renderer.close()
            fd.close()
            tempFile.delete()
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  Signature point navigation
    // ═══════════════════════════════════════════════════════════════════════

    private fun showCurrentSignaturePoint() {
        if (currentSignatureIndex >= totalSignatures) return

        val coordinate = signatureCoordinates?.optJSONObject(currentSignatureIndex) ?: return
        val pointNumber = currentSignatureIndex + 1
        val isLast = currentSignatureIndex == totalSignatures - 1

        progressText.text = "Firma $pointNumber de $totalSignatures"
        progressBar.progress = ((currentSignatureIndex.toFloat() / totalSignatures) * 100).toInt()

        btnAccept.text = if (isLast) "Confirmar y finalizar" else "Aceptar firma $pointNumber →"
        btnAccept.isEnabled = true

        val id = coordinate.optString("id", "sign_$currentSignatureIndex")
        showSignaturePreview(coordinate, id)
    }

    /**
     * Pinta la firma "activa" sobre el PDF con borde punteado, posicionada de forma
     * responsiva y respetando la rotacion del punto de firma (como hace iOS).
     */
    private fun showSignaturePreview(coordinate: JSONObject, id: String) {
        val pageNum = coordinate.optInt("pagina", coordinate.optInt("pageNumber", 1))
        val detail = pageDetails[pageNum] ?: return

        val xDoc = coordinate.optDouble("xDoc", 0.0).toFloat()
        val yDoc = coordinate.optDouble("ydoc", 0.0).toFloat()
        val anchoPagina = coordinate.optDouble(
            "AnchoPagina",
            coordinate.optDouble("anchoPagina", 1.0)
        ).toFloat().coerceAtLeast(1f)
        val altoPagina = coordinate.optDouble("altoPagina", 1.0)
            .toFloat().coerceAtLeast(1f)
        val positionStr = coordinate.optString("position", "0")
        val rotationDegrees = positionStr.toFloatOrNull() ?: 0f

        val scaleX = detail.renderedWidth / anchoPagina
        val scaleY = detail.renderedHeight / altoPagina

        val newX = xDoc * scaleX
        val newY = yDoc * scaleY + detail.originY

        val signWidthPx = 75.dpToPx()
        val signHeightPx = 47.dpToPx()

        val previewContainer = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 2.dpToPx().toFloat()
                setColor(Color.TRANSPARENT)
                // Borde punteado gris oscuro (igual que iOS lineDashPattern [4,3])
                setStroke(
                    2.dpToPx(),
                    Color.parseColor("#5C5C5C"),
                    4.dpToPx().toFloat(),
                    3.dpToPx().toFloat()
                )
            }
            // Desactivar hardware accel localmente para que los dashes se dibujen bien
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

        signatureBitmap?.let { bmp ->
            val imgView = ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            previewContainer.addView(
                imgView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        // Rotacion con ancla (0,0) top-left — equivalente al anchorPoint+position de iOS
        previewContainer.pivotX = 0f
        previewContainer.pivotY = 0f
        previewContainer.rotation = rotationDegrees
        previewContainer.translationX = newX
        previewContainer.translationY = newY

        val params = FrameLayout.LayoutParams(signWidthPx, signHeightPx)
        params.leftMargin = 0
        params.topMargin = 0
        pdfContainer.addView(previewContainer, params)

        signatureOverlays[id] = previewContainer

        // Auto-scroll hasta la firma, clampeado al contenido disponible
        scrollView.post {
            val visibleHeight = scrollView.height
            val contentHeight = pdfContainer.height
            val maxOffsetY = maxOf(0, contentHeight - visibleHeight)
            val idealOffset = maxOf(0, (newY - 50f).toInt())
            val clampedOffset = minOf(idealOffset, maxOffsetY)
            scrollView.smoothScrollTo(0, clampedOffset)
        }
    }

    /**
     * Al aceptar, reemplaza el preview con borde punteado por la firma "final"
     * (solo la imagen, sin borde). Mantiene la rotacion aplicada.
     */
    private fun confirmCurrentSignature() {
        val coordinate = signatureCoordinates?.optJSONObject(currentSignatureIndex) ?: return
        val id = coordinate.optString("id", "sign_$currentSignatureIndex")

        signatureOverlays[id]?.let { view ->
            pdfContainer.removeView(view)
        }
        signatureOverlays.remove(id)

        val pageNum = coordinate.optInt("pagina", coordinate.optInt("pageNumber", 1))
        val detail = pageDetails[pageNum] ?: return

        val xDoc = coordinate.optDouble("xDoc", 0.0).toFloat()
        val yDoc = coordinate.optDouble("ydoc", 0.0).toFloat()
        val anchoPagina = coordinate.optDouble(
            "AnchoPagina",
            coordinate.optDouble("anchoPagina", 1.0)
        ).toFloat().coerceAtLeast(1f)
        val altoPagina = coordinate.optDouble("altoPagina", 1.0)
            .toFloat().coerceAtLeast(1f)
        val positionStr = coordinate.optString("position", "0")
        val rotationDegrees = positionStr.toFloatOrNull() ?: 0f

        val scaleX = detail.renderedWidth / anchoPagina
        val scaleY = detail.renderedHeight / altoPagina

        val newX = xDoc * scaleX
        val newY = yDoc * scaleY + detail.originY

        val signWidthPx = 75.dpToPx()
        val signHeightPx = 47.dpToPx()

        val confirmedView = FrameLayout(this)
        signatureBitmap?.let { bmp ->
            val imgView = ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            confirmedView.addView(
                imgView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        confirmedView.pivotX = 0f
        confirmedView.pivotY = 0f
        confirmedView.rotation = rotationDegrees
        confirmedView.translationX = newX
        confirmedView.translationY = newY

        val params = FrameLayout.LayoutParams(signWidthPx, signHeightPx)
        params.leftMargin = 0
        params.topMargin = 0
        pdfContainer.addView(confirmedView, params)
        signatureOverlays["${id}_confirmed"] = confirmedView
    }

    private fun acceptCurrentSignature() {
        confirmCurrentSignature()
        signaturesApplied++
        if (currentSignatureIndex < totalSignatures - 1) {
            currentSignatureIndex++
            showCurrentSignaturePoint()
        } else {
            finishSignature()
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  Finish / cancel / delivery
    // ═══════════════════════════════════════════════════════════════════════

    @Suppress("DEPRECATION")
    private fun finishSignature() {
        val progressDialog = ProgressDialog(this).apply {
            setMessage("Finalizando firma...")
            setCancelable(false)
            show()
        }

        Thread {
            try {
                val deviceInfo = "Android/${android.os.Build.MODEL}/${android.os.Build.VERSION.RELEASE}"
                val docId = documentId.toIntOrNull() ?: 0
                val sigId = signerId.toIntOrNull() ?: 0
                val response = DigidAPIClient.finishSignature(docId, sigId, deviceInfo, null)

                runOnUiThread {
                    progressDialog.dismiss()
                    val sigApplied = response.optInt("signaturesApplied", totalSignatures)
                    val sigRequired = response.optInt("signaturesRequired", totalSignatures)
                    deliverSuccess(sigApplied, sigRequired)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progressDialog.dismiss()
                    deliverError(DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, e.message ?: "Error finishing signature"))
                }
            }
        }.start()
    }

    private fun showCancelConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Cancelar firma?")
            .setMessage("Si cancelas ahora, el documento NO quedara firmado.")
            .setPositiveButton("Si cancelas") { _, _ -> deliverCancelled() }
            .setNegativeButton("Continuar", null)
            .show()
    }

    private fun deliverSuccess(signaturesApplied: Int, signaturesRequired: Int) {
        val result = SignatureApplyResult(
            success = true,
            message = "Documento firmado exitosamente",
            signaturesApplied = signaturesApplied,
            signaturesRequired = signaturesRequired
        )
        setResult(RESULT_OK, Intent().putExtra(EXTRA_RESULT, result))
        finish()
    }

    private fun deliverCancelled() {
        val result = SignatureApplyResult(
            success = false,
            message = "Proceso cancelado por el usuario",
            signaturesApplied = signaturesApplied,
            signaturesRequired = totalSignatures
        )
        setResult(DigidResultCode.RESULT_CANCELLED, Intent().putExtra(EXTRA_RESULT, result))
        finish()
    }

    private fun deliverError(error: DigidException) {
        setResult(DigidResultCode.RESULT_ERROR, Intent().putExtra(EXTRA_ERROR, error))
        finish()
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()
}
