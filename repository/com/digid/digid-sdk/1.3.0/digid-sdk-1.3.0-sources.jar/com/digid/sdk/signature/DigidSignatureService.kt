package com.digid.sdk.signature

import android.graphics.Bitmap
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import com.digid.sdk.internal.DigidAPIClient
import com.digid.sdk.internal.DigidImageUtils

data class SignatureUploadResult(
    val success: Boolean,
    val message: String,
    val signatureUrl: String? = null,
    val missingFiles: List<String>? = null
)

object DigidSignatureService {

    fun uploadImages(
        documentId: Int,
        signerId: Int,
        signatureBitmap: Bitmap,
        idFrontBitmap: Bitmap? = null,
        idBackBitmap: Bitmap? = null,
        selfieBitmap: Bitmap? = null,
        callback: (Result<SignatureUploadResult>) -> Unit
    ) {
        Digid.requireInitialized()

        Thread {
            try {
                val sigBase64 = DigidImageUtils.resizedPngBase64(signatureBitmap, 96)
                val frontBase64 = idFrontBitmap?.let { DigidImageUtils.resizedPngBase64(it, 96) }
                val backBase64 = idBackBitmap?.let { DigidImageUtils.resizedPngBase64(it, 96) }
                val selfieBase64 = selfieBitmap?.let { DigidImageUtils.resizedPngBase64(it, 96) }

                val response = DigidAPIClient.uploadSignatureImage(
                    documentId = documentId,
                    signerId = signerId,
                    signatureBase64 = sigBase64,
                    idFrontBase64 = frontBase64,
                    idBackBase64 = backBase64,
                    selfieBase64 = selfieBase64
                )

                if (response.success) {
                    callback(Result.success(SignatureUploadResult(
                        success = true,
                        message = response.message ?: "Imágenes guardadas exitosamente.",
                        signatureUrl = response.signatureUrl,
                        missingFiles = response.missingFiles
                    )))
                } else {
                    callback(Result.failure(DigidException(
                        DigidErrorCode.UNKNOWN_ERROR,
                        response.error ?: "Error al guardar imágenes."
                    )))
                }
            } catch (e: Exception) {
                callback(Result.failure(
                    if (e is DigidException) e
                    else DigidException(DigidErrorCode.NETWORK_ERROR, e.message ?: "Error de red.")
                ))
            }
        }.start()
    }
}
