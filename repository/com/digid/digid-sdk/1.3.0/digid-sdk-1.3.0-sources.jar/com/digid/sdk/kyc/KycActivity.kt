package com.digid.sdk.kyc

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import com.digid.sdk.DigidResultCode
import com.digid.sdk.internal.DigidBaseActivity
import com.digid.sdk.internal.DigidSessionManager
import com.digid.sdk.internal.InternalKycResult
import com.digid.sdk.internal.KycResultHolder
import com.digid.sdk.internal.KycResultMapper

class KycActivity : DigidBaseActivity() {

    companion object {
        private const val TAG = "KycActivity"

        /** Identificador del usuario en el sistema del cliente. Requerido. */
        const val EXTRA_VENDOR_DATA = "digid_vendor_data"

        /** ID de sesión personalizado para trazabilidad. Opcional. */
        const val EXTRA_SESSION_ID = "digid_session_id"

        const val EXTRA_RESULT = KycResult.EXTRA_RESULT
        const val EXTRA_ERROR = KycResult.EXTRA_ERROR
    }

    private lateinit var vendorData: String
    private var sessionId: String? = null

    private lateinit var loadingLayout: LinearLayout
    private lateinit var loadingText: TextView
    private lateinit var loadingProgress: ProgressBar

    override fun onSdkReady() {
        setupLoadingUI()
        showLoading("Conectando con el servicio...")

        vendorData = intent.getStringExtra(EXTRA_VENDOR_DATA) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "El parámetro vendor_data es requerido."))
            return
        }
        sessionId = intent.getStringExtra(EXTRA_SESSION_ID)

        startAuthorizationFlow()
    }

    private fun startAuthorizationFlow() {
        showLoading("Verificando permisos...")

        DigidSessionManager.authorizeAndStartVerification(
            activity = this,
            vendorData = vendorData,
            sessionId = sessionId,
            callback = object : DigidSessionManager.KycFlowCallback {

                override fun onAuthorizationComplete() {
                    showLoading("Iniciando verificación...")
                }

                override fun onAuthorizationError(error: DigidException) {
                    Log.e(TAG, "Error de autorización: ${error.code} - ${error.message}")
                    deliverError(error)
                }

                override fun onVerificationComplete(result: InternalKycResult) {
                    val kycResult = KycResultMapper.mapFromInternal(
                        kycResult = result,
                        vendorData = vendorData,
                        sessionId = sessionId ?: result.sessionId
                    )
                    deliverSuccess(kycResult)
                }

                override fun onVerificationCancelled() {
                    deliverCancelled()
                }

                override fun onVerificationError(error: DigidException) {
                    deliverError(error)
                }
            }
        )
    }

    private fun setupLoadingUI() {
        val theme = Digid.theme

        loadingLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor(theme.backgroundColor))
            setPadding(64, 64, 64, 64)
        }

        loadingProgress = ProgressBar(this).apply {
            isIndeterminate = true
            try {
                indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(theme.primaryColor))
            } catch (_: Exception) { }
        }

        loadingText = TextView(this).apply {
            text = "Conectando..."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTypeface(null, Typeface.NORMAL)
            try {
                setTextColor(Color.parseColor(theme.primaryColor))
            } catch (_: Exception) {
                setTextColor(Color.DKGRAY)
            }
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 0)
        }

        loadingLayout.addView(loadingProgress)
        loadingLayout.addView(loadingText)
        setContentView(loadingLayout)
    }

    private fun showLoading(message: String) {
        if (::loadingText.isInitialized) {
            loadingText.text = message
            loadingLayout.visibility = View.VISIBLE
        }
    }

    private fun deliverSuccess(result: KycResult) {
        // KycResult con imágenes en base64 puede superar 1 MB → FAILED BINDER TRANSACTION.
        // Guardamos el resultado en KycResultHolder y devolvemos solo RESULT_OK sin datos.
        // El integrador lee el resultado con Digid.consumeKycResult().
        KycResultHolder.store(result)
        setResult(RESULT_OK)
        finish()
    }

    private fun deliverCancelled() {
        setResult(DigidResultCode.RESULT_CANCELLED)
        finish()
    }

    private fun deliverError(error: DigidException) {
        setResult(DigidResultCode.RESULT_ERROR, Intent().apply { putExtra(EXTRA_ERROR, error) })
        finish()
    }
}
