package com.digid.sdk.internal

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.digid.sdk.BuildConfig
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ConcurrentHashMap

internal object DigidAPIClient {

    private const val TAG = "DigidAPIClient"
    private val SDK_VERSION = BuildConfig.SDK_VERSION
    private const val PLATFORM = "android"

    data class UploadResponse(
        val success: Boolean,
        val message: String?,
        val error: String?,
        val signatureUrl: String? = null,
        val missingFiles: List<String>? = null
    )

    /**
     * Solicita autorización al backend para iniciar un flujo KYC.
     * El backend valida el token, verifica folios disponibles y genera un session token de Didit.
     *
     * POST /sdk/auth  |  Body: { "IdClient", "platform", "sdk_version" }
     */
    fun authorizeKycSession(clientId: String, vendorSessionId: String? = null): KycAuthResponse {
        val url = "${Digid.environment.baseUrl}sdk/auth"
        val body = KycAuthRequest(clientId = clientId, platform = PLATFORM, sdkVersion = SDK_VERSION, vendorSessionId = vendorSessionId)
        val conn = createConnection(url, "POST")
        try {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            OutputStreamWriter(conn.outputStream).use { it.write(body.toJson().toString()) }

            val responseCode = conn.responseCode
            val responseText = if (responseCode in 200..299) {
                conn.inputStream.bufferedReader().readText()
            } else {
                conn.errorStream?.bufferedReader()?.readText() ?: "{}"
            }

            return when (responseCode) {
                200 -> {
                    val json = JSONObject(responseText)
                    val authResponse = KycAuthResponse.fromJson(json)
                    if (authResponse.status.lowercase() == "authorized" && authResponse.session != null) {
                        Log.d(TAG, "Autorización KYC exitosa. Session: ${authResponse.session.sessionId}")
                        authResponse
                    } else if (authResponse.error != null) {
                        throw mapServerError(authResponse.error)
                    } else {
                        throw DigidException(DigidErrorCode.UNKNOWN_ERROR, "Respuesta inesperada del servidor.")
                    }
                }
                401 -> throw DigidException(DigidErrorCode.INVALID_TOKEN, "Token de acceso inválido o expirado.")
                403 -> throw DigidException(DigidErrorCode.INVALID_TOKEN, "No tienes permisos para usar este servicio.")
                429 -> throw DigidException(DigidErrorCode.NETWORK_ERROR, "Demasiadas solicitudes. Espera un momento e intenta de nuevo.")
                in 500..599 -> throw DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, "Error temporal del servidor.")
                else -> throw DigidException(DigidErrorCode.UNKNOWN_ERROR, "Error inesperado (HTTP $responseCode).")
            }
        } catch (e: DigidException) {
            throw e
        } catch (e: Exception) {
            throw DigidException(DigidErrorCode.NETWORK_ERROR, "Error de conexión con el servidor.", e.message)
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Consulta el estado de la verificación KYC.
     * Los datos completos llegan al backend vía webhook, este endpoint
     * retorna ready=true cuando están disponibles.
     *
     * GET /sdk/verification/{sessionId}
     */
    fun pollVerificationResult(sessionId: String): KycPollingResponse {
        val url = "${Digid.environment.baseUrl}sdk/verification/$sessionId"
        val conn = createConnection(url, "GET")
        try {
            val responseCode = conn.responseCode
            val responseText = if (responseCode in 200..299) {
                conn.inputStream.bufferedReader().readText()
            } else {
                conn.errorStream?.bufferedReader()?.readText() ?: "{}"
            }
            return when (responseCode) {
                200 -> KycPollingResponse.fromJson(JSONObject(responseText))
                401 -> throw DigidException(DigidErrorCode.INVALID_TOKEN, "Token inválido o expirado.")
                else -> throw DigidException(DigidErrorCode.UNKNOWN_ERROR, "Error al consultar verificación (HTTP $responseCode).")
            }
        } catch (e: DigidException) {
            throw e
        } catch (e: Exception) {
            throw DigidException(DigidErrorCode.NETWORK_ERROR, "Error de conexión al consultar verificación.", e.message)
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Descarga imágenes de verificación (frente INE, reverso, selfie) desde el backend.
     * Soporta rutas relativas (/api/sdk/image/...) y URLs absolutas.
     *
     * @return Mapa de clave ("front", "back", "selfie", "portrait") a Bitmap.
     */
    fun downloadVerificationImages(imageUrls: KycImageData): Map<String, Bitmap> {
        val results = ConcurrentHashMap<String, Bitmap>()
        val urlMap = listOf(
            "front" to imageUrls.frontImage,
            "back" to imageUrls.backImage,
            "selfie" to imageUrls.selfieImage,
            "portrait" to imageUrls.portraitImage
        ).filter { it.second != null && it.second!!.isNotEmpty() }

        if (urlMap.isEmpty()) return emptyMap()

        val latch = CountDownLatch(urlMap.size)

        for ((key, path) in urlMap) {
            Thread {
                try {
                    val fullUrl = if (path!!.startsWith("http")) path
                    else "${Digid.environment.baseUrl.trimEnd('/')}/${path.trimStart('/')}"

                    val conn = createConnection(fullUrl, "GET")
                    conn.setRequestProperty("Accept", "image/*")
                    try {
                        if (conn.responseCode == 200) {
                            val bytes = conn.inputStream.readBytes()
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { results[key] = it }
                        } else {
                            Log.w(TAG, "HTTP ${conn.responseCode} descargando imagen $key")
                        }
                    } finally {
                        conn.disconnect()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error descargando imagen $key: ${e.message}")
                } finally {
                    latch.countDown()
                }
            }.start()
        }

        latch.await()
        Log.d(TAG, "Imágenes descargadas: ${results.keys.joinToString()} (${results.size}/${urlMap.size})")
        return results
    }

    private fun mapServerError(error: KycServerError): DigidException {
        val code = when (error.code) {
            "INVALID_TOKEN" -> DigidErrorCode.INVALID_TOKEN
            "INVALID_PROCESS" -> DigidErrorCode.INVALID_PROCESS
            "CLIENT_SUSPENDED" -> DigidErrorCode.CLIENT_SUSPENDED
            "INSUFFICIENT_FOLIOS" -> DigidErrorCode.INSUFFICIENT_FOLIOS
            "RATE_LIMITED" -> DigidErrorCode.NETWORK_ERROR
            "DIDIT_SERVICE_ERROR" -> DigidErrorCode.VERIFICATION_SERVICE_ERROR
            "MAINTENANCE" -> DigidErrorCode.SERVICE_MAINTENANCE
            else -> DigidErrorCode.UNKNOWN_ERROR
        }
        return DigidException(code, error.message, "Server error code: ${error.code}")
    }

    fun downloadDocument(documentId: Int): ByteArray {
        val url = "${Digid.environment.baseUrl}sdk/signature/document/$documentId"
        val conn = createConnection(url, "GET")
        conn.setRequestProperty("Accept", "application/pdf")
        try {
            if (conn.responseCode !in 200..299) {
                throw DigidException(DigidErrorCode.NETWORK_ERROR, "Error descargando documento: HTTP ${conn.responseCode}")
            }
            return conn.inputStream.readBytes()
        } finally {
            conn.disconnect()
        }
    }

    fun uploadSignatureImage(
        documentId: Int,
        signerId: Int,
        signatureBase64: String,
        idFrontBase64: String? = null,
        idBackBase64: String? = null,
        selfieBase64: String? = null
    ): UploadResponse {
        val body = JSONObject().apply {
            put("document_id", documentId)
            put("signer_id", signerId)
            put("signature_image", signatureBase64)
            idFrontBase64?.let { put("id_front_image", it) }
            idBackBase64?.let { put("id_back_image", it) }
            selfieBase64?.let { put("selfie_image", it) }
        }
        return postJson("${Digid.environment.baseUrl}sdk/signature/upload", body)
    }

    fun uploadSelfie(documentId: Int, signerId: Int, selfieBase64: String): UploadResponse {
        val body = JSONObject().apply {
            put("document_id", documentId)
            put("signer_id", signerId)
            put("selfie_image", selfieBase64)
        }
        return postJson("${Digid.environment.baseUrl}sdk/signature/upload-selfie", body)
    }

    fun startSignature(documentId: Int, signerId: Int): JSONObject {
        val body = JSONObject().apply {
            put("document_id", documentId)
            put("signer_id", signerId)
        }
        return postJsonRaw("${Digid.environment.baseUrl}sdk/signature/start", body)
    }

    fun finishSignature(documentId: Int, signerId: Int, deviceInfo: String, gps: String? = null): JSONObject {
        val body = JSONObject().apply {
            put("document_id", documentId)
            put("signer_id", signerId)
            put("device_info", deviceInfo)
            gps?.let { put("gps", it) }
        }
        return postJsonRaw("${Digid.environment.baseUrl}sdk/signature/finish", body)
    }

    fun downloadSignatureImage(documentId: Int, signerId: Int): ByteArray {
        val url = "${Digid.environment.baseUrl}sdk/signature/image/$documentId/$signerId"
        val conn = createConnection(url, "GET")
        try {
            if (conn.responseCode !in 200..299) {
                throw DigidException(DigidErrorCode.NETWORK_ERROR, "Error descargando imagen de firma: HTTP ${conn.responseCode}")
            }
            return conn.inputStream.readBytes()
        } finally {
            conn.disconnect()
        }
    }

    private fun postJson(url: String, body: JSONObject): UploadResponse {
        val conn = createConnection(url, "POST")
        try {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
            val responseText = if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader().readText()
            } else {
                conn.errorStream?.bufferedReader()?.readText() ?: "{}"
            }
            val json = JSONObject(responseText)
            val missingFiles = json.optJSONArray("missing_files")?.let { arr ->
                (0 until arr.length()).map { arr.getString(it) }
            }
            return UploadResponse(
                success = json.optBoolean("success", false),
                message = json.optString("message", null),
                error = json.optString("error", null),
                signatureUrl = json.optString("signature_url", null),
                missingFiles = missingFiles
            )
        } finally {
            conn.disconnect()
        }
    }

    private fun postJsonRaw(url: String, body: JSONObject): JSONObject {
        val conn = createConnection(url, "POST")
        try {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
            val responseText = if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader().readText()
            } else {
                conn.errorStream?.bufferedReader()?.readText() ?: "{}"
            }
            return JSONObject(responseText)
        } finally {
            conn.disconnect()
        }
    }

    private fun createConnection(urlStr: String, method: String): HttpURLConnection {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 30_000
        conn.readTimeout = 30_000
        conn.setRequestProperty("Accept", "application/json")
        try {
            conn.setRequestProperty("Authorization", "Bearer ${Digid.getToken()}")
        } catch (_: Exception) {
            Log.w(TAG, "Token no disponible para la petición.")
        }
        return conn
    }
}
