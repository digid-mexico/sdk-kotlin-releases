package com.digid.sdk.terms

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.digid.sdk.R
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.digid.sdk.Digid
import com.digid.sdk.DigidTermsConfig

/**
 * Pantalla obligatoria de Términos y Condiciones.
 *
 * Mostrada automáticamente por [com.digid.sdk.internal.DigidBaseActivity] antes de cualquier
 * vista del SDK cuando los T&C no han sido aceptados en la sesión actual.
 *
 * Devuelve:
 * - [Activity.RESULT_OK] cuando el usuario acepta (checkbox marcado + pulsar "Continuar").
 * - [Activity.RESULT_CANCELED] cuando el usuario cancela o presiona Atrás.
 */
internal class TermsAcceptanceActivity : AppCompatActivity() {

    private lateinit var btnContinue: TextView
    private lateinit var checkBox: CheckBox
    private var isChecked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val theme = Digid.theme
        val primaryColor = Color.parseColor(theme.primaryColor)
        val bgColor = Color.parseColor(theme.backgroundColor)
        val termsConfig = Digid.termsConfig

        window.statusBarColor = primaryColor

        // ── Root ──────────────────────────────────────────────────────────────
        val root = FrameLayout(this)
        root.setBackgroundColor(bgColor)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(root)

        // ── Scrollable content ────────────────────────────────────────────────
        val scrollView = ScrollView(this)
        root.addView(scrollView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ).apply { bottomMargin = 124.dpToPx() })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24.dpToPx(), 32.dpToPx(), 24.dpToPx(), 24.dpToPx())
        }
        scrollView.addView(content)

        // ── Illustration ──────────────────────────────────────────────────────
        val illustration = ImageView(this).apply {
            setImageResource(R.drawable.ic_identity_illustration)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        content.addView(illustration, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = 24.dpToPx()
        })

        // ── Title ─────────────────────────────────────────────────────────────
        val title = TextView(this).apply {
            text = "Validación de Identidad"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1A1A2E"))
            gravity = Gravity.CENTER
        }
        content.addView(title, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // ── Teal accent underline ─────────────────────────────────────────────
        val accent = View(this).apply {
            val bg = GradientDrawable().apply {
                setColor(primaryColor)
                cornerRadius = 4f.dpToPx().toFloat()
            }
            background = bg
        }
        content.addView(accent, LinearLayout.LayoutParams(48.dpToPx(), 4.dpToPx()).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = 8.dpToPx()
            bottomMargin = 16.dpToPx()
        })

        // ── Description ───────────────────────────────────────────────────────
        val description = TextView(this).apply {
            text = "Su información será utilizada con el fin de validar su identidad. ¿Desea continuar?"
            textSize = 15f
            setTextColor(Color.parseColor("#555555"))
            gravity = Gravity.CENTER
            lineHeight = (15f * 1.55f * resources.displayMetrics.scaledDensity).toInt()
        }
        content.addView(description, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = 4.dpToPx()
            bottomMargin = 24.dpToPx()
        })

        // ── Horizontal divider ────────────────────────────────────────────────
        content.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#E0E0E0"))
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        ).apply { bottomMargin = 20.dpToPx() })

        // ── Checkbox row ──────────────────────────────────────────────────────
        checkBox = CheckBox(this).apply {
            setTextColor(Color.parseColor("#333333"))
            textSize = 14f
            buttonTintList = android.content.res.ColorStateList.valueOf(primaryColor)
        }

        val checkText = "He leído y Acepto los Términos y Condiciones"
        val termsLabel = "Términos y Condiciones"
        val spannable = SpannableString(checkText)
        val startIdx = checkText.indexOf(termsLabel)
        val endIdx = startIdx + termsLabel.length

        spannable.setSpan(
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    showTermsBottomSheet(termsConfig)
                }

                override fun updateDrawState(ds: TextPaint) {
                    super.updateDrawState(ds)
                    ds.color = primaryColor
                    ds.isUnderlineText = true
                    ds.isFakeBoldText = false
                }
            },
            startIdx, endIdx, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        checkBox.text = spannable
        checkBox.movementMethod = LinkMovementMethod.getInstance()
        checkBox.highlightColor = Color.TRANSPARENT

        checkBox.setOnCheckedChangeListener { _, checked ->
            isChecked = checked
            updateContinueButton()
        }

        content.addView(checkBox, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 8.dpToPx() })

        // ── Bottom button bar (fixed) ─────────────────────────────────────────
        val buttonBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(bgColor)
            elevation = 12f
            setPadding(16.dpToPx(), 16.dpToPx(), 16.dpToPx(), 16.dpToPx())
        }

        // "Cancelar" — outlined
        val btnCancel = buildButton(
            label = "Cancelar",
            filled = false,
            primaryColor = primaryColor
        ).apply {
            setOnClickListener {
                setResult(Activity.RESULT_CANCELED)
                finish()
            }
        }
        buttonBar.addView(btnCancel, LinearLayout.LayoutParams(
            0, 52.dpToPx(), 1f
        ).apply { marginEnd = 8.dpToPx() })

        // "Continuar" — filled (disabled until checkbox is checked)
        btnContinue = buildButton(
            label = "Continuar",
            filled = true,
            primaryColor = primaryColor
        ).apply {
            isEnabled = false
            alpha = 0.45f
            setOnClickListener {
                if (isChecked) {
                    setResult(Activity.RESULT_OK)
                    finish()
                }
            }
        }
        buttonBar.addView(btnContinue, LinearLayout.LayoutParams(
            0, 52.dpToPx(), 1f
        ).apply { marginStart = 8.dpToPx() })

        root.addView(buttonBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.BOTTOM })
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        setResult(Activity.RESULT_CANCELED)
        finish()
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun showTermsBottomSheet(config: DigidTermsConfig) {
        val sheet = TermsBottomSheetFragment.newInstance(config.termsText)
        sheet.onAccepted = {
            checkBox.isChecked = true
            isChecked = true
            updateContinueButton()
        }
        sheet.show(supportFragmentManager, TermsBottomSheetFragment.TAG)
    }

    private fun updateContinueButton() {
        btnContinue.isEnabled = isChecked
        btnContinue.alpha = if (isChecked) 1f else 0.45f
    }

    private fun buildButton(label: String, filled: Boolean, primaryColor: Int): TextView {
        return TextView(this).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = 10f.dpToPx().toFloat()
                if (filled) {
                    setColor(primaryColor)
                } else {
                    setColor(Color.TRANSPARENT)
                    setStroke(2.dpToPx(), primaryColor)
                }
            }
            background = bg
            setTextColor(if (filled) Color.WHITE else primaryColor)
        }
    }

    private fun Int.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()

    private fun Float.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()
}
