package com.digid.sdk.terms

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.text.HtmlCompat
import com.digid.sdk.Digid
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

/**
 * Panel deslizante que muestra el texto completo de los Términos y Condiciones.
 *
 * Se abre al tocar el hipervínculo "Términos y Condiciones" en [TermsAcceptanceActivity].
 * El usuario puede:
 * - Leer el texto completo desplazándose verticalmente.
 * - Pulsar "Aceptar TyC" para cerrar el panel y marcar el checkbox de la pantalla padre.
 * - Pulsar "Volver Arriba" para desplazarse al inicio del texto sin cerrar el panel.
 *
 * Uso:
 * ```kotlin
 * val sheet = TermsBottomSheetFragment.newInstance(termsText)
 * sheet.onAccepted = { /* marcar checkbox */ }
 * sheet.show(supportFragmentManager, TermsBottomSheetFragment.TAG)
 * ```
 */
internal class TermsBottomSheetFragment : BottomSheetDialogFragment() {

    companion object {
        const val TAG = "TermsBottomSheet"
        private const val ARG_TERMS_TEXT = "terms_text"

        fun newInstance(termsText: String): TermsBottomSheetFragment {
            return TermsBottomSheetFragment().apply {
                arguments = Bundle().apply { putString(ARG_TERMS_TEXT, termsText) }
            }
        }
    }

    /** Callback invocado cuando el usuario pulsa "Aceptar TyC". */
    var onAccepted: (() -> Unit)? = null

    private lateinit var scrollView: ScrollView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val termsText = arguments?.getString(ARG_TERMS_TEXT) ?: ""
        val theme = Digid.theme
        val primaryColor = Color.parseColor(theme.primaryColor)
        val bgColor = Color.parseColor(theme.backgroundColor)

        // ── Root ──────────────────────────────────────────────────────────────
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
            val bg = GradientDrawable().apply {
                setColor(bgColor)
                cornerRadii = floatArrayOf(24f.dpToPxF(), 24f.dpToPxF(), 24f.dpToPxF(), 24f.dpToPxF(), 0f, 0f, 0f, 0f)
            }
            background = bg
            setPadding(0, 12.dpToPx(), 0, 24.dpToPx())
        }

        // ── Handle indicator ──────────────────────────────────────────────────
        val handle = View(requireContext()).apply {
            val handleBg = GradientDrawable().apply {
                setColor(Color.parseColor("#DDDDDD"))
                cornerRadius = 4f.dpToPx().toFloat()
            }
            background = handleBg
        }
        root.addView(handle, LinearLayout.LayoutParams(48.dpToPx(), 4.dpToPx()).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setMargins(0, 0, 0, 16.dpToPx())
        })

        // ── "ACUERDO" label ───────────────────────────────────────────────────
        val labelAcuerdo = TextView(requireContext()).apply {
            text = "ACUERDO"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(primaryColor)
            gravity = Gravity.CENTER_HORIZONTAL
            letterSpacing = 0.12f
        }
        root.addView(labelAcuerdo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(24.dpToPx(), 4.dpToPx(), 24.dpToPx(), 4.dpToPx()) })

        // ── Title: "Términos y Condiciones" ───────────────────────────────────
        val title = TextView(requireContext()).apply {
            text = "Términos y Condiciones"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1A1A2E"))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(title, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(24.dpToPx(), 4.dpToPx(), 24.dpToPx(), 4.dpToPx()) })

        // ── Subtitle ──────────────────────────────────────────────────────────
        val subtitle = TextView(requireContext()).apply {
            text = "Página Web y plataforma de firmas"
            textSize = 14f
            setTextColor(Color.parseColor("#888888"))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(subtitle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(24.dpToPx(), 2.dpToPx(), 24.dpToPx(), 12.dpToPx()) })

        // ── Divider ───────────────────────────────────────────────────────────
        root.addView(divider(), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        ).apply { setMargins(16.dpToPx(), 0, 16.dpToPx(), 0) })

        // ── Scrollable T&C content ────────────────────────────────────────────
        scrollView = ScrollView(requireContext()).apply {
            isVerticalScrollBarEnabled = true
        }

        val termsContent = TextView(requireContext()).apply {
            // Renderiza HTML: <b> para subtítulos, <a href> para enlaces, <br> para saltos
            text = HtmlCompat.fromHtml(termsText, HtmlCompat.FROM_HTML_MODE_COMPACT)
            textSize = 14f
            setTextColor(Color.parseColor("#333333"))
            lineHeight = (14f * 1.6f * resources.displayMetrics.scaledDensity).toInt()
            setPadding(24.dpToPx(), 16.dpToPx(), 24.dpToPx(), 16.dpToPx())
            // Necesario para que los <a href> sean clickeables
            movementMethod = LinkMovementMethod.getInstance()
            highlightColor = Color.TRANSPARENT
        }
        scrollView.addView(termsContent)

        root.addView(scrollView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        // ── Buttons ───────────────────────────────────────────────────────────
        root.addView(divider(), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        ).apply { setMargins(16.dpToPx(), 8.dpToPx(), 16.dpToPx(), 0) })

        // "Aceptar TyC" — filled
        val btnAccept = buildButton(
            label = "Aceptar TyC",
            filled = true,
            primaryColor = primaryColor
        ).apply {
            setOnClickListener {
                onAccepted?.invoke()
                dismiss()
            }
        }
        root.addView(btnAccept, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 48.dpToPx()
        ).apply { setMargins(16.dpToPx(), 12.dpToPx(), 16.dpToPx(), 8.dpToPx()) })

        // "Volver Arriba" — outlined
        val btnScrollTop = buildButton(
            label = "Volver Arriba",
            filled = false,
            primaryColor = primaryColor
        ).apply {
            setOnClickListener {
                scrollView.smoothScrollTo(0, 0)
            }
        }
        root.addView(btnScrollTop, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 48.dpToPx()
        ).apply { setMargins(16.dpToPx(), 0, 16.dpToPx(), 8.dpToPx()) })

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Expandir el bottom sheet al 90% de la pantalla al abrirse
        (dialog as? BottomSheetDialog)?.let { dialog ->
            dialog.setOnShowListener {
                val bottomSheet = dialog.findViewById<FrameLayout>(
                    com.google.android.material.R.id.design_bottom_sheet
                )
                bottomSheet?.let { sheet ->
                    val behavior = BottomSheetBehavior.from(sheet)
                    val displayHeight = resources.displayMetrics.heightPixels
                    behavior.peekHeight = (displayHeight * 0.9f).toInt()
                    behavior.state = BottomSheetBehavior.STATE_EXPANDED
                }
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun divider() = View(requireContext()).apply {
        setBackgroundColor(Color.parseColor("#E8E8E8"))
    }

    private fun buildButton(label: String, filled: Boolean, primaryColor: Int): TextView {
        return TextView(requireContext()).apply {
            text = label
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = 8f.dpToPx().toFloat()
                if (filled) {
                    setColor(primaryColor)
                } else {
                    setColor(Color.TRANSPARENT)
                    setStroke(2.dpToPx(), primaryColor)
                }
            }
            background = bg
            setTextColor(if (filled) Color.WHITE else primaryColor)
        }
    }

    private fun Int.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()

    private fun Float.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()

    /** Versión que devuelve Float, necesaria donde la API espera FloatArray (ej. cornerRadii). */
    private fun Float.dpToPxF(): Float =
        this * resources.displayMetrics.density
}
