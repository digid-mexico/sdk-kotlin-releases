package com.digid.sdk.signature

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import com.digid.sdk.DigidResultCode
import com.digid.sdk.internal.DigidAPIClient
import com.digid.sdk.internal.DigidBaseActivity
import com.digid.sdk.signature.internal.SignatureCanvasView

/**
 * Vista 2 — Captura de Firma.
 *
 * Presenta un lienzo en blanco donde el usuario dibuja su firma con el dedo.
 * El SDK gestiona internamente:
 * - Lienzo de dibujo táctil con trazos suaves (Bezier) y coordenadas normalizadas
 *   para que la firma no se deforme al rotar el dispositivo.
 * - Portrait: canvas con proporción ~0.55 y botones (Limpiar / Confirmar) al pie.
 * - Landscape: canvas ocupa la parte izquierda y un panel derecho con primaryColor
 *   muestra el título, hint y botones en columna.
 *
 * Al confirmar, el SDK cierra la vista y entrega la imagen PNG en Base64.
 */
class SignatureCaptureActivity : DigidBaseActivity() {

    companion object {
        private const val TAG = "SignatureCaptureAct"
        const val EXTRA_DOCUMENT_ID  = "digid_document_id"
        const val EXTRA_CLIENT_ID    = "digid_client_id"
        const val EXTRA_SIGNER_ID    = "digid_signer_id"
        const val EXTRA_INE_FRONT_BASE64 = "digid_ine_front_base64"
        const val EXTRA_INE_BACK_BASE64  = "digid_ine_back_base64"
        const val EXTRA_SELFIE_BASE64    = "digid_selfie_base64"
        const val EXTRA_RESULT = SignatureCaptureResult.EXTRA_RESULT
        const val EXTRA_ERROR  = SignatureCaptureResult.EXTRA_ERROR
        private const val LANDSCAPE_PANEL_DP = 230
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    // ── Extras ────────────────────────────────────────────────────────────────
    private lateinit var documentId: String
    private lateinit var clientId: String
    private lateinit var signerId: String
    private var ineFrontBase64: String? = null
    private var ineBackBase64: String? = null
    private var selfieBase64: String? = null

    // ── Colors ────────────────────────────────────────────────────────────────
    private var primaryColor: Int = Color.parseColor("#1A3C6E")
    private var secondaryColor: Int = Color.parseColor("#2D8CF0")
    private var bgColor: Int = Color.WHITE

    // ── Root view + insets (guardados para reaplica en rotación) ─────────────
    private lateinit var outerRoot: FrameLayout
    private var lastSystemInsets: androidx.core.graphics.Insets? = null

    // ── Shared canvas content (reparented on rotation) ────────────────────────
    private lateinit var canvasContent: FrameLayout   // wraps canvasView + watermark
    private lateinit var canvasView: SignatureCanvasView
    private lateinit var watermark: TextView

    // ── Toolbar content layers (same RelativeLayout, toggled by orientation) ──
    private lateinit var toolbarPortraitLayer: View
    private lateinit var toolbarLandscapeLayer: View

    // ── Portrait views ─────────────────────────────────────────────────────────
    private lateinit var portraitRoot: LinearLayout
    private lateinit var portraitCanvasSlot: FrameLayout
    private lateinit var portraitBtnClear: Button
    private lateinit var portraitBtnConfirm: Button
    private lateinit var loadingBar: ProgressBar

    // ── Landscape views ────────────────────────────────────────────────────────
    private lateinit var landscapeRoot: FrameLayout
    private lateinit var landscapeCanvasSlot: FrameLayout
    private lateinit var landscapeBtnClear: Button
    private lateinit var landscapeBtnConfirm: Button

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onSdkReady() {
        documentId = intent.getStringExtra(EXTRA_DOCUMENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "document_id es requerido.")); return
        }
        clientId = intent.getStringExtra(EXTRA_CLIENT_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "client_id es requerido.")); return
        }
        signerId = intent.getStringExtra(EXTRA_SIGNER_ID) ?: run {
            deliverError(DigidException(DigidErrorCode.UNKNOWN_ERROR, "signer_id es requerido.")); return
        }
        ineFrontBase64 = intent.getStringExtra(EXTRA_INE_FRONT_BASE64)
        ineBackBase64  = intent.getStringExtra(EXTRA_INE_BACK_BASE64)
        selfieBase64   = intent.getStringExtra(EXTRA_SELFIE_BASE64)

        val theme = Digid.theme
        primaryColor   = Color.parseColor(theme.primaryColor)
        secondaryColor = Color.parseColor(theme.secondaryColor)
        bgColor        = Color.parseColor(theme.backgroundColor)

        window.statusBarColor = primaryColor

        buildUI()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateLayout()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { deliverCancelled() }

    // ── UI Construction ───────────────────────────────────────────────────────

    private fun buildUI() {
        outerRoot = FrameLayout(this)
        outerRoot.setBackgroundColor(bgColor)
        setContentView(outerRoot)

        ViewCompat.setOnApplyWindowInsetsListener(outerRoot) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            lastSystemInsets = sys
            applySystemInsets()
            insets
        }

        // ── Toolbar (always visible) ──
        val toolbar = buildToolbar()
        outerRoot.addView(toolbar, FrameLayout.LayoutParams(MATCH, 56.dp).apply {
            gravity = Gravity.TOP
        })

        // ── Shared canvas content ──
        buildCanvasContent()

        // ── Portrait / landscape bodies ──
        buildPortraitBody()
        buildLandscapeBody()

        val body = FrameLayout(this)
        body.addView(portraitRoot,   FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(landscapeRoot,  FrameLayout.LayoutParams(MATCH, MATCH))
        outerRoot.addView(body, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            topMargin = 56.dp
        })

        updateLayout()
    }

    /**
     * Aplica los insets del sistema al root.
     * En portrait respeta el top (cámara/notch + barra de estado).
     * En landscape suprime el top para que el contenido ocupe todo el alto.
     */
    private fun applySystemInsets() {
        val sys = lastSystemInsets ?: return
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val topPadding = if (isLandscape) 0 else sys.top
        outerRoot.setPadding(sys.left, topPadding, sys.right, sys.bottom)
    }

    private fun buildToolbar(): RelativeLayout {
        val toolbar = RelativeLayout(this).apply {
            setBackgroundColor(primaryColor)
        }

        // ── Portrait layer: logo? + "Captura de Firma" left, "Cancelar" right ──
        val portraitLayer = RelativeLayout(this).apply {
            setPadding(16.dp, 0, 16.dp, 0)
        }

        val pTitleParams = RelativeLayout.LayoutParams(WRAP, WRAP).apply {
            addRule(RelativeLayout.CENTER_VERTICAL)
        }
        Digid.theme.logoResId?.let { resId ->
            val logo = ImageView(this).apply {
                setImageResource(resId); adjustViewBounds = true; id = View.generateViewId()
            }
            portraitLayer.addView(logo, RelativeLayout.LayoutParams(32.dp, 32.dp).apply {
                addRule(RelativeLayout.CENTER_VERTICAL); marginEnd = 8.dp
            })
            pTitleParams.addRule(RelativeLayout.END_OF, logo.id)
        }
        portraitLayer.addView(TextView(this).apply {
            text = "Captura de Firma"; setTextColor(Color.WHITE)
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD
        }, pTitleParams)
        portraitLayer.addView(Button(this).apply {
            text = "Cancelar"; setTextColor(Color.WHITE); background = null
            setOnClickListener { deliverCancelled() }
        }, RelativeLayout.LayoutParams(WRAP, WRAP).apply {
            addRule(RelativeLayout.ALIGN_PARENT_END); addRule(RelativeLayout.CENTER_VERTICAL)
        })
        toolbarPortraitLayer = portraitLayer
        toolbar.addView(portraitLayer, RelativeLayout.LayoutParams(MATCH, MATCH))

        // ── Landscape layer: "Área de firma" left, "Captura de Firma" + "Cancelar" right ──
        val landscapeLayer = RelativeLayout(this).apply {
            setPadding(16.dp, 0, 16.dp, 0)
            visibility = View.GONE
        }
        val areaLabel = TextView(this).apply {
            text = "Área de firma"; setTextColor(Color.WHITE)
            textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            id = View.generateViewId()
        }
        val cancelBtnLandscape = Button(this).apply {
            text = "Cancelar"; setTextColor(Color.WHITE); background = null
            id = View.generateViewId()
            setOnClickListener { deliverCancelled() }
        }
        val titleLandscape = TextView(this).apply {
            text = "Captura de Firma"; setTextColor(Color.WHITE); textSize = 15f
        }
        landscapeLayer.addView(areaLabel, RelativeLayout.LayoutParams(WRAP, WRAP).apply {
            addRule(RelativeLayout.ALIGN_PARENT_START); addRule(RelativeLayout.CENTER_VERTICAL)
        })
        landscapeLayer.addView(cancelBtnLandscape, RelativeLayout.LayoutParams(WRAP, WRAP).apply {
            addRule(RelativeLayout.ALIGN_PARENT_END); addRule(RelativeLayout.CENTER_VERTICAL)
        })
        landscapeLayer.addView(titleLandscape, RelativeLayout.LayoutParams(WRAP, WRAP).apply {
            addRule(RelativeLayout.START_OF, cancelBtnLandscape.id)
            addRule(RelativeLayout.CENTER_VERTICAL)
            marginEnd = 4.dp
        })
        toolbarLandscapeLayer = landscapeLayer
        toolbar.addView(landscapeLayer, RelativeLayout.LayoutParams(MATCH, MATCH))

        return toolbar
    }

    /**
     * Crea el contenedor del canvas y el watermark.
     * Este FrameLayout se reparenta entre portrait y landscape en [updateLayout].
     */
    private fun buildCanvasContent() {
        canvasView = SignatureCanvasView(this)

        watermark = TextView(this).apply {
            text = "Firma aquí"
            setTextColor(Color.parseColor("#B0B0B0"))
            textSize = 28f
            gravity = Gravity.CENTER
        }

        val baselineLine = View(this).apply {
            setBackgroundColor(Color.parseColor("#CCCCCC"))
        }

        canvasContent = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                setStroke(1.dp, Color.parseColor("#CCCCCC"))
                cornerRadius = 8f.dp
            }
            elevation = 4f
        }
        canvasContent.addView(watermark, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            gravity = Gravity.CENTER
        })
        canvasContent.addView(canvasView, FrameLayout.LayoutParams(MATCH, MATCH))
        canvasContent.addView(baselineLine, FrameLayout.LayoutParams(MATCH, 1).apply {
            gravity = Gravity.BOTTOM
            bottomMargin = 30.dp
        })

        canvasView.onSignatureChangedListener = object : SignatureCanvasView.OnSignatureChangedListener {
            override fun onSignatureChanged(hasContent: Boolean) {
                watermark.visibility = if (hasContent) View.INVISIBLE else View.VISIBLE
                updateButtons(hasContent)
            }
        }
    }

    /** Construye el cuerpo portrait: ScrollView (hint + canvas) + barra de botones. */
    private fun buildPortraitBody() {
        portraitRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val scrollView = ScrollView(this).apply { isScrollbarFadingEnabled = true }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24.dp, 16.dp, 24.dp, 16.dp)
        }

        content.addView(TextView(this).apply {
            text = "Dibuje su firma en el recuadro inferior. Asegúrese de que coincida con la de su identificación."
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setTextColor(Color.parseColor("#333333"))
            textSize = 15f
        }, LinearLayout.LayoutParams(MATCH, WRAP))

        content.addView(View(this), LinearLayout.LayoutParams(MATCH, 16.dp))

        portraitCanvasSlot = FrameLayout(this)
        content.addView(portraitCanvasSlot, LinearLayout.LayoutParams(MATCH, 220.dp))

        scrollView.addView(content)

        // Buttons bar (floating at bottom)
        val buttonsBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(bgColor)
            setPadding(24.dp, 12.dp, 24.dp, 12.dp)
            elevation = 4f
        }

        portraitBtnClear = makeButton(ButtonStyle.OUTLINED_SECONDARY, "Limpiar")
        portraitBtnClear.isEnabled = false
        portraitBtnClear.setOnClickListener { clearCanvas() }

        portraitBtnConfirm = makeButton(ButtonStyle.FILLED_PRIMARY, "Confirmar firma")
        portraitBtnConfirm.isEnabled = false
        applyConfirmAppearance(portraitBtnConfirm, enabled = false, whiteStyle = false)
        portraitBtnConfirm.setOnClickListener { confirmSignature() }

        loadingBar = ProgressBar(this).apply { visibility = View.GONE }

        buttonsBar.addView(portraitBtnClear, LinearLayout.LayoutParams(WRAP, 48.dp).apply {
            marginEnd = 12.dp
        })
        buttonsBar.addView(portraitBtnConfirm, LinearLayout.LayoutParams(0, 48.dp, 1f))
        buttonsBar.addView(loadingBar, LinearLayout.LayoutParams(48.dp, 48.dp).apply {
            marginStart = 8.dp
        })

        portraitRoot.addView(scrollView,    LinearLayout.LayoutParams(MATCH, 0, 1f))
        portraitRoot.addView(buttonsBar,    LinearLayout.LayoutParams(MATCH, WRAP))
    }

    /** Construye el cuerpo landscape: canvas izquierda + panel derecho primaryColor. */
    private fun buildLandscapeBody() {
        landscapeRoot = FrameLayout(this)

        // Canvas slot: ocupa todo el ancho menos el panel derecho
        landscapeCanvasSlot = FrameLayout(this).apply {
            setPadding(16.dp, 16.dp, 16.dp, 16.dp)
        }

        // Panel derecho — el título ("Área de firma") ya está en el toolbar landscape
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(primaryColor)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(20.dp, 20.dp, 20.dp, 20.dp)
        }

        panel.addView(TextView(this).apply {
            text = "Dibuje su firma en el recuadro. Asegúrese de que coincida con la de su identificación."
            setTextColor(Color.parseColor("#CCFFFFFF"))
            textSize = 13f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH, WRAP))

        // Spacer flexible
        panel.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        landscapeBtnClear = makeButton(ButtonStyle.OUTLINED_WHITE, "Limpiar")
        landscapeBtnClear.isEnabled = false
        landscapeBtnClear.setOnClickListener { clearCanvas() }

        landscapeBtnConfirm = makeButton(ButtonStyle.FILLED_WHITE, "Confirmar firma")
        landscapeBtnConfirm.isEnabled = false
        applyConfirmAppearance(landscapeBtnConfirm, enabled = false, whiteStyle = true)
        landscapeBtnConfirm.setOnClickListener { confirmSignature() }

        panel.addView(landscapeBtnClear, LinearLayout.LayoutParams(MATCH, 44.dp).apply {
            bottomMargin = 8.dp
        })
        panel.addView(landscapeBtnConfirm, LinearLayout.LayoutParams(MATCH, 48.dp))

        landscapeRoot.addView(landscapeCanvasSlot, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            marginEnd = LANDSCAPE_PANEL_DP.dp
        })
        landscapeRoot.addView(panel, FrameLayout.LayoutParams(LANDSCAPE_PANEL_DP.dp, MATCH).apply {
            gravity = Gravity.END
        })
    }

    /**
     * Muestra el cuerpo correcto y reparenta [canvasContent] al slot correspondiente.
     * Se llama en [onCreate] y en [onConfigurationChanged].
     */
    private fun updateLayout() {
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        // Toolbar: alterna entre capa portrait y landscape
        toolbarPortraitLayer.visibility  = if (isLandscape) View.GONE    else View.VISIBLE
        toolbarLandscapeLayer.visibility = if (isLandscape) View.VISIBLE else View.GONE

        portraitRoot.visibility   = if (isLandscape) View.GONE  else View.VISIBLE
        landscapeRoot.visibility  = if (isLandscape) View.VISIBLE else View.GONE

        // Reaplica insets: en landscape suprime el top padding (sin franja blanca)
        applySystemInsets()

        val targetSlot = if (isLandscape) landscapeCanvasSlot else portraitCanvasSlot

        if (canvasContent.parent !== targetSlot) {
            (canvasContent.parent as? ViewGroup)?.removeView(canvasContent)
            targetSlot.addView(canvasContent, FrameLayout.LayoutParams(MATCH, MATCH))
        }

        // Ajustar la altura del canvas portrait al ~55% del ancho disponible
        if (!isLandscape) {
            portraitCanvasSlot.post {
                val targetH = (portraitCanvasSlot.width * 0.55).toInt()
                if (targetH > 0) {
                    val lp = portraitCanvasSlot.layoutParams as? LinearLayout.LayoutParams ?: return@post
                    if (lp.height != targetH) {
                        lp.height = targetH
                        portraitCanvasSlot.layoutParams = lp
                    }
                }
            }
        }
    }

    // ── Button factory ────────────────────────────────────────────────────────

    private enum class ButtonStyle {
        OUTLINED_SECONDARY,   // borde secondaryColor, texto secondaryColor  (portrait clear)
        OUTLINED_WHITE,       // borde blanco, texto blanco                  (landscape clear)
        FILLED_PRIMARY,       // fondo primaryColor, texto blanco            (portrait confirm)
        FILLED_WHITE          // fondo blanco, texto primaryColor            (landscape confirm)
    }

    private fun makeButton(style: ButtonStyle, label: String): Button {
        return Button(this).apply {
            text = label
            minimumWidth = 0; minWidth = 0
            minimumHeight = 0; minHeight = 0
            setPadding(16.dp, 0, 16.dp, 0)

            when (style) {
                ButtonStyle.OUTLINED_SECONDARY -> {
                    setTextColor(secondaryColor)
                    background = GradientDrawable().apply {
                        setColor(Color.TRANSPARENT)
                        setStroke(1.dp, secondaryColor)
                        cornerRadius = 4f.dp
                    }
                }
                ButtonStyle.OUTLINED_WHITE -> {
                    setTextColor(Color.WHITE)
                    background = GradientDrawable().apply {
                        setColor(Color.TRANSPARENT)
                        setStroke(1.dp, Color.WHITE)
                        cornerRadius = 4f.dp
                    }
                }
                ButtonStyle.FILLED_PRIMARY -> {
                    setTextColor(Color.WHITE)
                    background = GradientDrawable().apply {
                        setColor(primaryColor)
                        cornerRadius = 4f.dp
                    }
                }
                ButtonStyle.FILLED_WHITE -> {
                    setTextColor(primaryColor)
                    background = GradientDrawable().apply {
                        setColor(Color.WHITE)
                        cornerRadius = 4f.dp
                    }
                }
            }
        }
    }

    private fun applyConfirmAppearance(btn: Button, enabled: Boolean, whiteStyle: Boolean) {
        btn.alpha = if (enabled) 1.0f else 0.5f
        if (!whiteStyle) {
            // Portrait: fondo cambia entre primary y gris
            val color = if (enabled) primaryColor else Color.parseColor("#CCCCCC")
            (btn.background as? GradientDrawable)?.setColor(color)
        }
    }

    // ── State helpers ─────────────────────────────────────────────────────────

    private fun updateButtons(hasContent: Boolean) {
        portraitBtnClear.isEnabled = hasContent
        portraitBtnConfirm.isEnabled = hasContent
        applyConfirmAppearance(portraitBtnConfirm, hasContent, whiteStyle = false)

        landscapeBtnClear.isEnabled = hasContent
        landscapeBtnConfirm.isEnabled = hasContent
        applyConfirmAppearance(landscapeBtnConfirm, hasContent, whiteStyle = true)
    }

    private fun clearCanvas() {
        canvasView.clear()
        watermark.visibility = View.VISIBLE
    }

    private fun setLoading(loading: Boolean) {
        loadingBar.visibility = if (loading) View.VISIBLE else View.GONE
        val hasContent = canvasView.hasContent && !loading
        portraitBtnConfirm.isEnabled = hasContent
        portraitBtnClear.isEnabled = hasContent
        landscapeBtnConfirm.isEnabled = hasContent
        landscapeBtnClear.isEnabled = hasContent
    }

    // ── Confirm / Upload ──────────────────────────────────────────────────────

    private fun confirmSignature() {
        if (!canvasView.hasContent) return
        val signatureBase64 = canvasView.exportToBase64()
        uploadSignatureToServer(signatureBase64)
    }

    private fun uploadSignatureToServer(signatureBase64: String) {
        setLoading(true)

        Thread {
            try {
                val docId = documentId.toIntOrNull() ?: 0
                val sigId = signerId.toIntOrNull() ?: 0
                val response = DigidAPIClient.uploadSignatureImage(
                    documentId     = docId,
                    signerId       = sigId,
                    signatureBase64 = signatureBase64,
                    idFrontBase64  = ineFrontBase64,
                    idBackBase64   = ineBackBase64,
                    selfieBase64   = selfieBase64
                )
                Log.d(TAG, "Upload response: $response")
                runOnUiThread {
                    setLoading(false)
                    if (response.success) {
                        deliverSuccess(signatureBase64)
                    } else {
                        updateButtons(true)
                        showUploadError(response.error ?: "Error al guardar la firma.")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Upload error: ${e.message}", e)
                runOnUiThread {
                    setLoading(false)
                    updateButtons(true)
                    showUploadError("Error de red: ${e.message}")
                }
            }
        }.start()
    }

    private fun showUploadError(message: String) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("Reintentar") { _, _ -> confirmSignature() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── Result delivery ───────────────────────────────────────────────────────

    private fun deliverSuccess(signatureBase64: String) {
        val result = SignatureCaptureResult(
            success = true,
            message = "Firma capturada y guardada exitosamente.",
            signatureBase64 = signatureBase64
        )
        setResult(RESULT_OK, Intent().putExtra(EXTRA_RESULT, result))
        finish()
    }

    private fun deliverCancelled() {
        val result = SignatureCaptureResult(
            success = false,
            message = "Proceso cancelado por el usuario.",
            signatureBase64 = ""
        )
        setResult(DigidResultCode.RESULT_CANCELLED, Intent().putExtra(EXTRA_RESULT, result))
        finish()
    }

    private fun deliverError(error: DigidException) {
        setResult(DigidResultCode.RESULT_ERROR, Intent().putExtra(EXTRA_ERROR, error))
        finish()
    }

    // ── Extensions ────────────────────────────────────────────────────────────
    private val Int.dp:   Int   get() = (this * resources.displayMetrics.density).toInt()
    private val Float.dp: Float get() = this * resources.displayMetrics.density
}
