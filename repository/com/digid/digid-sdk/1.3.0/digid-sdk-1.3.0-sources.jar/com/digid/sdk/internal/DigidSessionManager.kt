package com.digid.sdk.internal

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import com.digid.sdk.BuildConfig
import com.digid.sdk.Digid
import com.digid.sdk.DigidEnvironment
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import me.didit.sdk.DiditSdk
import me.didit.sdk.DiditSdkState
import me.didit.sdk.Configuration
import me.didit.sdk.VerificationResult
import me.didit.sdk.core.localization.SupportedLanguage
import java.io.ByteArrayOutputStream

/**
 * Capa de abstracción entre la API pública de Digid y el SDK de verificación externo.
 *
 * Flujo completo:
 * 1. POST /sdk/auth → backend valida token, verifica folios, genera session token.
 * 2. Inicia verificación biométrica con el SDK externo.
 * 3. Al completar, el SDK retorna sessionId y status.
 * 4. GET /sdk/verification/{sessionId} (polling) → datos completos llegan vía webhook al backend.
 * 5. Cuando ready=true, descarga imágenes y construye resultado final.
 */
internal object DigidSessionManager {

    private const val TAG = "DigidSessionManager"

    private var isInitialized = false
    private lateinit var environment: DigidEnvironment

    private var currentSessionToken: String? = null
    private var currentSessionData: KycSessionData? = null
    private var currentVendorData: String? = null
    private var currentCallback: KycFlowCallback? = null

    // Prevents callbacks from reaching a destroyed Activity when auth takes
    // longer than the Activity lifecycle. Set to true by cancelCurrentSession().
    @Volatile private var isCancelled = false

    private const val POLLING_INTERVAL_MS = 3000L
    private const val MAX_POLLING_ATTEMPTS = 20

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pollingAttempts = 0
    private var stateObserverJob: Job? = null

    internal interface KycFlowCallback {
        fun onAuthorizationComplete()
        fun onAuthorizationError(error: DigidException)
        fun onVerificationComplete(result: InternalKycResult)
        fun onVerificationCancelled()
        fun onVerificationError(error: DigidException)
    }

    fun initialize(context: Context, token: String, environment: DigidEnvironment) {
        this.environment = environment
        DiditSdk.initialize(context)
        isInitialized = true
        Log.d(TAG, "Servicio de verificación inicializado. Ambiente: $environment")
    }

    /**
     * Solicita autorización al backend y, si es exitosa, lanza el flujo de verificación.
     * Se ejecuta en background; los callbacks se entregan en el hilo principal.
     */
    fun authorizeAndStartVerification(
        activity: Activity,
        vendorData: String,
        sessionId: String?,
        callback: KycFlowCallback
    ) {
        check(isInitialized) { "DigidSessionManager no inicializado" }

        isCancelled = false
        this.currentCallback = callback
        this.currentVendorData = vendorData

        Log.d(TAG, "Solicitando autorización al backend...")

        Thread {
            try {
                val authResponse = DigidAPIClient.authorizeKycSession(Digid.clientId, sessionId)

                val sessionData = authResponse.session
                    ?: throw DigidException(
                        DigidErrorCode.VERIFICATION_SERVICE_ERROR,
                        "El servidor no devolvió datos de sesión válidos."
                    )

                currentSessionToken = sessionData.sessionToken
                currentSessionData = sessionData

                Log.d(TAG, "Autorización exitosa. Folios: ${authResponse.clientInfo?.remainingFolios ?: 0}")

                mainHandler.post {
                    if (isCancelled) return@post
                    callback.onAuthorizationComplete()
                    launchVerification(activity, sessionData.sessionToken)
                }

            } catch (e: DigidException) {
                Log.e(TAG, "Error de autorización: ${e.code} - ${e.message}")
                mainHandler.post { callback.onAuthorizationError(e) }
            } catch (e: Exception) {
                Log.e(TAG, "Error inesperado en autorización: ${e.message}", e)
                mainHandler.post {
                    callback.onAuthorizationError(
                        DigidException(DigidErrorCode.NETWORK_ERROR, "Error de conexión con el servidor.", e.message)
                    )
                }
            }
        }.start()
    }

    /**
     * Inicia la verificación con el SDK externo.
     * Observa el StateFlow del SDK y lanza la UI solo cuando el estado sea Ready.
     */
    private fun launchVerification(activity: Activity, sessionToken: String) {
        val config = Configuration(
            languageLocale = SupportedLanguage.SPANISH,
            loggingEnabled = BuildConfig.DEBUG
        )

        DiditSdk.startVerification(token = sessionToken, configuration = config) { result ->
            handleVerificationResult(activity, result)
        }

        stateObserverJob?.cancel()
        stateObserverJob = CoroutineScope(Dispatchers.Main).launch {
            DiditSdk.state.collectLatest { state ->
                Log.d(TAG, "Estado del servicio de verificación: $state")
                when (state) {
                    is DiditSdkState.Ready -> {
                        Log.d(TAG, "Servicio listo — lanzando UI de verificación")
                        DiditSdk.launchVerificationUI(activity)
                        stateObserverJob?.cancel()
                    }
                    is DiditSdkState.Error -> {
                        val errorMsg = state.message ?: "Error al inicializar verificación"
                        Log.e(TAG, "Error en servicio de verificación: $errorMsg")
                        stateObserverJob?.cancel()
                        currentCallback?.onVerificationError(
                            DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, "Error en el servicio de verificación: $errorMsg")
                        )
                        currentCallback = null
                    }
                    else -> Log.d(TAG, "Estado transitorio: $state")
                }
            }
        }
    }

    private fun handleVerificationResult(activity: Activity, result: VerificationResult) {
        when (result) {
            is VerificationResult.Completed -> {
                val sessionId = result.session.sessionId
                val verificationStatus = result.session.status.rawValue
                Log.d(TAG, "Verificación completada — Status: $verificationStatus, Session: $sessionId")
                pollingAttempts = 0
                startPolling(sessionId, verificationStatus)
            }
            is VerificationResult.Cancelled -> {
                Log.d(TAG, "Verificación cancelada por el usuario")
                cleanupSession()
                mainHandler.post {
                    currentCallback?.onVerificationCancelled()
                    currentCallback = null
                }
            }
            is VerificationResult.Failed -> {
                val errorMsg = result.error.message ?: "Error durante la verificación"
                Log.e(TAG, "Verificación fallida: $errorMsg")
                cleanupSession()
                mainHandler.post {
                    currentCallback?.onVerificationError(
                        DigidException(DigidErrorCode.VERIFICATION_SERVICE_ERROR, "Error en el servicio de verificación: $errorMsg")
                    )
                    currentCallback = null
                }
            }
        }
    }

    /**
     * Polling al backend para obtener datos completos de la verificación.
     * Los datos llegan al backend vía webhook del servicio externo.
     * Intervalo: 3s | Máximo: 20 intentos (60s total). Timeout retorna resultado parcial.
     */
    private fun startPolling(sessionId: String, verificationStatus: String) {
        Thread { executePollAttempt(sessionId, verificationStatus) }.start()
    }

    private fun executePollAttempt(sessionId: String, verificationStatus: String) {
        if (isCancelled) return

        pollingAttempts++
        Log.d(TAG, "Polling intento $pollingAttempts/$MAX_POLLING_ATTEMPTS para sesión: $sessionId")

        if (pollingAttempts > MAX_POLLING_ATTEMPTS) {
            Log.w(TAG, "Polling timeout — devolviendo resultado parcial")
            mainHandler.post {
                if (!isCancelled) returnFallbackResult(sessionId, verificationStatus)
            }
            return
        }

        try {
            val pollingResponse = DigidAPIClient.pollVerificationResult(sessionId)

            if (pollingResponse.ready) {
                Log.d(TAG, "Datos completos recibidos (intento $pollingAttempts)")
                mainHandler.post {
                    if (!isCancelled) handlePollingSuccess(pollingResponse, sessionId)
                }
            } else {
                Log.d(TAG, "Datos aún no listos: ${pollingResponse.message ?: "esperando webhook"}")
                mainHandler.postDelayed({
                    Thread { executePollAttempt(sessionId, verificationStatus) }.start()
                }, POLLING_INTERVAL_MS)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error en polling: ${e.message} — continuando...")
            mainHandler.postDelayed({
                Thread { executePollAttempt(sessionId, verificationStatus) }.start()
            }, POLLING_INTERVAL_MS)
        }
    }

    private fun handlePollingSuccess(pollingResponse: KycPollingResponse, sessionId: String) {
        val vendorData = currentVendorData ?: pollingResponse.vendorData ?: ""
        val isApproved = pollingResponse.status.lowercase() == "approved"

        Thread {
            val downloadedImages = pollingResponse.images?.let {
                DigidAPIClient.downloadVerificationImages(it)
            } ?: emptyMap()

            val verification = pollingResponse.verification
            val document = pollingResponse.document

            val internalResult = InternalKycResult(
                success = true,
                sessionId = sessionId,
                vendorData = vendorData,
                status = pollingResponse.status,
                faceMatch = verification?.faceMatch ?: isApproved,
                faceMatchScore = verification?.faceMatchScore ?: if (isApproved) 100.0f else 0.0f,
                livenessCheck = verification?.livenessCheck ?: isApproved,
                livenessScore = verification?.livenessScore ?: if (isApproved) 100.0f else 0.0f,
                documentValid = verification?.documentValid ?: isApproved,
                livenessMethod = verification?.livenessMethod,
                ageEstimation = verification?.ageEstimation,
                faceQuality = verification?.faceQuality,
                documentType = document?.documentType ?: "",
                documentNumber = document?.documentNumber ?: "",
                personalNumber = document?.personalNumber ?: "",
                fullName = document?.fullName ?: "",
                firstName = document?.firstName ?: "",
                lastName = document?.lastName ?: "",
                birthDate = document?.birthDate ?: "",
                expiryDate = document?.expiryDate ?: "",
                dateOfIssue = document?.dateOfIssue ?: "",
                nationality = document?.nationality ?: "",
                gender = document?.gender ?: "",
                age = document?.age,
                placeOfBirth = document?.placeOfBirth ?: "",
                // El servidor envía el domicilio en address_data.full_address; se prioriza sobre el campo plano.
                address = document?.addressData?.fullAddress ?: document?.address,
                addressData = document?.addressData,
                extraFieldsJson = document?.extraFieldsJson,
                idFrontBase64 = bitmapToBase64(downloadedImages["front"]),
                idBackBase64 = bitmapToBase64(downloadedImages["back"]),
                selfieBase64 = bitmapToBase64(downloadedImages["selfie"]),
                livenessVideoUrl = null,
                rejectionReasons = pollingResponse.rejectionReasons ?: emptyList(),
                ipAnalysis = pollingResponse.ipAnalysis,
                pdfUrl = pollingResponse.pdfUrl
            )

            mainHandler.post {
                cleanupSession()
                currentCallback?.onVerificationComplete(internalResult)
                currentCallback = null
            }
        }.start()
    }

    private fun returnFallbackResult(sessionId: String, verificationStatus: String) {
        val isApproved = verificationStatus.lowercase() == "approved"

        val fallbackResult = InternalKycResult(
            success = true,
            sessionId = sessionId,
            vendorData = currentVendorData ?: "",
            status = verificationStatus,
            faceMatch = isApproved,
            faceMatchScore = if (isApproved) 100.0f else 0.0f,
            livenessCheck = isApproved,
            livenessScore = if (isApproved) 100.0f else 0.0f,
            documentValid = isApproved,
            livenessMethod = null, ageEstimation = null, faceQuality = null,
            documentType = "", documentNumber = "", personalNumber = "", fullName = "",
            firstName = "", lastName = "", birthDate = "", expiryDate = "", dateOfIssue = "",
            nationality = "", gender = "", age = null, placeOfBirth = "", address = null,
            addressData = null, extraFieldsJson = null,
            idFrontBase64 = "", idBackBase64 = "", selfieBase64 = "",
            livenessVideoUrl = null,
            rejectionReasons = emptyList(),
            ipAnalysis = null, pdfUrl = null
        )

        Log.w(TAG, "Retornando resultado parcial (sin datos del webhook)")
        cleanupSession()
        currentCallback?.onVerificationComplete(fallbackResult)
        currentCallback = null
    }

    private fun bitmapToBase64(bitmap: Bitmap?): String {
        if (bitmap == null) return ""
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Cancela la sesión activa, silenciando cualquier callback pendiente.
     * Llamar desde onDestroy/onPause de la Activity para evitar callbacks sobre
     * un contexto ya destruido.
     */
    fun cancelCurrentSession() {
        isCancelled = true
        cleanupSession()
        Log.d(TAG, "Sesión cancelada externamente.")
    }

    private fun cleanupSession() {
        stateObserverJob?.cancel()
        stateObserverJob = null
        currentSessionToken = null
        currentSessionData = null
        currentVendorData = null
        pollingAttempts = 0
        Log.d(TAG, "Sesión de verificación limpiada.")
    }
}

internal data class InternalKycResult(
    val success: Boolean,
    val sessionId: String,
    val vendorData: String,
    val status: String,
    val faceMatch: Boolean,
    val faceMatchScore: Float,
    val livenessCheck: Boolean,
    val livenessScore: Float,
    val documentValid: Boolean,
    val livenessMethod: String?,
    val ageEstimation: Float?,
    val faceQuality: Float?,
    val documentType: String,
    val documentNumber: String,
    val personalNumber: String,
    val fullName: String,
    val firstName: String,
    val lastName: String,
    val birthDate: String,
    val expiryDate: String,
    val dateOfIssue: String,
    val nationality: String,
    val gender: String,
    val age: Int?,
    val placeOfBirth: String,
    val address: String?,
    val addressData: KycAddressData?,
    val extraFieldsJson: String?,
    val idFrontBase64: String,
    val idBackBase64: String,
    val selfieBase64: String,
    val livenessVideoUrl: String?,
    val rejectionReasons: List<String>,
    val ipAnalysis: KycIpAnalysisData?,
    val pdfUrl: String?
)
