package com.digid.sdk.internal

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.digid.sdk.Digid
import com.digid.sdk.DigidErrorCode
import com.digid.sdk.DigidException
import com.digid.sdk.DigidResultCode
import com.digid.sdk.terms.TermsAcceptanceActivity

/**
 * Clase base interna para todas las Activity del SDK que requieren aceptación previa de T&C.
 *
 * ## Contrato para subclases
 * - **No** hacer `override fun onCreate(...)`. Toda la lógica de inicialización de la vista
 *   debe ir en [onSdkReady].
 * - Se puede hacer `override` de [onTermsDeclined] y [onSdkInitializationError] para
 *   personalizar el comportamiento ante rechazo o error de inicialización.
 *
 * ## Flujo de la puerta de T&C
 * 1. `onCreate` valida que el SDK esté inicializado.
 * 2. Si los T&C ya fueron aceptados dentro del TTL → llama [onSdkReady] directamente.
 * 3. Si no → lanza [TermsAcceptanceActivity] a través del `ActivityResultLauncher`.
 * 4. Al regresar con `RESULT_OK` → registra la aceptación → llama [onSdkReady].
 * 5. Al regresar con cancelación/back → llama [onTermsDeclined].
 *
 * ## Manejo de rotación
 * Si el dispositivo rota mientras [TermsAcceptanceActivity] está activa, la actividad
 * base se recrea con `savedInstanceState != null`. En ese caso se omite el re-lanzamiento
 * de T&C: el `ActivityResultLauncher` ya está registrado y entregará el resultado cuando
 * el usuario termine con la pantalla de T&C.
 */
abstract class DigidBaseActivity : AppCompatActivity() {

    private val tag get() = "Digid/${this::class.simpleName}"

    private lateinit var termsLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // El launcher debe registrarse después de super.onCreate(), que inicializa el
        // ActivityResultRegistry. Se hace aquí (y no como val de clase) porque necesita
        // el contexto del Activity ya configurado. La Activity Result API acepta el registro
        // en cualquier punto antes de onStart().
        termsLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            when (result.resultCode) {
                Activity.RESULT_OK -> {
                    DigidTermsManager.markAccepted()
                    Log.d(tag, "T&C aceptados — iniciando flujo SDK")
                    onSdkReady()
                }
                else -> {
                    Log.d(tag, "T&C rechazados (resultCode=${result.resultCode}) — cancelando")
                    onTermsDeclined()
                }
            }
        }

        // 1. Verificar que el SDK haya sido inicializado
        try {
            Digid.requireInitialized()
        } catch (e: IllegalStateException) {
            Log.e(tag, "SDK no inicializado: ${e.message}")
            onSdkInitializationError(e)
            return
        }

        when {
            // 2a. T&C vigentes → acceder directamente al flujo SDK
            DigidTermsManager.isAccepted() -> {
                Log.d(tag, "T&C vigentes — acceso directo")
                onSdkReady()
            }

            // 2b. Primera creación de la actividad → mostrar pantalla de T&C
            savedInstanceState == null -> {
                Log.d(tag, "T&C pendientes — lanzando TermsAcceptanceActivity")
                termsLauncher.launch(Intent(this, TermsAcceptanceActivity::class.java))
            }

            // 2c. Recreación (p.ej. rotación) mientras TermsAcceptanceActivity está visible:
            //     el launcher ya gestionará el resultado; no relanzar para no apilarlo de nuevo.
            else -> {
                Log.d(tag, "Recreación con T&C en curso — esperando resultado del launcher")
            }
        }
    }

    // ── API para subclases ────────────────────────────────────────────────────

    /**
     * Punto de entrada principal. Se llama cuando el SDK está listo y los T&C han sido aceptados.
     * Reemplaza a `onCreate` en las subclases.
     */
    protected abstract fun onSdkReady()

    /**
     * Llamado cuando el usuario rechaza o cancela los T&C.
     * Comportamiento predeterminado: devolver [DigidResultCode.RESULT_CANCELLED] y terminar.
     */
    protected open fun onTermsDeclined() {
        setResult(DigidResultCode.RESULT_CANCELLED)
        finish()
    }

    /**
     * Llamado cuando el SDK no fue inicializado correctamente.
     * Comportamiento predeterminado: devolver [DigidResultCode.RESULT_ERROR] y terminar.
     */
    protected open fun onSdkInitializationError(e: Exception) {
        val error = DigidException(
            code = DigidErrorCode.SDK_NOT_INITIALIZED,
            message = e.message ?: "SDK no inicializado"
        )
        setResult(
            DigidResultCode.RESULT_ERROR,
            Intent().putExtra("digid_error", error)
        )
        finish()
    }
}
