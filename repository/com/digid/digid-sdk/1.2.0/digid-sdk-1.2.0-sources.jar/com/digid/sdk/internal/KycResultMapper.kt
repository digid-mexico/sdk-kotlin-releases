package com.digid.sdk.internal

import com.digid.sdk.kyc.KycDocument
import com.digid.sdk.kyc.KycResources
import com.digid.sdk.kyc.KycResult
import java.time.Instant

internal object KycResultMapper {

    fun mapFromInternal(
        kycResult: InternalKycResult,
        vendorData: String,
        sessionId: String
    ): KycResult = KycResult(
        success = kycResult.success,
        message = if (kycResult.success) "Verificación completada." else "Verificación finalizada con observaciones.",
        sessionId = sessionId,
        vendorData = vendorData,
        timestamp = Instant.now().toString(),
        faceMatch = kycResult.faceMatch,
        faceMatchScore = kycResult.faceMatchScore,
        livenessCheck = kycResult.livenessCheck,
        livenessScore = kycResult.livenessScore,
        documentValid = kycResult.documentValid,
        document = KycDocument(
            documentType = kycResult.documentType,
            documentNumber = kycResult.documentNumber,
            fullName = kycResult.fullName,
            firstName = kycResult.firstName,
            lastName = kycResult.lastName,
            birthDate = kycResult.birthDate,
            expiryDate = kycResult.expiryDate,
            nationality = kycResult.nationality,
            gender = kycResult.gender,
            address = kycResult.address
        ),
        resources = KycResources(
            idFrontBase64 = kycResult.idFrontBase64,
            idBackBase64 = kycResult.idBackBase64,
            selfieBase64 = kycResult.selfieBase64,
            livenessVideoUrl = kycResult.livenessVideoUrl
        ),
        rejectionReasons = kycResult.rejectionReasons
    )
}
