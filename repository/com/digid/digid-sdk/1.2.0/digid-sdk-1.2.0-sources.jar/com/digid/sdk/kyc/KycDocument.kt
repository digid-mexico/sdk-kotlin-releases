package com.digid.sdk.kyc

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Datos del documento de identidad extraídos durante el proceso KYC.
 * Corresponde a ID(Ine), Pasaporte o Licencia de conducir.
 */
@Parcelize
data class KycDocument(
    /** Tipo de documento: "ID(Ine)", "PASSPORT", "DRIVER_LICENSE". */
    val documentType: String,

    /** Número único del documento o CURP. */
    val documentNumber: String,

    /** Nombre completo tal como aparece en el documento. */
    val fullName: String,

    /** Nombre(s) del titular. */
    val firstName: String,

    /** Apellidos del titular. */
    val lastName: String,

    /** Fecha de nacimiento en formato YYYY-MM-DD. */
    val birthDate: String,

    /** Fecha de vencimiento del documento en formato YYYY-MM-DD. */
    val expiryDate: String,

    /** Código de nacionalidad ISO 3166. Ej: "MEX". */
    val nationality: String,

    /** Género: "M" o "F". */
    val gender: String,

    /** Domicilio registrado en el documento (puede ser null si no está disponible). */
    val address: String?
) : Parcelable
