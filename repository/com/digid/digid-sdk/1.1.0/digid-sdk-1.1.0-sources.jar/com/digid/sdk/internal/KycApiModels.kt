package com.digid.sdk.internal

import org.json.JSONObject

internal data class KycAuthRequest(
    val clientId: String,
    val platform: String = "android",
    val sdkVersion: String = "1.0.0"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("IdClient", clientId)
        put("platform", platform)
        put("sdk_version", sdkVersion)
    }
}

internal data class KycAuthResponse(
    val status: String,
    val session: KycSessionData?,
    val clientInfo: KycClientData?,
    val error: KycServerError?
) {
    companion object {
        fun fromJson(json: JSONObject): KycAuthResponse = KycAuthResponse(
            status = json.optString("status", ""),
            session = json.optJSONObject("session")?.let { KycSessionData.fromJson(it) },
            clientInfo = json.optJSONObject("client_info")?.let { KycClientData.fromJson(it) },
            error = json.optJSONObject("error")?.let { KycServerError.fromJson(it) }
        )
    }
}

internal data class KycSessionData(
    val sessionId: String,
    val sessionToken: String,
    val status: String
) {
    companion object {
        fun fromJson(json: JSONObject): KycSessionData = KycSessionData(
            sessionId = json.optString("session_id", ""),
            sessionToken = json.optString("session_token", ""),
            status = json.optString("status", "")
        )
    }
}

internal data class KycClientData(
    val name: String,
    val remainingFolios: Int
) {
    companion object {
        fun fromJson(json: JSONObject): KycClientData = KycClientData(
            name = json.optString("name", ""),
            remainingFolios = json.optInt("remaining_folios", 0)
        )
    }
}

internal data class KycServerError(
    val code: String,
    val message: String
) {
    companion object {
        fun fromJson(json: JSONObject): KycServerError = KycServerError(
            code = json.optString("code", "UNKNOWN"),
            message = json.optString("message", "Error desconocido del servidor.")
        )
    }
}

internal data class KycPollingResponse(
    val status: String,
    val ready: Boolean,
    val message: String?,
    val sessionId: String?,
    val vendorData: String?,
    val verification: KycVerificationData?,
    val document: KycDocumentData?,
    val images: KycImageData?
) {
    companion object {
        fun fromJson(json: JSONObject): KycPollingResponse = KycPollingResponse(
            status = json.optString("status", ""),
            ready = json.optBoolean("ready", false),
            message = json.optString("message", null),
            sessionId = json.optString("session_id", null),
            vendorData = json.optString("vendor_data", null),
            verification = json.optJSONObject("verification")?.let { KycVerificationData.fromJson(it) },
            document = json.optJSONObject("document")?.let { KycDocumentData.fromJson(it) },
            images = json.optJSONObject("images")?.let { KycImageData.fromJson(it) }
        )
    }
}

internal data class KycVerificationData(
    val faceMatch: Boolean,
    val faceMatchScore: Float,
    val livenessCheck: Boolean,
    val livenessScore: Float,
    val documentValid: Boolean
) {
    companion object {
        fun fromJson(json: JSONObject): KycVerificationData = KycVerificationData(
            faceMatch = json.optBoolean("face_match", false),
            faceMatchScore = json.optDouble("face_match_score", 0.0).toFloat(),
            livenessCheck = json.optBoolean("liveness_check", false),
            livenessScore = json.optDouble("liveness_score", 0.0).toFloat(),
            documentValid = json.optBoolean("document_valid", false)
        )
    }
}

internal data class KycDocumentData(
    val documentType: String?,
    val documentNumber: String?,
    val fullName: String?,
    val firstName: String?,
    val lastName: String?,
    val birthDate: String?,
    val expiryDate: String?,
    val nationality: String?,
    val gender: String?,
    val address: String?
) {
    companion object {
        fun fromJson(json: JSONObject): KycDocumentData = KycDocumentData(
            documentType = json.optString("document_type", null),
            documentNumber = json.optString("document_number", null),
            fullName = json.optString("full_name", null),
            firstName = json.optString("first_name", null),
            lastName = json.optString("last_name", null),
            birthDate = json.optString("birth_date", null),
            expiryDate = json.optString("expiry_date", null),
            nationality = json.optString("nationality", null),
            gender = json.optString("gender", null),
            address = json.optString("address", null)
        )
    }
}

internal data class KycImageData(
    val frontImage: String?,
    val backImage: String?,
    val selfieImage: String?,
    val portraitImage: String?
) {
    companion object {
        fun fromJson(json: JSONObject): KycImageData = KycImageData(
            frontImage = json.optString("front_image", null),
            backImage = json.optString("back_image", null),
            selfieImage = json.optString("selfie_image", null),
            portraitImage = json.optString("portrait_image", null)
        )
    }
}
