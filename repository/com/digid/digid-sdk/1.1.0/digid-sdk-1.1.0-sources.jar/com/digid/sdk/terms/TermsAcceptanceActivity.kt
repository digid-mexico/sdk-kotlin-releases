package com.digid.sdk.terms

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.digid.sdk.Digid
import com.digid.sdk.DigidTermsConfig

/**
 * Pantalla obligatoria de Términos y Condiciones.
 *
 * Mostrada automáticamente por [com.digid.sdk.internal.DigidBaseActivity] antes de cualquier
 * vista del SDK cuando los T&C no han sido aceptados en la sesión actual.
 *
 * Devuelve:
 * - [Activity.RESULT_OK] cuando el usuario acepta (checkbox marcado + pulsar "Continuar").
 * - [Activity.RESULT_CANCELED] cuando el usuario cancela o presiona Atrás.
 */
internal class TermsAcceptanceActivity : AppCompatActivity() {

    private lateinit var btnContinue: TextView
    private lateinit var checkBox: CheckBox
    private var isChecked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val theme = Digid.theme
        val primaryColor = Color.parseColor(theme.primaryColor)
        val bgColor = Color.parseColor(theme.backgroundColor)
        val termsConfig = Digid.termsConfig

        window.statusBarColor = primaryColor

        // ── Root ──────────────────────────────────────────────────────────────
        val root = FrameLayout(this)
        root.setBackgroundColor(bgColor)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(root)

        // ── Scrollable content ────────────────────────────────────────────────
        val scrollView = ScrollView(this)
        root.addView(scrollView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ).apply { bottomMargin = 124.dpToPx() })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24.dpToPx(), 32.dpToPx(), 24.dpToPx(), 24.dpToPx())
        }
        scrollView.addView(content)

        // ── Illustration ──────────────────────────────────────────────────────
        val illustration = IdentityIllustrationView(this, primaryColor)
        content.addView(illustration, LinearLayout.LayoutParams(
            160.dpToPx(), 160.dpToPx()
        ).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = 24.dpToPx()
        })

        // ── Title ─────────────────────────────────────────────────────────────
        val title = TextView(this).apply {
            text = "Validación de Identidad"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1A1A2E"))
            gravity = Gravity.CENTER
        }
        content.addView(title, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // ── Teal accent underline ─────────────────────────────────────────────
        val accent = View(this).apply {
            val bg = GradientDrawable().apply {
                setColor(primaryColor)
                cornerRadius = 4f.dpToPx().toFloat()
            }
            background = bg
        }
        content.addView(accent, LinearLayout.LayoutParams(48.dpToPx(), 4.dpToPx()).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = 8.dpToPx()
            bottomMargin = 16.dpToPx()
        })

        // ── Description ───────────────────────────────────────────────────────
        val description = TextView(this).apply {
            text = "Para continuar con el proceso de verificación de identidad, " +
                    "es necesario que leas y aceptes los Términos y Condiciones de " +
                    "uso del servicio de Digid."
            textSize = 15f
            setTextColor(Color.parseColor("#555555"))
            gravity = Gravity.CENTER
            lineHeight = (15f * 1.55f * resources.displayMetrics.scaledDensity).toInt()
        }
        content.addView(description, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = 4.dpToPx()
            bottomMargin = 24.dpToPx()
        })

        // ── Horizontal divider ────────────────────────────────────────────────
        content.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#E0E0E0"))
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        ).apply { bottomMargin = 20.dpToPx() })

        // ── Checkbox row ──────────────────────────────────────────────────────
        checkBox = CheckBox(this).apply {
            setTextColor(Color.parseColor("#333333"))
            textSize = 14f
            buttonTintList = android.content.res.ColorStateList.valueOf(primaryColor)
        }

        val checkText = "He leído y Acepto los Términos y Condiciones"
        val termsLabel = "Términos y Condiciones"
        val spannable = SpannableString(checkText)
        val startIdx = checkText.indexOf(termsLabel)
        val endIdx = startIdx + termsLabel.length

        spannable.setSpan(
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    showTermsBottomSheet(termsConfig)
                }

                override fun updateDrawState(ds: TextPaint) {
                    super.updateDrawState(ds)
                    ds.color = primaryColor
                    ds.isUnderlineText = true
                    ds.isFakeBoldText = false
                }
            },
            startIdx, endIdx, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        checkBox.text = spannable
        checkBox.movementMethod = LinkMovementMethod.getInstance()
        checkBox.highlightColor = Color.TRANSPARENT

        checkBox.setOnCheckedChangeListener { _, checked ->
            isChecked = checked
            updateContinueButton()
        }

        content.addView(checkBox, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 8.dpToPx() })

        // ── Bottom button bar (fixed) ─────────────────────────────────────────
        val buttonBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(bgColor)
            elevation = 12f
            setPadding(16.dpToPx(), 16.dpToPx(), 16.dpToPx(), 16.dpToPx())
        }

        // "Cancelar" — outlined
        val btnCancel = buildButton(
            label = "Cancelar",
            filled = false,
            primaryColor = primaryColor
        ).apply {
            setOnClickListener {
                setResult(Activity.RESULT_CANCELED)
                finish()
            }
        }
        buttonBar.addView(btnCancel, LinearLayout.LayoutParams(
            0, 52.dpToPx(), 1f
        ).apply { marginEnd = 8.dpToPx() })

        // "Continuar" — filled (disabled until checkbox is checked)
        btnContinue = buildButton(
            label = "Continuar",
            filled = true,
            primaryColor = primaryColor
        ).apply {
            isEnabled = false
            alpha = 0.45f
            setOnClickListener {
                if (isChecked) {
                    setResult(Activity.RESULT_OK)
                    finish()
                }
            }
        }
        buttonBar.addView(btnContinue, LinearLayout.LayoutParams(
            0, 52.dpToPx(), 1f
        ).apply { marginStart = 8.dpToPx() })

        root.addView(buttonBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.BOTTOM })
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        setResult(Activity.RESULT_CANCELED)
        finish()
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun showTermsBottomSheet(config: DigidTermsConfig) {
        val sheet = TermsBottomSheetFragment.newInstance(config.termsText)
        sheet.onAccepted = {
            checkBox.isChecked = true
            isChecked = true
            updateContinueButton()
        }
        sheet.show(supportFragmentManager, TermsBottomSheetFragment.TAG)
    }

    private fun updateContinueButton() {
        btnContinue.isEnabled = isChecked
        btnContinue.alpha = if (isChecked) 1f else 0.45f
    }

    private fun buildButton(label: String, filled: Boolean, primaryColor: Int): TextView {
        return TextView(this).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                cornerRadius = 10f.dpToPx().toFloat()
                if (filled) {
                    setColor(primaryColor)
                } else {
                    setColor(Color.TRANSPARENT)
                    setStroke(2.dpToPx(), primaryColor)
                }
            }
            background = bg
            setTextColor(if (filled) Color.WHITE else primaryColor)
        }
    }

    private fun Int.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()

    private fun Float.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()

    // ── Programmatic illustration ─────────────────────────────────────────────

    /**
     * Vista que dibuja una ilustración de verificación de identidad:
     * - Círculo exterior con fondo claro del color primario
     * - Silueta de persona (cabeza + torso)
     * - Rectángulo de documento con líneas decorativas
     * - Escudo de verificación superpuesto
     */
    inner class IdentityIllustrationView(
        context: android.content.Context,
        private val primaryColor: Int
    ) : View(context) {

        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val figurePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val docPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shieldPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val checkPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2f
            val cy = h / 2f
            val r = minOf(w, h) / 2f * 0.92f

            // ── Background circle (light teal fill) ───────────────────────────
            bgPaint.style = Paint.Style.FILL
            bgPaint.color = primaryColor
            bgPaint.alpha = 22
            canvas.drawCircle(cx, cy, r, bgPaint)

            bgPaint.style = Paint.Style.STROKE
            bgPaint.alpha = 55
            bgPaint.strokeWidth = 2.5f.dpToPxFloat()
            canvas.drawCircle(cx, cy, r, bgPaint)

            // ── Person silhouette ─────────────────────────────────────────────
            figurePaint.style = Paint.Style.FILL
            figurePaint.color = primaryColor
            figurePaint.alpha = 200

            // Head
            val headRadius = r * 0.18f
            val headCy = cy - r * 0.22f
            canvas.drawCircle(cx, headCy, headRadius, figurePaint)

            // Shoulders / torso arc
            val bodyPath = Path().apply {
                val bodyTop = headCy + headRadius * 0.8f
                val bodyW = r * 0.48f
                val bodyH = r * 0.32f
                val arcRect = RectF(cx - bodyW, bodyTop, cx + bodyW, bodyTop + bodyH * 2)
                addArc(arcRect, 180f, 180f)
                close()
            }
            canvas.drawPath(bodyPath, figurePaint)

            // ── Document card ─────────────────────────────────────────────────
            docPaint.style = Paint.Style.FILL
            val docL = cx - r * 0.38f
            val docT = cy + r * 0.18f
            val docR = cx + r * 0.38f
            val docB = cy + r * 0.72f
            val docRect = RectF(docL, docT, docR, docB)
            docPaint.color = Color.WHITE
            canvas.drawRoundRect(docRect, 8f.dpToPxFloat(), 8f.dpToPxFloat(), docPaint)

            // Card border
            docPaint.style = Paint.Style.STROKE
            docPaint.color = primaryColor
            docPaint.alpha = 160
            docPaint.strokeWidth = 2f.dpToPxFloat()
            canvas.drawRoundRect(docRect, 8f.dpToPxFloat(), 8f.dpToPxFloat(), docPaint)

            // Lines on card
            docPaint.style = Paint.Style.FILL
            docPaint.color = primaryColor
            docPaint.alpha = 90
            val lineH = 3f.dpToPxFloat()
            val lineRadius = lineH / 2f
            val lineMargin = (docR - docL) * 0.12f
            val lineTop = docT + (docB - docT) * 0.35f
            for (i in 0..2) {
                val ly = lineTop + i * (lineH + 5f.dpToPxFloat())
                val lineEndRatio = if (i == 2) 0.55f else 0.85f
                canvas.drawRoundRect(
                    RectF(docL + lineMargin, ly, docL + lineMargin + (docR - docL - lineMargin * 2) * lineEndRatio, ly + lineH),
                    lineRadius, lineRadius, docPaint
                )
            }

            // ── Shield / checkmark badge ───────────────────────────────────────
            val badgeCx = docR - 2f.dpToPxFloat()
            val badgeCy = docT + 2f.dpToPxFloat()
            val badgeR = r * 0.22f

            // Badge background
            shieldPaint.style = Paint.Style.FILL
            shieldPaint.color = primaryColor
            canvas.drawCircle(badgeCx, badgeCy, badgeR, shieldPaint)

            // Checkmark
            checkPaint.style = Paint.Style.STROKE
            checkPaint.color = Color.WHITE
            checkPaint.strokeWidth = 2.5f.dpToPxFloat()
            checkPaint.strokeCap = Paint.Cap.ROUND
            checkPaint.strokeJoin = Paint.Join.ROUND
            val ck = badgeR * 0.5f
            val checkPath = Path().apply {
                moveTo(badgeCx - ck * 0.6f, badgeCy)
                lineTo(badgeCx - ck * 0.05f, badgeCy + ck * 0.55f)
                lineTo(badgeCx + ck * 0.7f, badgeCy - ck * 0.6f)
            }
            canvas.drawPath(checkPath, checkPaint)
        }

        private fun Float.dpToPxFloat(): Float =
            this * resources.displayMetrics.density
    }
}
